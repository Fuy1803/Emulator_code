#!/bin/bash
# P6 TEST 4: CPU P6 vs P5 tren jar ghep that (5 tab), 5 phut moi cau hinh, trong netns. Moi cap P5/P6 chay CUNG LUC (cung tai may) de so sanh cong bang.
HERE="$(cd "$(dirname "$0")" && pwd)"
export OUTROOT=${OUTROOT:?}; GJ=${GAMEJAR:?}; DURS=${DURS:-300}
P5=$HERE/../../p5/AngelChipEmulator_V2Proxy_P5.jar; P6=$HERE/../AngelChipEmulator_V2Proxy_P6.jar
mk() { f=$OUTROOT/job_$1.env; mkdir -p $OUTROOT
  { echo "NAME=$1"; echo "JAR=$2"; echo "GAMEJAR=$GJ"; echo "MODE=real5"; echo "DUR=$DURS"; echo "FPS=$3"; echo "AUTO=0"; echo "ACT_AT=10"; echo "ACT=\"$4\""; echo "DSP=$5"; } > $f
  bash $HERE/run_netns.sh $f; }
SLEEP="click 707 361 wait 500 click 718 383 wait 500"
for cfg in "fps2 2 -" "fps5 5 -" "ngu 0 SLEEP"; do set -- $cfg; n=$1; f=$2; a=""; [ "$3" = SLEEP ] && a="$SLEEP"
  mk c_p5_$n $P5 $f "$a" 91 &
  mk c_p6_$n $P6 $f "$a" 92 &
  wait
done
echo ALLDONE > $OUTROOT/ALLDONE
