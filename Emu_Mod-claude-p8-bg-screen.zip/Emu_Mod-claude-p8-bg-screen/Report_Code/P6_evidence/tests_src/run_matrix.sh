#!/bin/bash
# TEST 1/2: ma tran Chaos tren 1 jar. usage: run_matrix.sh JAR TAG OUTROOT [SEC]   (moi o: cap 2/5/10 x {lat tren man tinh, stress, fuzz tren game 2 (List+Canvas+serviceRepaints), fuzz tren jar ghep 2_t.jar})
JAR=$1; TAG=$2; ROOT=$3; SEC=${4:-60}; HERE="$(cd "$(dirname "$0")" && pwd)"; mkdir -p $ROOT
MERGED=${MERGED:?}
i=0
for fps in 2 5 10; do
  for kind in lat stress fuzz2 fuzzm; do
    case $kind in
      lat)    mode=lat;    game=$HERE/testgame3.jar; boot=game;;
      stress) mode=stress; game=$HERE/testgame2.jar; boot=game;;
      fuzz2)  mode=fuzz;   game=$HERE/testgame2.jar; boot=game;;
      fuzzm)  mode=fuzz;   game=$MERGED;             boot=true;;
    esac
    i=$((i+1)); d=$((100+i%4))
    ( DSP=$d CAP=$fps $HERE/run_chaos.sh $JAR $ROOT/${TAG}_${kind}_fps$fps $mode $SEC $((fps*7+i)) $fps 1 day $game $boot > $ROOT/${TAG}_${kind}_fps$fps.out 2>&1 ) &
    if [ $((i%4)) -eq 0 ]; then wait; fi
  done
done
wait
echo "== $TAG"; for f in $ROOT/${TAG}_*_fps*; do [ -d $f ] || continue; n=$(basename $f); echo "$n: $(grep -a 'KET THUC' $f/chaos.log | tail -1 | sed 's/\[CHAOS\] //') $(grep -ac 'CHAOS\] FAIL' $f/chaos.log) FAIL-lines"; done
