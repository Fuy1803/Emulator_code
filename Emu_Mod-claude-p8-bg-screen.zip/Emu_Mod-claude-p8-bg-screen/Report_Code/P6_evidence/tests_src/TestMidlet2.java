import javax.microedition.lcdui.*;
import javax.microedition.midlet.MIDlet;

/** Game thu 2 (kieu game that): khoa chung (keyPressed/paint can khoa ngan); luong game repaint()+serviceRepaints() KHONG giu khoa (giu khoa se tu deadlock ca tren emulator goc);
 *  mot List (man hinh lcdui) doi lua chon khi bam phim; in "[TEST2] KEY n" moi phim nhan duoc. */
public class TestMidlet2 extends MIDlet implements CommandListener {
    static final Object LOCK = new Object();
    static volatile long ticks, paints, keys;
    Display d; Canvas cv; List list;
    class Gfx extends Canvas {
        int x;
        public void paint(Graphics g) {
            synchronized (LOCK) { paints++; }
            g.setColor(0x203060); g.fillRect(0, 0, getWidth(), getHeight());
            g.setColor(0xFFFF00); g.drawString("t " + ticks + " " + (x % 100), 4, 4, Graphics.TOP | Graphics.LEFT);
        }
        public void keyPressed(int k) {
            synchronized (LOCK) { keys++; }
            System.out.println("[TEST2] KEY " + k + " n=" + keys);
            if (k == Canvas.KEY_NUM5 || getGameAction(k) == FIRE) { d.setCurrent(list); }
        }
    }
    public void startApp() {
        d = Display.getDisplay(this);
        cv = new Gfx();
        list = new List("Menu", List.IMPLICIT);
        for (int i = 0; i < 8; i++) list.append("muc " + i, null);
        list.addCommand(new Command("Back", Command.BACK, 1)); list.setCommandListener(this);
        d.setCurrent(cv);
        new Thread(new Runnable() { public void run() {
            while (true) {
                synchronized (LOCK) { ticks++; ((Gfx) cv).x += 3; }
                cv.repaint(); cv.serviceRepaints();
                try { Thread.sleep(30); } catch (InterruptedException e) { return; }
            }
        } }, "game2").start();
        new Thread(new Runnable() { public void run() {
            int s = 0;
            while (true) {
                try { Thread.sleep(1000); } catch (InterruptedException e) { return; }
                System.out.println("[TEST2] t=" + (++s) + " ticks=" + ticks + " paints=" + paints + " keys=" + keys);
            }
        } }, "stat2").start();
    }
    public void commandAction(Command c, Displayable s) { d.setCurrent(cv); }
    public void pauseApp() { }
    public void destroyApp(boolean u) { }
}
