#!/bin/bash
# P6 TEST 3: soak. 4 cua so jar ghep (5 game trong 1 JVM), cap 2 hinh/giay, tu ngu 1 phut, "Chạm là dậy", moi 10-60 s 1 thao tac ngau nhien
# (ngu/day bang menu, cham, phim, an/hien, thu nho/khoi phuc, doi kich thuoc, doi fps, mo menu hop nhat). Dau do moi giay: luong su kien con song (callSerially<=2 s), khong deadlock,
# khong luong ket cho ve, man hinh khong trong khi thuc. usage: soak_p6.sh JAR OUTROOT MERGEDJAR SEC [TABS]
JAR=$1; ROOT=$2; MG=$3; SEC=${4:-7200}; TABS=${5:-3}; HERE="$(cd "$(dirname "$0")" && pwd)"; mkdir -p $ROOT
for i in 1 2 3 4; do
  ( DSP=$((110+i)) CAP=2 ONLY=-1 CHAOS_TABS=$TABS $HERE/run_chaos.sh $JAR $ROOT/w$i soak $SEC $((40+i)) 2 1 cham $MG true > $ROOT/w$i.out 2>&1 ) &
  sleep 3
done
wait
for i in 1 2 3 4; do echo "w$i: $(grep -a 'KET THUC' $ROOT/w$i/chaos.log | tail -1) FAIL-lines=$(grep -ac 'CHAOS\] FAIL' $ROOT/w$i/chaos.log)"; done
