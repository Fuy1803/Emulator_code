import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.*;
import java.lang.management.*;
import java.util.*;
import java.util.List;
import javax.swing.*;

/**
 * CHI DE THU. Chay emulator trong cung JVM va "pha" no: dao ngu/day, doi FPS, an/hien, thu nho (mo phong), doi kich thuoc, bam phim/chuot that (Robot),
 * trong khi dau do kiem tra: (1) callSerially phai chay trong 2 s (luong su kien KHONG ket), (2) khong co deadlock (ThreadMXBean),
 * (3) khong luong nao cho ve (EventDispatcher.serviceRepaints) qua 3 s, (4) man hinh khong TRONG khi thuc, (5) co ngu khop trang thai thanh trang thai.
 * Moi vi pham ghi 1 dong "[CHAOS] FAIL ..." + ghi thread dump vao tep. Cau hinh bang -Dchaos.*  (xem main).
 */
public class Chaos {
    static final String MODE = System.getProperty("chaos.mode", "fuzz");           // fuzz (Robot, jar that) | stress (nhanh, goi truc tiep)
    static final long DUR = Long.getLong("chaos.sec", 300) * 1000L;
    static final long SEED = Long.getLong("chaos.seed", 1);
    static final String DUMP = System.getProperty("chaos.dump", "/tmp/chaos_dump");
    static volatile boolean failed; static volatile int fails; static volatile long rounds;
    static Random rnd = new Random(SEED);
    static Robot robot;
    static Frame frame() { for (Frame f : Frame.getFrames()) if (f.getTitle() != null && f.getTitle().startsWith("AngelChip") && f.isDisplayable()) return f; return null; }
    static Class<?> toiuu() throws Exception { return Class.forName("ep3.ToiUu"); }
    static Object sf(String n) { try { java.lang.reflect.Field f = toiuu().getDeclaredField(n); f.setAccessible(true); return f.get(null); } catch (Throwable t) { return null; } }
    static void call(String n, Object... a) { try { for (java.lang.reflect.Method m : toiuu().getDeclaredMethods()) if (m.getName().equals(n) && m.getParameterTypes().length == a.length) { m.setAccessible(true); m.invoke(null, a); return; } } catch (Throwable t) { } }

    static void dump(String why) {
        try {
            String f = DUMP + "_" + System.currentTimeMillis() + ".txt";
            PrintWriter w = new PrintWriter(new FileWriter(f));
            w.println("== " + why);
            ThreadMXBean mx = ManagementFactory.getThreadMXBean();
            long[] dl = mx.findDeadlockedThreads(); w.println("deadlocked threads: " + (dl == null ? "khong" : Arrays.toString(dl)));
            for (ThreadInfo ti : mx.dumpAllThreads(true, true)) w.print(ti);
            w.close(); System.out.println("[CHAOS] dump -> " + f);
        } catch (Throwable t) { System.out.println("[CHAOS] khong ghi duoc dump: " + t); }
    }
    static void fail(String what) { failed = true; fails++; System.out.println("[CHAOS] FAIL " + what + " (vong " + rounds + ")"); dump(what); }

    static boolean awake() { Object a = sf("asleep"); return a instanceof Boolean && !((Boolean) a); }

    /* ---------- dau do ---------- */
    static volatile long lastProbeOk = System.currentTimeMillis();
    static void startProbes() {
        Thread t = new Thread(new Runnable() { public void run() {
            int blankStreak = 0; boolean frozenReported = false, waitReported = false;
            while (true) {
                try {
                    Thread.sleep(1000);
                    // (1) callSerially trong 2 s
                    final boolean[] ran = new boolean[1];
                    if (!booted) { Thread.sleep(500); continue; }
                    try {
                        javax.microedition.midlet.MIDlet m = org.microemu.MIDletBridge.getCurrentMIDlet();
                        if (m != null) javax.microedition.lcdui.Display.getDisplay(m).callSerially(new Runnable() { public void run() { ran[0] = true; } });
                        else ran[0] = true;
                    } catch (Throwable e) { ran[0] = true; }
                    long t0 = System.currentTimeMillis();
                    while (!ran[0] && System.currentTimeMillis() - t0 < 2000) Thread.sleep(50);
                    if (!ran[0]) { if (!frozenReported) { fail("DONG BANG: callSerially khong chay sau 2 s (luong su kien ket)"); frozenReported = true; } }
                    else frozenReported = false;
                    // (2) deadlock
                    long[] dl = ManagementFactory.getThreadMXBean().findDeadlockedThreads();
                    if (dl != null) fail("DEADLOCK giua cac luong " + Arrays.toString(dl));
                    // (3) luong cho ve qua lau
                    boolean waiting = false;
                    for (Map.Entry<Thread, StackTraceElement[]> e : Thread.getAllStackTraces().entrySet())
                        for (StackTraceElement s : e.getValue()) if (s.getClassName().endsWith("EventDispatcher") && s.getMethodName().equals("serviceRepaints") && e.getKey().getState() == Thread.State.WAITING) waiting = true;
                    stuckWait = waiting ? stuckWait + 1 : 0;
                    if (stuckWait >= 4 && !waitReported) { fail("LUONG CHO VE (serviceRepaints) qua " + stuckWait + " s"); waitReported = true; }
                    if (stuckWait == 0) waitReported = false;
                    // (4) man hinh trong khi thuc
                    if (booted && awake() && frame() != null && frame().isShowing()) {
                        int c = distinctColors();
                        if (c >= 0 && c <= 2) blankStreak++; else blankStreak = 0;
                        if (blankStreak == 4) { saveShot(); fail("MAN HINH TRONG (<=2 mau) khi dang thuc, " + c + " mau; lastPaint-cach-day=" + (sf("lastPaint") instanceof Long ? (System.nanoTime() - (Long) sf("lastPaint")) / 1000000L : -1) + " ms, owedRepaint=" + sf("owedRepaint") + ", hiddenNow=" + sf("hiddenNow") + ", tieu de man hinh=" + curTitle()); }
                    } else blankStreak = 0;
                    // (5) tin hieu "ngu" cua cua so phai khop (thuc <-> khong ngu)
                    lastProbeOk = System.currentTimeMillis();
                } catch (Throwable e) { }
            }
        } }, "chaos-probe");
        t.setDaemon(true); t.start();
    }
    static volatile int stuckWait; static volatile boolean booted;
    static String curTitle() { try { javax.microedition.midlet.MIDlet m = org.microemu.MIDletBridge.getCurrentMIDlet(); javax.microedition.lcdui.Displayable d = javax.microedition.lcdui.Display.getDisplay(m).getCurrent(); return d == null ? "null" : d.getClass().getName() + "/" + d.getTitle(); } catch (Throwable t) { return "?" + t; } }
    static void saveShot() { try { Frame f = frame(); Rectangle b = f.getBounds(); java.awt.image.BufferedImage im = robot.createScreenCapture(b); javax.imageio.ImageIO.write(im, "png", new File(DUMP + "_" + System.currentTimeMillis() + ".png")); } catch (Throwable t) { } }

    static int distinctColors() {
        try {
            final Frame f = frame(); final Component[] disp = new Component[1];
            find(f, disp);
            if (disp[0] == null || disp[0].getWidth() < 20) return -1;
            final BufferedImage im = new BufferedImage(disp[0].getWidth(), disp[0].getHeight(), BufferedImage.TYPE_INT_RGB);
            final Component c = disp[0];
            final boolean[] done = new boolean[1];
            SwingUtilities.invokeLater(new Runnable() { public void run() { try { Graphics g = im.getGraphics(); c.paint(g); g.dispose(); } catch (Throwable t) { } done[0] = true; } });
            long t0 = System.currentTimeMillis(); while (!done[0] && System.currentTimeMillis() - t0 < 2000) Thread.sleep(20);
            if (!done[0]) return -1;
            HashSet<Integer> s = new HashSet<Integer>();
            for (int y = 0; y < im.getHeight(); y += 2) for (int x = 0; x < im.getWidth(); x += 2) { s.add(im.getRGB(x, y)); if (s.size() > 3) return s.size(); }
            return s.size();
        } catch (Throwable t) { return -1; }
    }
    static void find(Component c, Component[] out) {
        if (c.getClass().getName().endsWith("SwingDisplayComponent")) { out[0] = c; return; }
        if (c instanceof Container) for (Component k : ((Container) c).getComponents()) { find(k, out); if (out[0] != null) return; }
    }

    /* ---------- thao tac ---------- */
    static void key(int vk) { robot.keyPress(vk); robot.delay(60); robot.keyRelease(vk); }
    static void hold(int vk, int ms) { robot.keyPress(vk); robot.delay(ms); robot.keyRelease(vk); }
    static void click(int x, int y) { robot.mouseMove(x, y); robot.mousePress(java.awt.event.InputEvent.BUTTON1_DOWN_MASK); robot.delay(80); robot.mouseRelease(java.awt.event.InputEvent.BUTTON1_DOWN_MASK); }
    static JMenuItem findItem(String text) {
        Frame f = frame(); if (!(f instanceof JFrame)) return null;
        JMenuBar mb = ((JFrame) f).getJMenuBar(); if (mb == null) return null;
        for (int i = 0; i < mb.getMenuCount(); i++) { JMenuItem r = scan(mb.getMenu(i), text); if (r != null) return r; }
        return null;
    }
    static JMenuItem scan(JMenuItem m, String text) {
        if (text.equals(m.getText())) return m;
        if (m instanceof JMenu) for (Component c : ((JMenu) m).getMenuComponents()) if (c instanceof JMenuItem) { JMenuItem r = scan((JMenuItem) c, text); if (r != null) return r; }
        return null;
    }
    static void menu(final String text) { SwingUtilities.invokeLater(new Runnable() { public void run() { JMenuItem it = findItem(text); if (it != null) it.doClick(0); } }); }
    static void edt(Runnable r) { SwingUtilities.invokeLater(r); }
    static String[] FPS = { "Không giới hạn", "10 hình/giây", "5 hình/giây", "2 hình/giây" };
    static String[] AUTO = { "Không", "1 phút không thao tác", "5 phút không thao tác", "15 phút không thao tác" };

    static void op() throws Exception {
        Frame f = frame(); if (f == null) return;
        Rectangle b = f.getBounds(); int px = b.x + 20 + rnd.nextInt(Math.max(1, b.width - 40)), py = b.y + 60 + rnd.nextInt(Math.max(1, b.height - 120));
        int r = rnd.nextInt(100);
        if (r < 14) { int[] ks = { KeyEvent.VK_DOWN, KeyEvent.VK_UP, KeyEvent.VK_ENTER, KeyEvent.VK_LEFT, KeyEvent.VK_RIGHT, KeyEvent.VK_5 }; key(ks[rnd.nextInt(ks.length)]); }
        else if (r < 22) click(px, py);
        else if (r < 28) hold(KeyEvent.VK_MULTIPLY, 1300);                       // mo menu hop nhat
        else if (r < 32) key(KeyEvent.VK_F1);
        else if (r < 44) { menu("Ngủ ngay"); }
        else if (r < 54) { menu("Dậy"); }
        else if (r < 60) { menu(FPS[rnd.nextInt(FPS.length)]); }
        else if (r < 64) { menu(AUTO[rnd.nextInt(AUTO.length)]); }
        else if (r < 67) { menu(rnd.nextBoolean() ? "Chạm là dậy" : "Chỉ bấm Dậy"); }
        else if (r < 75) { edt(new Runnable() { public void run() { Frame g = frame(); if (g != null) g.setVisible(false); } }); Thread.sleep(200 + rnd.nextInt(1500)); edt(new Runnable() { public void run() { Frame g = frame(); if (g != null) g.setVisible(true); } }); }
        else if (r < 82) { setState(true); Thread.sleep(200 + rnd.nextInt(1500)); setState(false); }
        else if (r < 88) { edt(new Runnable() { public void run() { Frame g = frame(); if (g != null) g.setSize(g.getWidth() + (rnd.nextBoolean() ? 20 : -20), g.getHeight() + (rnd.nextBoolean() ? 20 : -20)); } }); }
        else if (r < 94) { key(KeyEvent.VK_ENTER); Thread.sleep(150); key(KeyEvent.VK_DOWN); }
        else { /* nghi */ }
        Thread.sleep(150 + rnd.nextInt(1200));
    }
    /** Mo phong thu nho/khoi phuc: dat truong state + phat sinh dung cac su kien WindowEvent ma trinh quan ly cua so that se phat (xvfb khong co WM). */
    static void setState(final boolean ic) { edt(new Runnable() { public void run() { try { Frame g = frame(); if (g == null) return; java.lang.reflect.Field fl = Frame.class.getDeclaredField("state"); fl.setAccessible(true);
        int old = fl.getInt(g), nw = ic ? Frame.ICONIFIED : Frame.NORMAL; if (old == nw) return; fl.setInt(g, nw);
        g.dispatchEvent(new java.awt.event.WindowEvent(g, java.awt.event.WindowEvent.WINDOW_STATE_CHANGED, old, nw));
        g.dispatchEvent(new java.awt.event.WindowEvent(g, ic ? java.awt.event.WindowEvent.WINDOW_ICONIFIED : java.awt.event.WindowEvent.WINDOW_DEICONIFIED)); } catch (Throwable t) { } } }); }

    /** Sau moi vong: doi cap + 300 ms roi kiem tra tinh hop le, in 1 dong tom tat. */
    static void settleAndCheck() throws Exception {
        Thread.sleep(700);
        Frame f = frame();
        if (f != null && !f.isShowing()) { edt(new Runnable() { public void run() { Frame g = frame(); if (g != null) g.setVisible(true); } }); }
        setState(false);
        Thread.sleep(300);
    }

    public static void main(String[] a) throws Exception {
        System.setProperty("java.awt.headless", "false");
        robot = new Robot(); robot.setAutoDelay(10); hookOut();
        startProbes();
        final String[] args = a;
        Thread chaos = new Thread(new Runnable() { public void run() {
            try {
                Thread.sleep(Long.getLong("chaos.start", 15000));
                // khoi dong ban dau: vao mo hinh game (launcher -> menu -> ban 1)
                if ("game".equals(System.getProperty("chaos.boot"))) { click(640, 500); Thread.sleep(400); key(KeyEvent.VK_ENTER); Thread.sleep(5000); }
                else if (Boolean.parseBoolean(System.getProperty("chaos.boot", "true"))) {
                    click(640, 500); Thread.sleep(400); key(KeyEvent.VK_ENTER); Thread.sleep(3000); key(KeyEvent.VK_ENTER); Thread.sleep(7000);
                    int tabs = Integer.getInteger("chaos.tabs", 1);
                    for (int k = 2; k <= tabs; k++) { hold(KeyEvent.VK_MULTIPLY, 1300); Thread.sleep(2000); key(KeyEvent.VK_DOWN); Thread.sleep(500); key(KeyEvent.VK_ENTER); Thread.sleep(6000); }
                }
                booted = true;
                if ("stuck".equals(MODE)) { stuck(); Thread.sleep(500); System.exit(0); }
                if ("lat".equals(MODE)) { lat(); Thread.sleep(500); System.exit(0); }
                long end = System.currentTimeMillis() + DUR;
                System.out.println("[CHAOS] bat dau mode=" + MODE + " seed=" + SEED + " sec=" + DUR / 1000);
                while (System.currentTimeMillis() < end) {
                    rounds++;
                    if ("stress".equals(MODE)) stress(); else { op(); if ("soak".equals(MODE)) { Thread.sleep(10000 + rnd.nextInt(50000)); System.out.println("[CHAOS] hb vong " + rounds + " ngu=" + sf("asleep") + " fails=" + fails + " t=" + new java.util.Date()); } }
                    if (rounds % 10 == 0) { settleAndCheck(); System.out.println("[CHAOS] vong " + rounds + " ngu=" + sf("asleep") + " fails=" + fails); }
                }
                settleAndCheck(); Thread.sleep(6000);   // cho dau do ket luan
                System.out.println("[CHAOS] KET THUC vong=" + rounds + " fails=" + fails);
                System.out.println(fails == 0 ? "[CHAOS] PASS" : "[CHAOS] FAILED"); Thread.sleep(500); System.exit(0);
            } catch (Throwable t) { System.out.println("[CHAOS] loi " + t); }
        } }, "chaos-main");
        chaos.setDaemon(true); chaos.start();
        org.microemu.app.Main.main(a);
    }

    static Object fld(String n) { return sf(n); }
    static long statPainted() { Object o = sf("lastPaint"); return o == null ? -1 : ((Number) o).longValue(); }
    /** dem so lan lastPaint doi gia tri trong ms (moi gia tri = 1 lan ve) */
    static int countPaints(long ms) throws Exception { long end = System.currentTimeMillis() + ms; long last = statPainted(); int n = 0; while (System.currentTimeMillis() < end) { long v = statPainted(); if (v != last && v != 0) { n++; } last = v; Thread.sleep(5); } return n; }
    static boolean pend() { Object o = sf("deferredPending"); if (o instanceof Boolean) return (Boolean) o; if (o instanceof java.util.concurrent.atomic.AtomicBoolean) return ((java.util.concurrent.atomic.AtomicBoolean) o).get(); return false; }
    /** Che do "stuck": doi cai dat khi dang co yeu cau ve bu cho (huy Timer) roi bat lai; sau do ve 2 yeu cau sat nhau tren man tinh: phai ve CA HAI (ve bu hoat dong). */
    static void stuck() throws Exception {
        call("setAutoSleep", 0); call("setShowInfo", false); call("setFps", 2); Thread.sleep(1500);
        call("requestFullRepaint"); Thread.sleep(150);
        call("requestFullRepaint");                                                                 // lan 2 sat lan 1 (< 500 ms): bi hoan -> hen ve bu
        System.out.println("[STUCK] ngay sau yeu cau thu 2: deferredPending=" + pend() + " (mong true: dang cho ve bu)");
        call("setFps", 0);                                                                          // huy Timer (khong con can) KHI dang cho ve bu
        Thread.sleep(300);
        System.out.println("[STUCK] sau khi huy timer: deferredPending=" + pend());
        call("setFps", 2); Thread.sleep(2000);
        System.out.println("[STUCK] sau khi bat lai fps=2, nghi 2 s: deferredPending=" + pend() + " (phai false)");
        call("requestFullRepaint"); Thread.sleep(150);                                              // lan 1 (>500ms tu lan truoc): ve ngay
        long t0 = System.currentTimeMillis(); long base = statPainted();
        call("requestFullRepaint");                                                                 // lan 2: phai duoc ve bu trong <= 600 ms
        int n = 0; long last = statPainted(); long tDone = -1;
        while (System.currentTimeMillis() - t0 < 1800) { long v = statPainted(); if (v != last && v != 0) { n++; if (tDone < 0) tDone = System.currentTimeMillis() - t0; } last = v; Thread.sleep(5); }
        System.out.println("[STUCK] lan 2 duoc ve bu: " + (n >= 1 ? "co, sau " + tDone + " ms" : "KHONG (mat yeu cau ve)") + "; deferredPending=" + pend());
        boolean ok = !pend() && n >= 1 && tDone <= 700;
        System.out.println(ok ? "[CHAOS] PASS" : "[CHAOS] FAILED");
        if (!ok) { fails++; System.out.println("[CHAOS] FAIL ve bu bi mat/ket"); }
    }

    static volatile int firstLost; static volatile long keyAt; static volatile int keyCount; static volatile int awtKeys;
    static { try { Toolkit.getDefaultToolkit().addAWTEventListener(new java.awt.event.AWTEventListener() { public void eventDispatched(AWTEvent e) { if (e.getID() == KeyEvent.KEY_PRESSED) awtKeys++; } }, AWTEvent.KEY_EVENT_MASK); } catch (Throwable t) { } }
    static void hookOut() {
        final java.io.PrintStream old = System.out;
        System.setOut(new java.io.PrintStream(new java.io.OutputStream() {
            StringBuilder sb = new StringBuilder();
            public void write(int b) { old.write(b); if (b == '\n') { String l = sb.toString(); sb.setLength(0); if (l.contains("] KEY ")) { keyAt = System.nanoTime(); keyCount++; } } else sb.append((char) b); }
        }, true));
    }
    static void waitPaint(long base, long ms) throws Exception { long end = System.currentTimeMillis() + ms; while (System.currentTimeMillis() < end && statPainted() == base) Thread.sleep(2); }
    /** Che do "lat": moi vong = 1 nhieu loan (ngu/day, hide/show, iconify, resize, doi fps) roi khoi phuc; do (a) ve lai sau khoi phuc <= cap+100 ms,
     *  (b) phim toi game <= 200 ms, (c) ve sau phim <= cap+100 ms. Moi vi pham = 1 FAIL. */
    static void lat() throws Exception {
        int[] fpsv = { 2, 5, 10 }; int viol = 0;
        int curFps = Integer.getInteger("chaos.fps", 2);
        for (int tries = 0; tries < 8 && keyCount == 0; tries++) { click(640, 500); Thread.sleep(500); key(KeyEvent.VK_ENTER); Thread.sleep(1500); key(KeyEvent.VK_5); Thread.sleep(1500); }
        if (keyCount == 0) { System.out.println("[CHAOS] FAIL game khong khoi dong duoc (hang muc thu bi loai)"); fails++; System.exit(2); }
        long end = System.currentTimeMillis() + DUR; int it = 0;
        while (System.currentTimeMillis() < end) {
            rounds++; it++;
            int r = Integer.getInteger("chaos.only", -1) >= 0 ? Integer.getInteger("chaos.only") : rnd.nextInt(8);
            System.out.println("[CHAOS] it " + it + " r=" + r + " keys=" + keyCount); boolean needPaint = r != 5 && r != 6;                 // r=5 (khong lam gi), r=6 (doi fps roi tra lai) khong an/ngu => khong doi hoi ve lai
            if (r == 0) { call("sleepNow", "lat"); Thread.sleep(300 + rnd.nextInt(1500)); }
            else if (r == 1) { edt(new Runnable() { public void run() { Frame g = frame(); if (g != null) g.setVisible(false); } }); Thread.sleep(200 + rnd.nextInt(1500)); }
            else if (r == 2) { setState(true); Thread.sleep(200 + rnd.nextInt(1500)); }
            else if (r == 3) { edt(new Runnable() { public void run() { Frame g = frame(); if (g != null) g.setSize(g.getWidth() + 30, g.getHeight() + 20); } }); Thread.sleep(300); edt(new Runnable() { public void run() { Frame g = frame(); if (g != null) g.setSize(g.getWidth() - 30, g.getHeight() - 20); } }); }
            else if (r == 4) { call("sleepNow", "lat"); edt(new Runnable() { public void run() { Frame g = frame(); if (g != null) g.setVisible(false); } }); Thread.sleep(300 + rnd.nextInt(800)); }
            else if (r == 5) { /* khong lam gi */ }
            else if (r == 6) { call("setFps", fpsv[rnd.nextInt(3)]); Thread.sleep(300); call("setFps", curFps); Thread.sleep(600); }
            else { setState(true); call("sleepNow", "lat"); Thread.sleep(400); }
            // khoi phuc: hien lai, bo thu nho, day
            long base = statPainted();
            long t0 = System.nanoTime();
            edt(new Runnable() { public void run() { Frame g = frame(); if (g != null) g.setVisible(true); } });
            setState(false);
            call("wake", "lat");
            if (statPainted() >= 0) waitPaint(base, 1500);
            long ms = (System.nanoTime() - t0) / 1000000L;
            long cap = 1000L / curFps + 100;
            if (!needPaint || statPainted() < 0) { }
            else if (statPainted() == base) { viol++; System.out.println("[CHAOS] FAIL khong ve lai sau khoi phuc trong 1,5 s (it " + it + ", r=" + r + ")"); dump("khong ve lai it " + it); }
            else if (ms > cap + 400) { viol++; System.out.println("[CHAOS] FAIL ve lai sau khoi phuc cham " + ms + " ms > " + (cap + 400) + " (it " + it + ")"); }
            Thread.sleep(700);                                  // het thoi gian nuot sau day + cho cua so on dinh
            // phim: toi game <= 200 ms
            { Frame g0 = frame(); if (g0 != null) { Rectangle b0 = g0.getBounds(); click(b0.x + b0.width / 2, b0.y + b0.height / 2); Thread.sleep(150); } }   // tieu diem X (xvfb khong co WM): bam vao cua so
            int kc = keyCount, ak = awtKeys; long pb = statPainted(); keyAt = 0;
            long tk = System.nanoTime();
            key(KeyEvent.VK_5);
            long wait = System.currentTimeMillis() + 2000; while (keyCount == kc && System.currentTimeMillis() < wait) Thread.sleep(2);
            if (keyCount == kc) { firstLost++; System.out.println("[CHAOS] ghi nhan: phim dau tien sau khoi phuc khong toi game sau 2 s (it " + it + ", r=" + r + ")"); String _w = "(it " + it + ", r=" + r + ", asleep=" + sf("asleep") + ", swallow-con=" + ((sf("swallowUntil") instanceof Long ? ((Long) sf("swallowUntil") - System.nanoTime()) / 1000000L : -1)) + "ms, hiddenNow=" + sf("hiddenNow") + ", AWT thay phim=" + (awtKeys - ak) + ", tieu diem=" + (java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().getFocusOwner() == null ? "khong ai" : java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().getFocusOwner().getClass().getSimpleName()) + ", awake=" + awake() + ", hien=" + (frame() != null && frame().isShowing()) + ")";
                int k2 = keyCount; key(KeyEvent.VK_5); Thread.sleep(600); boolean again5 = keyCount > k2;
                int k3 = keyCount; key(KeyEvent.VK_6); Thread.sleep(600); boolean six = keyCount > k3;
                System.out.println("[CHAOS] nhan xet: bam lai phim 5 -> " + (again5 ? "toi game" : "KHONG") + "; bam phim 6 -> " + (six ? "toi game" : "KHONG") + " " + _w);
                if (!again5 && !six) { viol++; fails++; System.out.println("[CHAOS] FAIL DONG BANG: ca 3 lan bam phim deu khong toi game " + _w); dump("dong bang it " + it); } }
            else {
                long kl = (keyAt - tk) / 1000000L - 60;      // tru 60 ms Robot giu phim
                if (kl > 200) { viol++; System.out.println("[CHAOS] FAIL phim toi game cham " + kl + " ms > 200 (it " + it + ")"); }
                if (statPainted() >= 0) waitPaint(pb, 1500);
                long pl = (System.nanoTime() - tk) / 1000000L - 60;
                if (statPainted() < 0) { } else if (statPainted() == pb) { viol++; System.out.println("[CHAOS] FAIL sau phim khong ve lai (it " + it + ")"); }
                else if (statPainted() >= 0 && pl > 1000L / curFps + 100 + 60) { viol++; System.out.println("[CHAOS] FAIL ve sau phim cham " + pl + " ms > " + (1000L / curFps + 100) + " (it " + it + ")"); }
            }
            if (it % 10 == 0) System.out.println("[CHAOS] vong " + it + " vi pham=" + viol);
        }
        fails += 0;
        System.out.println("[CHAOS] KET THUC vong=" + it + " vi pham=" + viol + " mat-phim-dau=" + firstLost);
        System.out.println(viol == 0 ? "[CHAOS] PASS" : "[CHAOS] FAILED");
    }

    /** Che do nhanh: goi truc tiep ngu/day moi 10-300 ms + doi fps + an/hien. */
    static void stress() throws Exception {
        int r = rnd.nextInt(10);
        if (r < 3) call("sleepNow", "chaos"); else if (r < 6) call("wake", "chaos");
        else if (r < 7) menu(FPS[rnd.nextInt(FPS.length)]);
        else if (r < 8) { edt(new Runnable() { public void run() { Frame g = frame(); if (g != null) g.setVisible(false); } }); Thread.sleep(rnd.nextInt(100)); edt(new Runnable() { public void run() { Frame g = frame(); if (g != null) g.setVisible(true); } }); }
        else if (r < 9) setState(rnd.nextBoolean());
        else key(KeyEvent.VK_5);
        Thread.sleep(10 + rnd.nextInt(290));
    }
}
