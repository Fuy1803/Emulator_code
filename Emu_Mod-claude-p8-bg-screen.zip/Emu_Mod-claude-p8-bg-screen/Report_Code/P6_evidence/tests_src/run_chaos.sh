#!/bin/bash
# usage: run_chaos.sh JAR OUTDIR MODE SEC SEED FPS AUTO WAKE GAME [boot] ; chay Chaos tren 1 cua so (xvfb :${DSP:-87}), in dong CHAOS cuoi
JAR=$1; OUT=$2; MODE=$3; SEC=$4; SEED=$5; FPS=$6; AUTO=$7; WAKE=$8; GAME=$9; BOOT=${10:-false}
HERE="$(cd "$(dirname "$0")" && pwd)"; export JAVA_TOOL_OPTIONS=
mkdir -p $OUT; H=$OUT/home; rm -rf $H; mkdir -p $H/.microemulator
printf "fps=$FPS\nautosleep=$AUTO\nwake=$WAKE\n" > $H/.microemulator/toiuu_m.properties
pgrep -f "Xvfb :${DSP:-87} " >/dev/null || { (Xvfb :${DSP:-87} -screen 0 1280x1024x24 >/dev/null 2>&1 &); sleep 2; }
cd $OUT; DISPLAY=:${DSP:-87} timeout $((SEC+90)) java --add-opens java.desktop/java.awt=ALL-UNNAMED -XX:+UseSerialGC -Xss256k -Xmx192m -Duser.home=$H -Dtoiuu.debug=true -Dchaos.fps=${CAP:-2} -Dchaos.only=${ONLY:--1} -Dchaos.mode=$MODE -Dchaos.sec=$SEC -Dchaos.seed=$SEED -Dchaos.tabs=${CHAOS_TABS:-1} -Dchaos.boot=$BOOT -Dchaos.start=12000 -Dchaos.dump=$OUT/dump -cp $JAR:$HERE Chaos --proxyProfile m $GAME > chaos.log 2>&1
grep -a "CHAOS\] \(FAIL\|KET\|PASS\|FAILED\)" chaos.log | sort | uniq -c | head -8
