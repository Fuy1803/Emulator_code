import javax.microedition.lcdui.*;
import javax.microedition.midlet.MIDlet;

/** Game thu 3: man hinh TINH (khong luong nao tu ve); chi ve khi co yeu cau (de kiem tra ve bu / ve khi day / khoi phuc). */
public class TestMidlet3 extends MIDlet {
    static volatile int paints, keys, sel;
    public void startApp() {
        Canvas c = new Canvas() {
            public void paint(Graphics g) { paints++; g.setColor(0x102040 + sel * 0x101010); g.fillRect(0, 0, getWidth(), getHeight()); g.setColor(0xFFFF00); g.drawString("sel " + sel + " paints " + paints, 4, 4, Graphics.TOP | Graphics.LEFT); }
            public void keyPressed(int k) { keys++; sel = (sel + 1) % 8; System.out.println("[TEST3] KEY " + k + " n=" + keys); repaint(); }
        };
        Display.getDisplay(this).setCurrent(c);
    }
    public void pauseApp() { }
    public void destroyApp(boolean u) { }
}
