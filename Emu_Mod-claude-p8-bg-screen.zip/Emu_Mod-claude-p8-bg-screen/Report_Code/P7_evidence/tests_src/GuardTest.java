import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.lang.management.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.List;
import javax.swing.*;

/**
 * CHI DE THU (P7). Chay emulator trong cung JVM va kiem tra DAU VAO TOI MIDLET khi ngu / luc day / tin hieu phim ket / cuu ho / watchdog.
 * -Dgt.scn = A (phim ket: giu phim -> ngu -> nha luc ngu -> day -> bam lai), B (tiem su kien khi ngu: hang doi, goi thang SwingDeviceComponent, goi thang DisplayAccess, focus/activate, chuot),
 *            C (ngu lau tren jar ghep: danh sach ghep con nguyen + chon duoc sau khi day), W (watchdog), R (muc cuu ho 7, 8 tren game thu), R2 (muc cuu ho tren jar ghep trong 1 ban game)
 * Moi ket luan in 1 dong "[GT] ..." (PASS/FAIL kem so lieu). Cac dong "[T4] ..." cua MIDlet thu duoc bat de dem su kien toi MIDlet.
 */
public class GuardTest {
    static Robot robot;
    static final List<long[]> EVT = Collections.synchronizedList(new ArrayList<long[]>());   // {tNs, id}
    static final List<String> EVS = Collections.synchronizedList(new ArrayList<String>());
    static volatile int wd; static volatile int outLines;
    static final StringBuffer ALL = new StringBuffer();
    static int fails;

    static void hookOut() {
        final PrintStream old = System.out;
        System.setOut(new PrintStream(new OutputStream() {
            StringBuilder sb = new StringBuilder();
            public void write(int b) {
                old.write(b);
                if (b == '\n') {
                    String l = sb.toString(); sb.setLength(0);
                    if (l.startsWith("[T4] ") && !l.startsWith("[T4] TICK")) { EVT.add(new long[] { System.nanoTime() }); EVS.add(l.substring(5)); }
                    if (l.contains("======== DO:")) wd++;
                    if (ALL.length() < 2000000) ALL.append(l).append('\n');
                } else sb.append((char) b);
            }
        }, true));
    }
    static int mark() { return EVS.size(); }
    static List<String> since(int m) { synchronized (EVS) { return new ArrayList<String>(EVS.subList(Math.min(m, EVS.size()), EVS.size())); } }

    static void say(String s) { System.out.println("[GT] " + s); }
    static void check(boolean ok, String s) { if (!ok) fails++; say((ok ? "PASS " : "FAIL ") + s); }

    static Frame frame() { for (Frame f : Frame.getFrames()) if (f.getTitle() != null && f.getTitle().startsWith("AngelChip") && f.isDisplayable()) return f; return null; }
    static Component find(Component c, String suffix) {
        if (c.getClass().getName().endsWith(suffix)) return c;
        if (c instanceof Container) for (Component k : ((Container) c).getComponents()) { Component r = find(k, suffix); if (r != null) return r; }
        return null;
    }
    static Component dev() { return find(frame(), "SwingDeviceComponent"); }
    static Component disp() { return find(frame(), "SwingDisplayComponent"); }
    static Class<?> toiuu() throws Exception { return Class.forName("ep3.ToiUu"); }
    static void call(String n, Object... a) { try { for (Method m : toiuu().getDeclaredMethods()) if (m.getName().equals(n) && m.getParameterTypes().length == a.length) { m.setAccessible(true); m.invoke(null, a); return; } } catch (Throwable t) { say("call " + n + " loi " + t); } }
    static Object sf(String n) { try { Field f = toiuu().getDeclaredField(n); f.setAccessible(true); return f.get(null); } catch (Throwable t) { return null; } }
    static String cur() {
        try { Method m = toiuu().getDeclaredMethod("currentDescribe"); m.setAccessible(true); return (String) m.invoke(null); } catch (Throwable t) { /* P6: khong co */ }
        try { javax.microedition.lcdui.Displayable d = curD(); if (d == null) return "null"; String n = d.getClass().getName(); String ti = d.getTitle(); return n + (ti == null || ti.length() == 0 ? "" : "/\"" + ti + "\"") + " [ban " + (n.startsWith("b.") ? 2 : n.startsWith("c.") ? 3 : n.startsWith("d.") ? 4 : n.startsWith("e.") ? 5 : (n.indexOf('.') < 0 || n.startsWith("com.")) ? 1 : 0) + "]"; } catch (Throwable t) { return "?"; }
    }
    static javax.microedition.lcdui.Displayable curD() { try { javax.microedition.midlet.MIDlet m = org.microemu.MIDletBridge.getCurrentMIDlet(); return javax.microedition.lcdui.Display.getDisplay(m).getCurrent(); } catch (Throwable t) { return null; } }
    static void setD(javax.microedition.lcdui.Displayable d) { try { javax.microedition.midlet.MIDlet m = org.microemu.MIDletBridge.getCurrentMIDlet(); javax.microedition.lcdui.Display.getDisplay(m).setCurrent(d); } catch (Throwable t) { } }

    static void post(AWTEvent e) { Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(e); }
    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { } }
    static KeyEvent ke(int id, int vk, char ch) { return new KeyEvent(dev(), id, System.currentTimeMillis(), 0, vk, ch); }
    static void kPress(int vk, char ch) { post(ke(KeyEvent.KEY_PRESSED, vk, ch)); }
    static void kRelease(int vk, char ch) { post(ke(KeyEvent.KEY_RELEASED, vk, ch)); }
    static void kTap(int vk, char ch) { kPress(vk, ch); sleep(40); if (ch != KeyEvent.CHAR_UNDEFINED) post(ke(KeyEvent.KEY_TYPED, KeyEvent.VK_UNDEFINED, ch)); kRelease(vk, ch); sleep(120); }
    /** goi thang SwingDeviceComponent (khong qua hang doi AWT) = duong "khac" (dong bo lai ban phim khi RDP ket noi lai...) */
    static void direct(String m, KeyEvent e) { try { Component d = dev(); d.getClass().getMethod(m, KeyEvent.class).invoke(d, e); } catch (Throwable t) { say("direct loi " + t); } }
    static void menu(final String text) { SwingUtilities.invokeLater(new Runnable() { public void run() { JMenuItem it = item(text); if (it != null) it.doClick(0); else say("khong thay muc menu " + text); } }); }
    static JMenuItem item(String text) {
        Frame f = frame(); if (!(f instanceof JFrame)) return null;
        JMenuBar mb = ((JFrame) f).getJMenuBar(); if (mb == null) return null;
        for (int i = 0; i < mb.getMenuCount(); i++) { JMenuItem r = scan(mb.getMenu(i), text); if (r != null) return r; }
        return null;
    }
    static JMenuItem scan(JMenuItem m, String text) {
        if (text.equals(m.getText())) return m;
        if (m instanceof JMenu) for (Component c : ((JMenu) m).getMenuComponents()) if (c instanceof JMenuItem) { JMenuItem r = scan((JMenuItem) c, text); if (r != null) return r; }
        return null;
    }
    static void click(int x, int y) { robot.mouseMove(x, y); robot.mousePress(InputEvent.BUTTON1_DOWN_MASK); robot.delay(80); robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK); }
    static void rkey(int vk) { robot.keyPress(vk); robot.delay(60); robot.keyRelease(vk); }

    static int dispHash() {
        try {
            final Component c = disp(); final BufferedImage im = new BufferedImage(c.getWidth(), c.getHeight(), BufferedImage.TYPE_INT_RGB);
            final boolean[] done = new boolean[1];
            SwingUtilities.invokeLater(new Runnable() { public void run() { try { Graphics g = im.getGraphics(); c.paint(g); g.dispose(); } catch (Throwable t) { } done[0] = true; } });
            long t0 = System.currentTimeMillis(); while (!done[0] && System.currentTimeMillis() - t0 < 3000) sleep(20);
            int h = 17; for (int y = 0; y < im.getHeight(); y += 3) for (int x = 0; x < im.getWidth(); x += 3) h = h * 31 + im.getRGB(x, y);
            return h;
        } catch (Throwable t) { return -1; }
    }

    static String names(List<String> l) { return l.size() <= 12 ? l.toString() : l.subList(0, 12) + "...(" + l.size() + ")"; }
    static boolean has(List<String> l, String prefix) { for (String s : l) if (s.startsWith(prefix)) return true; return false; }
    static int cnt(List<String> l, String prefix) { int n = 0; for (String s : l) if (s.startsWith(prefix)) n++; return n; }

    static void bootGame() { click(640, 500); sleep(500); rkey(KeyEvent.VK_ENTER); sleep(6000); }
    static void toGameFocus() { Frame f = frame(); Rectangle b = f.getBounds(); click(b.x + 12, b.y + b.height - 6); sleep(300); }   // bam vao thanh trang thai (khong cham man hinh game)

    /* ======================= A: phim ket ======================= */
    static void scnA(int sleepSecs, boolean repeat) throws Exception {
        say("A: giu phim -> Ngu ngay -> nha luc ngu -> (chu ky repeat=" + repeat + ") cho " + sleepSecs + " s -> Day -> bam lai");
        javax.microedition.lcdui.Displayable cv = curD();
        int[][] keys = { { KeyEvent.VK_2, '2' }, { KeyEvent.VK_F1, 0xFFFF }, { KeyEvent.VK_F2, 0xFFFF }, { KeyEvent.VK_ENTER, '\n' } };
        String[] nm = { "'2'", "F1 (phim mem trai)", "F2 (phim mem phai)", "Enter" };
        for (int i = 0; i < keys.length; i++) {
            final int vk = keys[i][0]; final char ch = (char) keys[i][1];
            setD(cv); sleep(400);
            // co so: bam binh thuong 1 lan, xem MIDlet nhan gi
            int m0 = mark(); kTap(vk, ch); sleep(300); List<String> base = since(m0);
            setD(cv); sleep(400);
            int m1 = mark();
            kPress(vk, ch);
            final boolean[] stop = new boolean[1];
            Thread rep = null;
            if (repeat) { final int fvk = vk; final char fch = ch; rep = new Thread(new Runnable() { public void run() { while (!stop[0]) { post(ke(KeyEvent.KEY_PRESSED, fvk, fch)); sleep(30); } } }); rep.start(); }
            sleep(700);
            int msleep = mark();
            call("sleepNow", "gt"); sleep(500);
            int mAfterSleep = mark();
            sleep(1500);                                       // van giu (repeat) khi dang ngu
            stop[0] = true; if (rep != null) rep.join();
            kRelease(vk, ch);                                  // nha KHI DANG NGU
            sleep(sleepSecs * 1000L);
            List<String> during = since(mAfterSleep);
            int mw = mark();
            call("wake", "gt"); sleep(1500);
            List<String> atWake = since(mw);
            setD(cv); sleep(400);                              // dua ve man hinh co so (lenh luc giu co the da doi man hinh)
            int m2 = mark();
            kTap(vk, ch); sleep(500);
            List<String> after = since(m2);
            boolean sameAsBase = after.size() > 0 && has(after, "KEY_P") == has(base, "KEY_P") && has(after, "CMD") == has(base, "CMD") && has(after, "KEY_RP") == has(base, "KEY_RP");
            say("  phim " + nm[i] + ": co-so(bam binh thuong)=" + names(base) + " | luc ngu toi MIDlet=" + names(during) + " | ngay sau day=" + names(atWake) + " | bam lai sau day=" + names(after));
            check(during.isEmpty(), "A " + nm[i] + ": 0 su kien toi MIDlet trong luc ngu (sau thoi diem nha-luc-bat-dau-ngu) [" + during.size() + "]");
            check(atWake.isEmpty(), "A " + nm[i] + ": 0 su kien toi MIDlet ngay sau day tu dau vao truoc day [" + atWake.size() + "]");
            check(sameAsBase, "A " + nm[i] + ": bam lai sau day cho CUNG ket qua nhu bam binh thuong (khong ket phim)");
            { List<String> st = since(msleep); say("  (tu luc bat dau ngu trong 500 ms dau - nha phim/giu luc bat dau ngu: " + names(st.subList(0, Math.min(st.size(), Math.max(0, mAfterSleep - msleep)))) + ")"); }
        }
    }

    /* ======================= B: tiem su kien khi ngu ======================= */
    static void scnB() throws Exception {
        say("B: tiem su kien khi dang ngu (hang doi AWT, goi thang SwingDeviceComponent, goi thang DisplayAccess, focus/activate, chuot)");
        javax.microedition.lcdui.Displayable cv = curD();
        String before = cur();
        call("sleepNow", "gt"); sleep(600);
        int m0 = mark();
        int[] vks = { KeyEvent.VK_ENTER, KeyEvent.VK_UP, KeyEvent.VK_DOWN, KeyEvent.VK_LEFT, KeyEvent.VK_RIGHT, KeyEvent.VK_F1, KeyEvent.VK_F2, KeyEvent.VK_ESCAPE, KeyEvent.VK_A, KeyEvent.VK_B, KeyEvent.VK_5, KeyEvent.VK_2 };
        for (int vk : vks) { char ch = vk >= KeyEvent.VK_A && vk <= KeyEvent.VK_Z ? (char) (vk + 32) : vk == KeyEvent.VK_5 ? '5' : vk == KeyEvent.VK_2 ? '2' : KeyEvent.CHAR_UNDEFINED; kTap(vk, ch); }
        int mQ = mark(); List<String> qq = since(m0);
        for (int vk : vks) { char ch = vk >= KeyEvent.VK_A && vk <= KeyEvent.VK_Z ? (char) (vk + 32) : vk == KeyEvent.VK_5 ? '5' : vk == KeyEvent.VK_2 ? '2' : KeyEvent.CHAR_UNDEFINED;
            direct("keyPressed", ke(KeyEvent.KEY_PRESSED, vk, ch)); if (ch != KeyEvent.CHAR_UNDEFINED) direct("keyTyped", ke(KeyEvent.KEY_TYPED, KeyEvent.VK_UNDEFINED, ch)); direct("keyReleased", ke(KeyEvent.KEY_RELEASED, vk, ch)); sleep(60); }
        int mD = mark(); List<String> dd = since(mQ);
        // thang vao DisplayAccess (mo phong mod/ControlBridge/dong bo ban phim muc thap)
        try {
            org.microemu.DisplayAccess da = org.microemu.MIDletBridge.getMIDletAccess().getDisplayAccess();
            da.keyPressed(50); da.keyRepeated(50); da.keyReleased(50); da.pointerPressed(5, 5); da.pointerDragged(6, 6); da.pointerReleased(6, 6);
        } catch (Throwable t) { say("DisplayAccess loi " + t); }
        sleep(300);
        int mA = mark(); List<String> da2 = since(mD);
        // focus / kich hoat / chuot qua hang doi
        Frame f = frame(); Component d = dev(), ds = disp();
        post(new FocusEvent(d, FocusEvent.FOCUS_LOST)); post(new FocusEvent(d, FocusEvent.FOCUS_GAINED));
        post(new WindowEvent(f, WindowEvent.WINDOW_DEACTIVATED)); post(new WindowEvent(f, WindowEvent.WINDOW_LOST_FOCUS)); post(new WindowEvent(f, WindowEvent.WINDOW_GAINED_FOCUS)); post(new WindowEvent(f, WindowEvent.WINDOW_ACTIVATED));
        post(new MouseEvent(ds, MouseEvent.MOUSE_PRESSED, System.currentTimeMillis(), InputEvent.BUTTON1_MASK, 20, 20, 1, false, MouseEvent.BUTTON1));
        post(new MouseEvent(ds, MouseEvent.MOUSE_DRAGGED, System.currentTimeMillis(), InputEvent.BUTTON1_MASK, 22, 22, 1, false));
        post(new MouseEvent(ds, MouseEvent.MOUSE_RELEASED, System.currentTimeMillis(), InputEvent.BUTTON1_MASK, 22, 22, 1, false, MouseEvent.BUTTON1));
        post(new MouseEvent(ds, MouseEvent.MOUSE_CLICKED, System.currentTimeMillis(), InputEvent.BUTTON1_MASK, 22, 22, 1, false, MouseEvent.BUTTON1));
        post(new MouseEvent(d, MouseEvent.MOUSE_PRESSED, System.currentTimeMillis(), InputEvent.BUTTON1_MASK, 60, 300, 1, false, MouseEvent.BUTTON1));
        post(new MouseEvent(d, MouseEvent.MOUSE_RELEASED, System.currentTimeMillis(), InputEvent.BUTTON1_MASK, 60, 300, 1, false, MouseEvent.BUTTON1));
        sleep(800);
        List<String> ff = since(mA);
        // chuot that + phim that bang Robot
        Rectangle b = f.getBounds();
        int mR = mark();
        click(b.x + b.width / 2, b.y + b.height / 2); rkey(KeyEvent.VK_ENTER); rkey(KeyEvent.VK_F1); rkey(KeyEvent.VK_ESCAPE); rkey(KeyEvent.VK_A);
        sleep(800);
        List<String> rr = since(mR);
        say("  hang doi AWT: " + names(qq) + " | goi thang SDC: " + names(dd) + " | goi thang DisplayAccess: " + names(da2) + " | focus/activate/chuot: " + names(ff) + " | Robot that: " + names(rr));
        check(qq.isEmpty(), "B hang doi AWT (phim nhan/nha/go): 0 su kien toi MIDlet [" + qq.size() + "]");
        check(dd.isEmpty(), "B goi thang SwingDeviceComponent.keyPressed/keyTyped/keyReleased (duong ngoai hang doi): 0 [" + dd.size() + "]");
        check(da2.isEmpty(), "B goi thang DisplayAccess (key/pointer): 0 [" + da2.size() + "]");
        check(ff.isEmpty(), "B focus lost/gained + deactivate/activate + chuot: 0 [" + ff.size() + "]");
        check(rr.isEmpty(), "B Robot that (chuot+Enter+F1+Esc+a): 0 [" + rr.size() + "]");
        String mid = cur();
        int m3 = mark();
        call("wake", "gt"); sleep(2500);
        List<String> aw = since(m3);
        check(aw.isEmpty(), "B ngay sau Day: 0 su kien tu dau vao luc ngu [" + aw.size() + "] " + names(aw));
        String after = cur();
        check(before.equals(after) && before.equals(mid), "B man hinh hien tai khong doi: truoc=" + before + " | giua=" + mid + " | sau=" + after);
        int m4 = mark(); setD(cv); sleep(300); kTap(KeyEvent.VK_2, '2'); sleep(500);
        List<String> n = since(m4);
        check(has(n, "KEY_P 50") && has(n, "KEY_R 50"), "B sau Day phim moi van toi game binh thuong: " + names(n));
    }

    /* ======================= C: ngu lau tren jar ghep ======================= */
    static void scnC(int secs, boolean hold) throws Exception {
        say("C: jar ghep, danh sach ghep, ngu " + secs + " s (giu phim '2' luc bat dau ngu: " + hold + ")");
        click(640, 500); sleep(500); rkey(KeyEvent.VK_ENTER); sleep(4000);       // vao danh sach ghep (Hai tac 1 duoc chon)
        toGameFocus();
        String d0 = cur(); int h0 = dispHash();
        say("  truoc ngu: man hinh=" + d0 + " hash=" + h0);
        if (hold) kPress(KeyEvent.VK_2, '2');   // giu phim KHONG chon muc (Enter se chon ngay Hai tac 1)
        sleep(800);
        menu("Ngủ ngay"); sleep(300);
        if (hold) { sleep(1000); kRelease(KeyEvent.VK_2, '2'); }
        long end = System.currentTimeMillis() + secs * 1000L; String last = cur(); int changes = 0; long n = 0;
        while (System.currentTimeMillis() < end) {
            sleep(5000);
            String c = cur();
            if (!c.equals(last)) { changes++; say("  !!! man hinh doi khi ngu: " + last + " -> " + c); last = c; }
            if (++n % 60 == 0) say("  ngu " + (n * 5) + " s, man hinh=" + c);
        }
        menu("Dậy"); sleep(2500);
        String d1 = cur(); int h1 = dispHash();
        say("  sau day: man hinh=" + d1 + " hash=" + h1);
        check(changes == 0 && d0.equals(d1), "C man hinh hien tai khong doi sau " + secs + " s ngu (" + changes + " lan doi)");
        check(h0 == h1, "C hinh danh sach ghep sau day giong truoc ngu (cung lua chon) hash " + h0 + " vs " + h1);
        toGameFocus(); sleep(300);
        rkey(KeyEvent.VK_ENTER); sleep(4000);                                      // chon Hai tac 1 => phai vao ban game
        String d2 = cur();
        check(!d2.equals(d1) && d2.contains("[ban"), "C sau day bam Enter chon duoc Hai tac 1: " + d2);
    }

    /* ======================= W: watchdog ======================= */
    static void scnW() throws Exception {
        say("W: watchdog. dump hien co=" + wd);
        sleep(30000);
        check(wd == 0, "W chay binh thuong 30 s: 0 dump [" + wd + "]");
        toGameFocus();
        say("  chan luong su kien emulator 10 s (phim '9')");
        int w0 = wd; kTap(KeyEvent.VK_9, '9');
        sleep(22000);
        check(wd - w0 == 1, "W luong su kien bi chan 10 s: dung 1 dump [" + (wd - w0) + "]");
        String s = ALL.toString(); int i = s.lastIndexOf("======== DO:");
        check(i >= 0 && s.indexOf("event-thread", i) > 0, "W dump co tieu de va ngan xep luong event-thread");
        say("  chan EDT 12 s");
        int w1 = wd;
        SwingUtilities.invokeLater(new Runnable() { public void run() { sleep(12000); } });
        sleep(26000);
        check(wd - w1 == 1, "W EDT bi chan 12 s: dung 1 dump [" + (wd - w1) + "]");
        say("  TAT 'Ghi log khi do' roi chan 10 s");
        item("Ghi log khi đơ").doClick(0); sleep(500);
        int w2 = wd; kTap(KeyEvent.VK_9, '9'); sleep(24000);
        check(wd == w2, "W TAT: 0 dump khi chan 10 s [" + (wd - w2) + "]");
        item("Ghi log khi đơ").doClick(0); sleep(500);                           // bat lai
        say("  BAT lai: chan 10 s");
        int w3 = wd; kTap(KeyEvent.VK_9, '9'); sleep(22000);
        check(wd - w3 == 1, "W BAT lai: dung 1 dump [" + (wd - w3) + "]");
        say("  chan LIEN TUC ~40 s: chi 1 dump (toi da 1 lan / 10 phut khi con do)");
        int w4 = wd; kTap(KeyEvent.VK_9, '9'); sleep(11000); kTap(KeyEvent.VK_9, '9'); sleep(11000); kTap(KeyEvent.VK_9, '9'); sleep(11000); kTap(KeyEvent.VK_9, '9'); sleep(14000);
        say("  so dump trong chan lien tuc 4 x 10 s co khoang nghi ngan: " + (wd - w4) + " (moi doan chan rieng >5 s nen moi doan 1 dump; trong 1 doan khong lap)");
    }

    /* ======================= R: cuu ho tren game thu ======================= */
    static void scnR() throws Exception {
        say("R: muc cuu ho tren game thu (Canvas + TextBox)");
        toGameFocus();
        javax.microedition.lcdui.Displayable cv = curD();
        JMenuItem merge = item("Về menu bản ghép");
        check(merge != null && !merge.isEnabled(), "R 'Về menu bản ghép' bi vo hieu (khong phai jar ghep): enabled=" + (merge != null && merge.isEnabled()));
        String[] it = { "Phím mềm trái (F1)", "Phím mềm phải (F2)", "Phím giữa (Enter)", "Esc / Back" };
        for (String t : it) {
            setD(cv); sleep(300);
            int m = mark(); menu(t); sleep(900);
            List<String> e = since(m);
            check(!e.isEmpty(), "R canvas: '" + t + "' -> " + names(e));
        }
        // trong TextBox: gui phim mem
        say("  mo TextBox (Chat) va thu 'Gui phim' ... ");
        for (String t : it) {
            setD(cv); sleep(300); kTap(KeyEvent.VK_5, '5'); sleep(500);
            String c1 = cur();
            int m = mark(); menu(t); sleep(900);
            List<String> e = since(m);
            say("  TextBox hien (" + c1 + "): '" + t + "' -> " + names(e) + " | man hinh sau=" + cur());
        }
        // ket phim co y: nhet ma phim vao danh sach giu roi gui
        setD(cv); sleep(300);
        try {
            Object im = org.microemu.device.DeviceFactory.getDevice().getInputMethod();
            Field c = im.getClass().getDeclaredField("c"); c.setAccessible(true);
            java.util.List l = (java.util.List) c.get(im);
            synchronized (l) { l.add(112); l.add(113); l.add(10); l.add(27); }
            say("  da lam KET gia lap danh sach giu cua emulator: " + l);
        } catch (Throwable t) { say("khong lam ket duoc: " + t); }
        for (String t : new String[] { "Phím mềm trái (F1)", "Phím giữa (Enter)" }) {
            setD(cv); sleep(300);
            int m = mark(); menu(t); sleep(900);
            List<String> e = since(m);
            check(has(e, "CMD") || has(e, "KEY_P"), "R KET GIA LAP: '" + t + "' van la lan bam moi -> " + names(e));
        }
        // dang ngu: khong lam gi
        call("sleepNow", "gt"); sleep(500);
        int m = mark();
        for (String t : it) { menu(t); sleep(300); }
        sleep(800);
        check(since(m).isEmpty(), "R dang ngu: 4 muc 'Gui phim' khong gui gi: " + names(since(m)));
        call("wake", "gt"); sleep(800);
    }

    /* ======================= R2: cuu ho tren jar ghep ======================= */
    static long copyCpuNs() {
        ThreadMXBean mx = ManagementFactory.getThreadMXBean(); long s = 0;
        for (long id : mx.getAllThreadIds()) { ThreadInfo ti = mx.getThreadInfo(id); if (ti != null && ti.getThreadName().startsWith("MIDletThread")) { long c = mx.getThreadCpuTime(id); if (c > 0) s += c; } }
        return s;
    }
    static void scnR2() throws Exception {
        say("R2: jar ghep: vao ban game, 'Về menu bản ghép', ban game van chay, mo lai tu danh sach");
        click(640, 500); sleep(500); rkey(KeyEvent.VK_ENTER); sleep(4000);
        toGameFocus(); rkey(KeyEvent.VK_ENTER); sleep(9000);                    // chon Hai tac 1 -> vao game
        String inGame = cur();
        say("  dang o: " + inGame);
        check(inGame.contains("[ban 1]") || inGame.contains("onepiece"), "R2 da vao ban game 1: " + inGame);
        try { java.lang.reflect.Method mm = Class.forName("ep3.Rescue").getDeclaredMethod("isMerged"); mm.setAccessible(true); say("  isMerged=" + mm.invoke(null) + " loi=" + fld("ep3.Rescue","lastErr")); } catch (Throwable t) { say("  isMerged loi " + t); }
        JMenuItem merge = item("Về menu bản ghép");
        check(merge != null && merge.isEnabled(), "R2 'Về menu bản ghép' bat (jar ghep): enabled=" + (merge != null && merge.isEnabled()));
        int dl = wd; int fixBefore = countLog("FixGhep");
        long c0 = copyCpuNs(); menu("Về menu bản ghép"); sleep(7000); long c1 = copyCpuNs();
        String menuScr = cur();
        say("  sau 'Về menu bản ghép': " + menuScr + " | CPU luong game trong 7 s: " + (c1 - c0) / 1000000L + " ms");
        check(!menuScr.equals(inGame) && menuScr.contains("List"), "R2 da ve danh sach ghep: " + menuScr);
        check((c1 - c0) > 20000000L, "R2 ban game van chay trong luc hien danh sach (CPU luong MIDletThread tang " + (c1 - c0) / 1000000L + " ms)");
        check(countLog("FixGhep") == fixBefore, "R2 khong co dong [FixGhep] (khong dung/khoi dong lai ban nao)");
        menu("Phím giữa (Enter)"); sleep(5000);
        String back = cur();
        say("  sau 'Phím giữa (Enter)' tren danh sach: " + back);
        check(back.equals(inGame), "R2 chon lai Hai tac 1 tu danh sach -> quay ve CUNG ban dang chay: " + back);
        check(wd == dl, "R2 khong co dump watchdog");
    }
    static Object fld(String c, String n) throws Exception { Field f = Class.forName(c).getDeclaredField(n); f.setAccessible(true); return f.get(null); }
    static int countLog(String s) { String a = ALL.toString(); int n = 0, i = 0; while ((i = a.indexOf(s, i)) >= 0) { n++; i += s.length(); } return n; }

    public static void main(final String[] a) throws Exception {
        System.setProperty("java.awt.headless", "false");
        robot = new Robot(); robot.setAutoDelay(10); hookOut();
        final String scn = System.getProperty("gt.scn", "A");
        Thread t = new Thread(new Runnable() { public void run() {
            try {
                sleep(Long.getLong("gt.start", 14000));
                if (!scn.startsWith("C") && !scn.equals("R2")) bootGame();
                toGameFocus();
                if (scn.equals("A")) scnA(Integer.getInteger("gt.sec", 20), Boolean.getBoolean("gt.repeat"));
                else if (scn.equals("B")) scnB();
                else if (scn.equals("C")) scnC(Integer.getInteger("gt.sec", 60), false);
                else if (scn.equals("CH")) scnC(Integer.getInteger("gt.sec", 60), true);
                else if (scn.equals("W")) scnW();
                else if (scn.equals("R")) scnR();
                else if (scn.equals("R2")) scnR2();
                say("KET THUC " + scn + " fails=" + fails);
                System.out.println(fails == 0 ? "[GT] PASS" : "[GT] FAILED");
            } catch (Throwable e) { say("loi " + e); e.printStackTrace(); }
            sleep(500); System.exit(fails == 0 ? 0 : 1);
        } }, "gt-main");
        t.setDaemon(true); t.start();
        org.microemu.app.Main.main(a);
    }
}
