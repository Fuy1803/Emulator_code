#!/bin/bash
# P7 TEST 5 (hoi quy) tren P7: P5 test 2,3 (ve man ngu 1 lan; thanh trang thai), P4 test 1,2,5, EP1 test 1,2,4 va EP2 (kiem tra proxy). usage: regress_p7.sh OUTDIR RUNDIR(chua 2_t.jar) FIXJAR(2_fix.jar)
F=${1:?}; RUND=${2:?}; FIX=${3:?}; mkdir -p $F
cd "$(dirname "$0")"
P7=${REGJAR:-$(readlink -f ../AngelChipEmulator_V2Proxy_P7.jar)}
pkill -f 'Xvfb :8'; pkill -f 'Xvfb :9'; pkill -f echo.py; sleep 1
OUT=$F/t2p JAR=$P7 GAME=$FIX DUR=${T2DUR:-600} unshare -n bash t2_paint_inner.sh > $F/t2p.out 2>&1
OUT=$F/t3s JAR=$P7 unshare -n bash t3_status_inner.sh > $F/t3s.out 2>&1
OUT=$F/p4t1 JAR=$P7 unshare -n bash t1_wake_inner.sh > $F/p4t1.out 2>&1
OUT=$F/p4t2 JAR=$P7 GAME=$FIX unshare -n bash t2_merged_inner.sh > $F/p4t2.out 2>&1
OUT=$F/p4t5 JAR=$P7 unshare -n bash t5_defaults_inner.sh > $F/p4t5.out 2>&1
echo DONE1 > $F/DONE1
export PJAR=$P7
cd ../../..
for t in t1_mapping t2_windows t4_failures u1_default_dialog u2_tabs_all u3_reasons; do
  RUN=$RUND OUT=$F/ep_$t bash build/ep2/tests/$t.sh > $F/ep_$t.out 2>&1
done
RUN=$RUND OUT=$F/ep_t1_matrix bash build/ep2/tests/t1_matrix.sh > $F/ep_t1_matrix.out 2>&1
echo DONE2 > $F/DONE2
