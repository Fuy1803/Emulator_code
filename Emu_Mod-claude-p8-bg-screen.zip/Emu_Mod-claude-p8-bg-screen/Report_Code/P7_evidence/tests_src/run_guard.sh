#!/bin/bash
# usage: run_guard.sh JAR OUTDIR SCN GAMEJAR [extra -D...]   (env DSP = man hinh xvfb, FPS, AUTO, WAKE, SEC, REPEAT)
JAR=$1; OUT=$2; SCN=$3; GAME=$4; shift 4
HERE="$(cd "$(dirname "$0")" && pwd)"; export JAVA_TOOL_OPTIONS=
mkdir -p $OUT; H=$OUT/home; rm -rf $H; mkdir -p $H/.microemulator
printf "fps=${FPS:-5}\nautosleep=${AUTO:-0}\nwake=${WAKE:-day}\nwatchdog=${WD:-1}\n" > $H/.microemulator/toiuu_m.properties
D=${DSP:-130}
pgrep -f "Xvfb :$D " >/dev/null || { (Xvfb :$D -screen 0 1280x1024x24 >/dev/null 2>&1 &); sleep 2; }
mkdir -p $OUT/cls; javac -encoding UTF-8 -cp $JAR -d $OUT/cls $HERE/GuardTest.java 2>&1 | grep -v Picked
cd $OUT; DISPLAY=:$D timeout ${TMO:-900} java --add-opens java.desktop/java.awt=ALL-UNNAMED -XX:+UseSerialGC -Xss256k -Xmx192m -Duser.home=$H -Dtoiuu.debug=${TDEBUG:-false} -Dgt.scn=$SCN -Dgt.sec=${SEC:-20} -Dgt.repeat=${REPEAT:-false} "$@" -cp $JAR:$OUT/cls GuardTest --proxyProfile m $GAME > gt.log 2>&1
grep -a "^\[GT\]" gt.log
