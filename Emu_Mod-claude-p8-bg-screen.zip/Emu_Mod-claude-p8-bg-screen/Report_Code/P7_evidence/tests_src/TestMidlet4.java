import javax.microedition.lcdui.*;
import javax.microedition.midlet.MIDlet;

/** Game thu 4 (P7): ghi log MOI su kien dau vao toi MIDlet kem gio. Canvas + TextBox (nhu o Chat) + lenh. Phim '5'/FIRE mo TextBox, '9' chan luong su kien 10 s (thu watchdog). */
public class TestMidlet4 extends MIDlet implements CommandListener {
    static volatile int kp, kr, krp, pp, pr, pd, cmd, ticks, typed;
    Display d; Canvas cv; TextBox tb;
    final Command cChat = new Command("Chat", Command.SCREEN, 1), cBack = new Command("Back", Command.BACK, 1), cOk = new Command("OK", Command.OK, 1);

    static void log(String s) { System.out.println("[T4] " + s); }

    class Cv extends Canvas {
        public void paint(Graphics g) { g.setColor(0x103060); g.fillRect(0, 0, getWidth(), getHeight()); g.setColor(0xFFFF00); g.drawString("T4 ticks " + ticks + " kp " + kp, 4, 4, Graphics.TOP | Graphics.LEFT); }
        public void keyPressed(int k) { kp++; log("KEY_P " + k); if (k == Canvas.KEY_NUM5 || getGameAction(k) == FIRE) d.setCurrent(tb); if (k == Canvas.KEY_NUM9) { log("BLOCK event thread 10s"); try { Thread.sleep(10000); } catch (Exception e) { } log("BLOCK end"); } }
        public void keyReleased(int k) { kr++; log("KEY_R " + k); }
        public void keyRepeated(int k) { krp++; log("KEY_RP " + k); }
        public void pointerPressed(int x, int y) { pp++; log("PTR_P " + x + "," + y); }
        public void pointerReleased(int x, int y) { pr++; log("PTR_R " + x + "," + y); }
        public void pointerDragged(int x, int y) { pd++; log("PTR_D " + x + "," + y); }
    }

    public void startApp() {
        d = Display.getDisplay(this);
        cv = new Cv(); cv.addCommand(cChat); cv.setCommandListener(this);
        tb = new TextBox("Chat", "", 50, TextField.ANY); tb.addCommand(cOk); tb.addCommand(cBack); tb.setCommandListener(this);
        d.setCurrent(cv);
        new Thread(new Runnable() { public void run() {
            while (true) {
                ticks++; cv.repaint();
                if (ticks % 10 == 0) log("TICK " + ticks + " cur=" + (d.getCurrent() == cv ? "Canvas" : d.getCurrent() == tb ? "TextBox" : "?") + " kp=" + kp + " kr=" + kr + " krp=" + krp + " pp=" + pp + " pr=" + pr + " pd=" + pd + " cmd=" + cmd + " txt=" + tb.getString().length());
                try { Thread.sleep(100); } catch (InterruptedException e) { return; }
            }
        } }, "t4-ticks").start();
    }
    public void commandAction(Command c, Displayable s) {
        cmd++; log("CMD " + c.getLabel() + " on " + (s == cv ? "Canvas" : "TextBox"));
        if (c == cChat) d.setCurrent(tb); else if (c == cBack || c == cOk) d.setCurrent(cv);
    }
    public void pauseApp() { }
    public void destroyApp(boolean u) { }
}
