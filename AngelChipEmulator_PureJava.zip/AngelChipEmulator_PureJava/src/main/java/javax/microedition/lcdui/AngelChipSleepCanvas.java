package javax.microedition.lcdui;

/**
 * Man hinh ngu cu cua menu "AngelChip -> Che do tu ngu" (thay the lop a.class bi roi ma).
 * Bam phim hoac cham man hinh se quay lai dung Displayable truoc do.
 */
final class AngelChipSleepCanvas extends Canvas {
    private final Display display;
    private final Displayable previous;

    AngelChipSleepCanvas(Display display, Displayable previous) {
        this.display = display;
        this.previous = previous;
        setFullScreenMode(true);
    }

    protected void paint(Graphics g) {
        int w = getWidth();
        int h = getHeight();
        g.setColor(0x000000);
        g.fillRect(0, 0, w, h);
        g.setColor(0xFFFFFF);
        g.drawString("...", w / 2, h / 2, Graphics.HCENTER | Graphics.BASELINE);
    }

    private void wakeUp() {
        Displayable.touchActivity();
        if (display != null && previous != null) {
            display.setCurrent(previous);
        }
    }

    protected void keyPressed(int keyCode) {
        wakeUp();
    }

    protected void pointerPressed(int x, int y) {
        wakeUp();
    }
}
