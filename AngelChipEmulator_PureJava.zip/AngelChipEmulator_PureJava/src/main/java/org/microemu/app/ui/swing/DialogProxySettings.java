package org.microemu.app.ui.swing;

import java.awt.*;
import javax.swing.*;
import ep1.ProxyCheck;
import ep1.ProxySettings;
import ep1.ProxyTabs;

/** Hop thoai "Cai dat Proxy": chi sua MAC DINH cua profile cua cua so nay (SOCKS5). */
public class DialogProxySettings extends SwingDialogPanel {
    private final boolean has = ProxyTabs.hasProfile();
    private final JCheckBox enable = new JCheckBox("Bật sử dụng Proxy (mặc định của cửa sổ này)", false);
    private final JTextField host = new JTextField(20);
    private final JTextField port = new JTextField(20);
    private final JTextField user = new JTextField(20);
    private final JPasswordField pass = new JPasswordField(20);
    private final ProxySettings s;
    private final JLabel res = new JLabel(" ");
    private final JLabel tgt = new JLabel(" ");
    private static final Color GREEN = new Color(0, 140, 0), RED = new Color(200, 0, 0);

    /** Kiem tra proxy DANG GO trong cac o (khong can luu), chay nen. */
    private void doCheck(final JButton b) {
        final String h = host.getText().trim(), u = user.getText().trim(), pw = new String(pass.getPassword());
        int pn;
        try { pn = Integer.parseInt(port.getText().trim()); } catch (Exception e) { pn = -1; }
        if (h.length() == 0 || pn < 1 || pn > 65535) { res.setForeground(RED); res.setText("Nhập Host và Port hợp lệ trước"); return; }
        final int p = pn;
        final String[] tg = ProxyCheck.target();
        tgt.setText("Đích kiểm tra: " + ProxyCheck.targetText());
        b.setEnabled(false);
        res.setForeground(Color.gray); res.setText("Đang kiểm tra...");
        Thread t = new Thread(() -> {
            final ProxyCheck.Result r = ProxyCheck.checkAndLog("mac dinh", h, p, u, pw, tg);
            SwingUtilities.invokeLater(() -> { res.setForeground(r.alive ? GREEN : RED); res.setText(r.text()); b.setEnabled(true); });
        }, "ProxyCheck");
        t.setDaemon(true);
        t.start();
    }

    public DialogProxySettings() {
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(2, 4, 2, 4);
        c.gridx = 0; c.gridy = 0; c.gridwidth = 2;
        if (!has) {
            s = null;
            JLabel l = new JLabel(ProxyTabs.NO_PROFILE_TEXT);
            l.setForeground(Color.red);
            add(l, c);
            c.gridy = 1;
            add(new JLabel("Không có profile thì proxy TẮT cho mọi tab."), c);
            btOk.setEnabled(false);
            return;
        }
        s = ProxyTabs.snapshot();
        JLabel w = new JLabel("(*) Lưu ý: chỉ hỗ trợ SOCKS5 Proxy!");
        w.setFont(new Font("Default", Font.BOLD, 12));
        w.setForeground(Color.red);
        add(w, c);
        c.gridy = 1;
        add(new JLabel("Profile: " + ProxyTabs.profileName() + "   (file " + ProxyTabs.profileFile().getName() + ")"), c);
        c.gridwidth = 1;
        row(c, 2, "Proxy Host:", host);
        row(c, 3, "Proxy Port:", port);
        row(c, 4, "Proxy User:", user);
        row(c, 5, "Proxy Password:", pass);
        c.gridx = 0; c.gridy = 6; c.gridwidth = 2;
        add(enable, c);
        c.gridy = 7;
        add(new JLabel("Dùng cho các tab chọn \"Mặc định\" (xem \"Proxy cho từng tab\"). Áp dụng cho kết nối kế tiếp."), c);
        c.gridwidth = 1; c.gridx = 0; c.gridy = 8;
        JButton chk = new JButton("Kiểm tra");
        add(chk, c);
        c.gridx = 1;
        add(res, c);
        c.gridx = 0; c.gridy = 9; c.gridwidth = 2;
        add(tgt, c);
        res.setPreferredSize(new Dimension(300, 20));
        tgt.setText("Đích kiểm tra: " + ProxyCheck.targetText());
        chk.addActionListener(e -> doCheck(chk));
        enable.setSelected(s.def.enabled);
        host.setText(s.def.host);
        port.setText(s.def.port > 0 ? String.valueOf(s.def.port) : "");
        user.setText(s.def.user);
        pass.setText(s.def.pass);
    }

    private void row(GridBagConstraints c, int y, String label, JComponent f) {
        c.gridx = 0; c.gridy = y;
        add(new JLabel(label), c);
        c.gridx = 1;
        add(f, c);
    }

    public boolean check(boolean ok) {
        if (!ok || !has) return true;
        String p = port.getText().trim();
        boolean bad = false;
        if (enable.isSelected()) {
            if (host.getText().trim().length() == 0) bad = true;
            try { int n = Integer.parseInt(p); if (n < 1 || n > 65535) bad = true; } catch (Exception e) { bad = true; }
        } else if (p.length() > 0) {
            try { int n = Integer.parseInt(p); if (n < 1 || n > 65535) bad = true; } catch (Exception e) { bad = true; }
        }
        if (bad) JOptionPane.showMessageDialog(this, "Host trống hoặc Port không hợp lệ (1-65535).");
        return !bad;
    }

    /** Luu; tra ve true neu da luu. */
    public boolean updateProxy() {
        if (!has) return false;
        ProxySettings n = s.copy();
        n.def.enabled = enable.isSelected();
        n.def.host = host.getText().trim();
        int pn = -1;
        try { pn = Integer.parseInt(port.getText().trim()); } catch (Exception e) { pn = -1; }
        n.def.port = pn;
        n.def.user = user.getText().trim();
        n.def.pass = new String(pass.getPassword());
        try {
            ProxyTabs.apply(n);
            return true;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Không lưu được: " + e.getMessage());
            return false;
        }
    }
}
