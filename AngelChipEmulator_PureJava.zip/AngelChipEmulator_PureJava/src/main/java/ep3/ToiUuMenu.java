package ep3;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.SwingUtilities;
import javax.swing.JMenuItem;
import javax.swing.JRadioButtonMenuItem;

/** Menu "Tối ưu" (cạnh "AngelChip"). */
public final class ToiUuMenu {
    private ToiUuMenu() {}

    public static JMenu create(JFrame frame) {
        ToiUu.init(frame);
        JMenu m = new JMenu("Tối ưu");
        JMenuItem ngu = new JMenuItem("Ngủ ngay");
        ngu.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { ToiUu.sleepNow("menu"); } });
        JMenuItem day = new JMenuItem("Dậy");
        day.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { ToiUu.wake("menu"); } });
        m.add(ngu);
        m.add(day);
        m.addSeparator();

        JMenu auto = new JMenu("Tự ngủ sau");
        ButtonGroup g1 = new ButtonGroup();
        for (int i = 0; i < ToiUu.AUTO_CHOICES.length; i++) {
            final int v = ToiUu.AUTO_CHOICES[i];
            JRadioButtonMenuItem it = new JRadioButtonMenuItem(v == 0 ? "Không" : v + " phút không thao tác", v == ToiUu.autoMin);
            it.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { ToiUu.setAutoSleep(v); } });
            g1.add(it);
            auto.add(it);
        }
        m.add(auto);

        JMenu fps = new JMenu("Giới hạn hình/giây");
        ButtonGroup g2 = new ButtonGroup();
        for (int i = 0; i < ToiUu.FPS_CHOICES.length; i++) {
            final int v = ToiUu.FPS_CHOICES[i];
            JRadioButtonMenuItem it = new JRadioButtonMenuItem(v == 0 ? "Không giới hạn" : v + " hình/giây", v == ToiUu.fps);
            it.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { ToiUu.setFps(v); } });
            g2.add(it);
            fps.add(it);
        }
        m.add(fps);

        JMenu wake = new JMenu("Cách đánh thức");
        ButtonGroup g3 = new ButtonGroup();
        JRadioButtonMenuItem w1 = new JRadioButtonMenuItem("Chạm là dậy", ToiUu.WAKE_TOUCH.equals(ToiUu.wakeMode));
        w1.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { ToiUu.setWakeMode(ToiUu.WAKE_TOUCH); } });
        JRadioButtonMenuItem w2 = new JRadioButtonMenuItem("Chỉ bấm Dậy", ToiUu.WAKE_MENU.equals(ToiUu.wakeMode));
        w2.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { ToiUu.setWakeMode(ToiUu.WAKE_MENU); } });
        g3.add(w1); g3.add(w2); wake.add(w1); wake.add(w2);
        m.add(wake);

        final JCheckBoxMenuItem cb = new JCheckBoxMenuItem("Hiện CPU/RAM", ToiUu.showInfo);
        cb.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { ToiUu.setShowInfo(cb.isSelected()); } });
        m.add(cb);
        final JCheckBoxMenuItem wd = new JCheckBoxMenuItem("Ghi log khi đơ", ToiUu.watchdog);
        wd.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { ToiUu.setWatchdog(wd.isSelected()); } });
        m.add(wd);
        final JCheckBoxMenuItem rb = new JCheckBoxMenuItem("Nhả phím khi mất tiêu điểm", ToiUu.releaseOnBlur);
        rb.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { ToiUu.setReleaseOnBlur(rb.isSelected()); } });
        m.add(rb);
        m.addSeparator();
        // P7: muc cuu ho (luon bam duoc tu thanh menu)
        final JMenuItem merge = new JMenuItem("Về menu bản ghép");
        mergeItem = merge;
        merge.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { Rescue.goMenu(); } });
        m.add(merge);
        JMenu keys = new JMenu("Gửi phím");
        keys.add(keyItem("Phím mềm trái (F1)", java.awt.event.KeyEvent.VK_F1, "phim mem trai"));
        keys.add(keyItem("Phím mềm phải (F2)", java.awt.event.KeyEvent.VK_F2, "phim mem phai"));
        keys.add(keyItem("Phím giữa (Enter)", java.awt.event.KeyEvent.VK_ENTER, "phim giua"));
        keys.add(keyItem("Esc / Back", java.awt.event.KeyEvent.VK_ESCAPE, "esc"));
        keys.addSeparator();
        JMenuItem rel = new JMenuItem("Nhả mọi phím (gỡ kẹt)");
        rel.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { Rescue.releaseAllKeys(); } });
        keys.add(rel);
        m.add(keys);
        m.addMenuListener(new javax.swing.event.MenuListener() {
            public void menuSelected(javax.swing.event.MenuEvent e) { merge.setEnabled(Rescue.isMerged()); }
            public void menuDeselected(javax.swing.event.MenuEvent e) { }
            public void menuCanceled(javax.swing.event.MenuEvent e) { }
        });
        merge.setEnabled(Rescue.isMerged());
        m.addSeparator();
        JMenuItem info = new JMenuItem(ToiUu.hasProfile() ? "Profile: " + ToiUu.profileName() + " (lưu tự động)"
                : "Chưa có profile (thêm --proxyProfile vào file .bat): không lưu");
        info.setEnabled(false);
        m.add(info);
        return m;
    }

    static volatile JMenuItem mergeItem;

    /** Goi tu tick 5 s: bat/tat muc "Ve menu ban ghep" theo jar hien tai (jar thuong -> tat). */
    static void refresh() {
        final JMenuItem it = mergeItem;
        if (it == null) return;
        final boolean on = Rescue.isMerged();
        if (it.isEnabled() != on) SwingUtilities.invokeLater(new Runnable() { public void run() { it.setEnabled(on); } });
    }

    private static JMenuItem keyItem(String text, final int vk, final String name) {
        JMenuItem it = new JMenuItem(text);
        it.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { Rescue.sendKey(vk, name); } });
        return it;
    }
}
