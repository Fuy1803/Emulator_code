package ep3;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * Bo ghi log loi sieu nhe cho VPS theo tung tab (0 = He thong, 1..5 = Tab 1..5).
 * - Chi ghi khi co LOI / CANH BAO (khong ghi rac luc game chay binh thuong -> ~0% CPU).
 * - Bo dem vong co dinh MAX_PER_BUCKET dong/nhom -> RAM luon duoi ~200 KB du treo 24/7.
 * - Khong tao luong nen, khong ve Swing khi hop thoai dang dong.
 */
public final class TabErrorLog {
    public static final int MAX_TABS = 5;
    private static final int MAX_PER_BUCKET = 200;
    private static final int MAX_ALL = 400;

    private static final Object LOCK = new Object();
    @SuppressWarnings("unchecked")
    private static final LinkedList<String>[] BUCKETS = new LinkedList[MAX_TABS + 1];
    private static final LinkedList<String> ALL = new LinkedList<String>();
    private static int totalRecorded;
    private static volatile Runnable activeListener;
    private static volatile boolean handlerInstalled;

    static {
        for (int i = 0; i <= MAX_TABS; i++) {
            BUCKETS[i] = new LinkedList<String>();
        }
    }

    private TabErrorLog() {}

    /** Gan bo bat ngoai le chua xu ly tren cac luong game (goi 1 lan khi khoi dong). */
    public static synchronized void install() {
        if (handlerInstalled) return;
        handlerInstalled = true;
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            public void uncaughtException(Thread t, Throwable e) {
                try {
                    int tab = detectTabFromThrowable(e);
                    StringBuilder sb = new StringBuilder();
                    sb.append("[Loi luong ").append(t == null ? "?" : t.getName()).append("] ")
                      .append(e.getClass().getSimpleName()).append(": ").append(e.getMessage());
                    StackTraceElement[] st = e.getStackTrace();
                    if (st != null && st.length > 0) {
                        sb.append(" @ ").append(st[0].getClassName()).append('.').append(st[0].getMethodName())
                          .append(':').append(st[0].getLineNumber());
                    }
                    record(tab, sb.toString());
                } catch (Throwable ignore) {}
                if (prev != null) {
                    prev.uncaughtException(t, e);
                } else {
                    e.printStackTrace();
                }
            }
        });
    }

    private static int detectTabFromThrowable(Throwable e) {
        if (e != null) {
            StackTraceElement[] st = e.getStackTrace();
            if (st != null) {
                for (int i = 0; i < st.length; i++) {
                    String cn = st[i].getClassName();
                    if (cn.startsWith("b.")) return 2;
                    if (cn.startsWith("c.")) return 3;
                    if (cn.startsWith("d.")) return 4;
                    if (cn.startsWith("e.")) return 5;
                    if (cn.indexOf('.') < 0 && !cn.startsWith("ep")) return 1;
                }
            }
        }
        try {
            return ep1.ProxyTabs.detectTab();
        } catch (Throwable ignore) {
            return 0;
        }
    }

    /** Ghi 1 dong loi/canh bao vao dung tab (0 = He thong, 1..5 = Tab 1..5). */
    public static void record(int tab, String message) {
        if (message == null || message.length() == 0) return;
        int idx = (tab >= 1 && tab <= MAX_TABS) ? tab : 0;
        String ts = new SimpleDateFormat("HH:mm:ss").format(new Date());
        String tag = idx == 0 ? "[He thong]" : "[Tab " + idx + "]";
        String line = "[" + ts + "] " + tag + " " + message;
        Runnable cb;
        synchronized (LOCK) {
            LinkedList<String> q = BUCKETS[idx];
            if (q.size() >= MAX_PER_BUCKET) q.removeFirst();
            q.addLast(line);
            if (ALL.size() >= MAX_ALL) ALL.removeFirst();
            ALL.addLast(line);
            totalRecorded++;
            cb = activeListener;
        }
        if (cb != null) {
            try { cb.run(); } catch (Throwable ignore) {}
        }
    }

    public static int totalCount() {
        synchronized (LOCK) { return ALL.size(); }
    }

    public static int count(int tab) {
        int idx = (tab >= 1 && tab <= MAX_TABS) ? tab : 0;
        synchronized (LOCK) { return BUCKETS[idx].size(); }
    }

    /** Lay noi dung log: tab = -1 la Tat ca, 0 la He thong, 1..5 la Tab 1..5. */
    public static String getText(int tab) {
        List<String> copy;
        synchronized (LOCK) {
            if (tab < 0) copy = new ArrayList<String>(ALL);
            else {
                int idx = (tab >= 1 && tab <= MAX_TABS) ? tab : 0;
                copy = new ArrayList<String>(BUCKETS[idx]);
            }
        }
        if (copy.isEmpty()) return "(Chưa ghi nhận lỗi nào)";
        StringBuilder sb = new StringBuilder(copy.size() * 80);
        for (int i = 0; i < copy.size(); i++) {
            if (i > 0) sb.append('\n');
            sb.append(copy.get(i));
        }
        return sb.toString();
    }

    /** Xoa log: tab = -1 la xoa tat ca; 0..5 la xoa rieng nhom do. */
    public static void clear(int tab) {
        Runnable cb;
        synchronized (LOCK) {
            if (tab < 0) {
                ALL.clear();
                for (int i = 0; i <= MAX_TABS; i++) BUCKETS[i].clear();
            } else {
                int idx = (tab >= 1 && tab <= MAX_TABS) ? tab : 0;
                BUCKETS[idx].clear();
                String prefix = idx == 0 ? "] [He thong] " : "] [Tab " + idx + "] ";
                java.util.Iterator<String> it = ALL.iterator();
                while (it.hasNext()) {
                    if (it.next().indexOf(prefix) >= 0) it.remove();
                }
            }
            cb = activeListener;
        }
        if (cb != null) {
            try { cb.run(); } catch (Throwable ignore) {}
        }
    }

    static void setActiveListener(Runnable r) {
        synchronized (LOCK) { activeListener = r; }
    }
}
