package ep3;

import java.awt.Component;
import java.awt.Container;
import java.awt.event.KeyEvent;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.midlet.MIDlet;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import org.microemu.MIDletBridge;

/** P7: muc cuu ho tren thanh menu (luon bam duoc, khong phu thuoc tieu diem Swing). */
final class Rescue {
    private Rescue() {}

    /* ---------------------------------------------------------- Ve menu ban ghep */

    static volatile String lastErr;

    private static Object mergeControl() {
        try {
            MIDlet m = MIDletBridge.getCurrentMIDlet();
            if (m == null) return null;
            ClassLoader cl = m.getClass().getClassLoader();
            Class<?> c = Class.forName("lib.Display", true, cl);
            Object mc = c.getField("mc").get(null);
            lastErr = mc == null ? "lib.Display.mc = null" : null;
            return mc;
        } catch (Throwable t) { lastErr = String.valueOf(t); return null; }
    }

    /** true neu day la jar ghep (co lop lib.Display.mc cua EmbedAdvMenu). */
    static boolean isMerged() { return mergeControl() != null; }

    /** Giong nhan phim "Menu" cua ban ghep: MidControl.pause() (luu man hinh hien tai, hien danh sach). Khong dung/khoi dong lai game nao. */
    static void goMenu() {
        if (ToiUu.asleep) { ToiUu.log("ve menu ban ghep: dang ngu - bam Day truoc"); return; }
        Thread t = new Thread(new Runnable() { public void run() {
            try {
                Object mc = mergeControl();
                if (mc == null) { ToiUu.log("ve menu ban ghep: khong phai jar ghep (" + lastErr + ")"); return; }
                MIDlet m = MIDletBridge.getCurrentMIDlet();
                Displayable cur = Display.getDisplay(m).getCurrent();
                // dang o danh sach ban ghep roi thi thoi (de khong ghi de man hinh "da luu" cua ban ghep)
                if (isMergeList(mc, cur)) { ToiUu.log("ve menu ban ghep: dang o danh sach roi"); return; }
                String before = InputGuard.describe(cur);
                mc.getClass().getMethod("pause").invoke(mc);
                ToiUu.log("ve menu ban ghep: da goi MidControl.pause() (tu " + before + ")");
                ToiUu.forceRepaint("ve menu ban ghep");
            } catch (Throwable e) { ToiUu.log("ve menu ban ghep: loi " + e); }
        } }, "ToiUu-rescue");
        t.setDaemon(true);
        t.start();
    }

    private static boolean isMergeList(Object mc, Displayable cur) {
        if (cur == null) return false;
        try {
            for (Field f : mc.getClass().getDeclaredFields()) {
                if (!java.lang.reflect.Modifier.isStatic(f.getModifiers()) || f.getType() != javax.microedition.lcdui.List.class) continue;
                f.setAccessible(true);
                if (f.get(null) == cur) return true;
            }
        } catch (Throwable t) { /* coi nhu chua o danh sach */ }
        return false;
    }

    /* ---------------------------------------------------------- Gui phim */

    private static Component findDevice(Component c) {
        if (c.getClass().getName().endsWith("SwingDeviceComponent")) return c;
        if (c instanceof Container) for (Component k : ((Container) c).getComponents()) { Component r = findDevice(k); if (r != null) return r; }
        return null;
    }

    /** Gui 1 lan bam + nha toi game dang hien, qua CUNG duong phim that (SwingDeviceComponent.keyPressed/keyReleased -> J2SEInputMethod),
     *  khong can tieu diem Swing. Truoc do nha moi phim dang giu va xoa trang thai ket de lan bam chac chan la lan bam moi. Khong lam gi khi ngu. */
    static void sendKey(final int vk, final String name) {
        if (ToiUu.asleep) { ToiUu.log("gui phim " + name + ": dang ngu - khong gui"); return; }
        Thread t = new Thread(new Runnable() { public void run() {
            try {
                JFrame f = ToiUu.frameRef();
                Component dev = f == null ? null : findDevice(f);
                if (dev == null) { ToiUu.log("gui phim " + name + ": khong thay SwingDeviceComponent"); return; }
                InputGuard.releaseAll();
                final KeyEvent p = new KeyEvent(dev, KeyEvent.KEY_PRESSED, System.currentTimeMillis(), 0, vk, KeyEvent.CHAR_UNDEFINED);
                final KeyEvent r = new KeyEvent(dev, KeyEvent.KEY_RELEASED, System.currentTimeMillis() + 60, 0, vk, KeyEvent.CHAR_UNDEFINED);
                final Object d = dev;
                final Method kp = dev.getClass().getMethod("keyPressed", KeyEvent.class), kr = dev.getClass().getMethod("keyReleased", KeyEvent.class);
                SwingUtilities.invokeLater(new Runnable() { public void run() { try { kp.invoke(d, p); } catch (Throwable e) { ToiUu.log("gui phim loi " + e); } } });
                Thread.sleep(60);
                SwingUtilities.invokeLater(new Runnable() { public void run() { try { kr.invoke(d, r); } catch (Throwable e) { ToiUu.log("gui phim loi " + e); } } });
                ToiUu.log("gui phim " + name + " (VK=" + vk + ") xong");
            } catch (Throwable e) { ToiUu.log("gui phim " + name + ": loi " + e); }
        } }, "ToiUu-rescue");
        t.setDaemon(true);
        t.start();
    }

    static void releaseAllKeys() {
        Thread t = new Thread(new Runnable() { public void run() { ToiUu.log("nha moi phim (go ket): " + InputGuard.releaseAll()); } }, "ToiUu-rescue");
        t.setDaemon(true);
        t.start();
    }
}
