package ep3;

import java.awt.AWTEvent;
import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.FontMetrics;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.management.ManagementFactory;
import java.lang.reflect.Method;
import java.util.Properties;
import java.util.Timer;
import java.util.TimerTask;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.midlet.MIDlet;
import javax.swing.JFrame;
import javax.swing.MenuElement;
import javax.swing.SwingUtilities;
import org.microemu.MIDletBridge;

/**
 * Menu "Toi uu" (P4): ngu TOAN CUA SO (cac ban game cua jar ghep), tu ngu, gioi han hinh/giay, khong ve khi thu nho,
 * cach danh thuc, man hinh ngu co dong ho + CPU/RAM. Cai dat theo cua so (profile).
 * Ngu = co cap cua so: bo qua moi lan ve cua moi ban game va ve man hinh ngu ngay trong paintComponent; KHONG doi man hinh cua game
 * (nen doi tab / "Dung ung dung" / hop thoai game / doi kich thuoc khong lam cua so tu day). Khong chan luong game.
 */
public final class ToiUu {
    static final int[] FPS_CHOICES = { 0, 15, 10, 5, 2 };
    static final int[] AUTO_CHOICES = { 0, 1, 5, 15 };
    static final int DEFAULT_FPS = 5, DEFAULT_AUTO = 5;
    public static final String WAKE_TOUCH = "cham", WAKE_MENU = "day";

    static volatile int fps = DEFAULT_FPS;            // 0 = khong gioi han
    static volatile int autoMin = DEFAULT_AUTO;       // 0 = khong tu ngu
    static volatile boolean showInfo = true;          // "Hien CPU/RAM": mac dinh BAT
    static volatile boolean releaseOnBlur = true;     // P8: "Nha phim khi mat tieu diem": mac dinh BAT
    static volatile boolean watchdog = true;          // P7: "Ghi log khi do": mac dinh BAT
    static volatile String wakeMode = WAKE_MENU;      // cham = cham la day; day = chi bam Day
    static volatile boolean asleep;
    static volatile long sleepSince;                  // nano
    static volatile long lastHuman = System.currentTimeMillis();
    /** CHI DE THU (Driver): cho phep chuot/phim cua nguoi di vao game khi dang ngu, de dieu khien menu hop nhat khi ngu. Mac dinh false, san pham khong dat. */
    static volatile boolean testPass;
    private static volatile long swallowUntil;        // nano: nuot not su kien sau khi cham de day
    private static volatile long lastPaint;           // nano
    private static volatile JFrame frame;
    private static volatile Component displayComp;
    private static volatile boolean hiddenLogged;
    /** P6: yeu cau ve gop thanh DUNG 1 yeu cau cho (CAS, khong khoa). deferDue = nano luc hen ve bu; qua han ma chua chay => hen lai (timer chet/huy khong lam ket co). */
    private static final java.util.concurrent.atomic.AtomicBoolean deferredPending = new java.util.concurrent.atomic.AtomicBoolean();
    private static volatile long deferDue;
    /** P6: co mot yeu cau ve da bi bo qua (ngu/an/gioi han) ma chua duoc ve bu: lan ve sau cung khong bao gio duoc mat. */
    private static volatile boolean owedRepaint;
    private static volatile long owedSince;
    private static volatile boolean hiddenNow;           // P6: cache trang thai an/thu nho (cap nhat boi listener + tick), skip() khong goi Swing
    private static volatile Timer timer;
    private static final Object TIMER_LOCK = new Object();   // chi bao ve tao/huy Timer, khong bao gio giu khi goi code khac
    private static final Object IO_LOCK = new Object();      // chi bao ve ghi file
    private static boolean initDone;
    private static File file;
    private static String profile;
    private static final boolean DEBUG = Boolean.getBoolean("toiuu.debug");
    private static volatile long statPainted, statSkipped;
    private static final int[] gamePaints = new int[7];      // [0]=khac, [1..5]=Hai tac 1..5 (chi khi -Dtoiuu.debug=true)

    // so lieu CPU/RAM
    private static volatile int sleepPaints;                 // so lan ve man hinh ngu (chi de kiem thu, in khi -Dtoiuu.debug=true)
    private static Object osBean;
    private static Method mCpuTime, mCommit;
    private static long lastCpuNs = -1, lastWallNs;

    private ToiUu() {}

    static void log(String m) { System.out.println("[ToiUu] " + m); System.out.flush(); }

    public static boolean hasProfile() { return profile != null; }
    public static String profileName() { return profile; }
    public static boolean isSleeping() { return asleep; }
    /** Goi tu Display.repaint: dang ngu thi khong xep yeu cau ve vao hang doi (giam CPU; serviceRepaints khong cho vi khong co PaintEvent). */
    public static boolean sleepingNow() { return asleep; }

    /** Goi 1 lan khi dung menu (Main constructor). */
    static void init(JFrame f) {
        synchronized (IO_LOCK) { if (initDone) return; initDone = true; }
        frame = f;
        try { profile = ep1.ProxyTabs.profileName(); } catch (Throwable t) { profile = null; }
        if (profile != null) {
            file = new File(new File(System.getProperty("user.home"), ".microemulator"), "toiuu_" + profile + ".properties");
            load();
            log("profile=" + profile + " file=" + file.getPath() + " " + describe());
        } else {
            log("chua co profile -> mac dinh (" + describe() + "), khong luu");
        }
        try { Toolkit.getDefaultToolkit().getSystemEventQueue().push(new Gate()); }
        catch (Throwable t) { log("khong gan duoc bo loc chuot/phim: " + t); }
        f.addWindowStateListener(new WindowAdapter() {
            public void windowStateChanged(WindowEvent e) { stateChanged(); }
        });
        f.addWindowListener(new WindowAdapter() {
            public void windowDeiconified(WindowEvent e) { stateChanged(); }
        });
        f.addComponentListener(new ComponentAdapter() {
            public void componentShown(ComponentEvent e) { stateChanged(); }
            public void componentHidden(ComponentEvent e) { stateChanged(); }
            public void componentResized(ComponentEvent e) { forceRepaint("doi kich thuoc"); }
            public void componentMoved(ComponentEvent e) { }
        });
        f.addWindowFocusListener(new WindowAdapter() {
            public void windowGainedFocus(WindowEvent e) { forceRepaint("lay tieu diem"); }
            public void windowLostFocus(WindowEvent e) { onFocusLost("windowLostFocus"); }
        });
        f.addWindowListener(new WindowAdapter() {
            public void windowActivated(WindowEvent e) { forceRepaint("kich hoat"); }
            public void windowDeactivated(WindowEvent e) { onFocusLost("windowDeactivated"); }
        });
        syncTimer();
        Watchdog.sync(watchdog);
    }

    private static String describe() {
        return "tu ngu=" + (autoMin == 0 ? "khong" : autoMin + " phut") + " fps=" + (fps == 0 ? "khong gioi han" : String.valueOf(fps))
                + " danh thuc=" + (WAKE_TOUCH.equals(wakeMode) ? "cham la day" : "chi bam Day") + " hien cpu/ram=" + (showInfo ? "bat" : "tat") + " ghi-log-khi-do=" + (watchdog ? "bat" : "tat") + " nha-phim-khi-mat-tieu-diem=" + (releaseOnBlur ? "bat" : "tat");
    }

    private static void load() {
        try {
            if (!file.isFile()) return;     // chua co file: giu mac dinh
            Properties p = new Properties();
            InputStream in = new FileInputStream(file);
            try { p.load(in); } finally { in.close(); }
            fps = pick(p.getProperty("fps"), FPS_CHOICES, DEFAULT_FPS);
            autoMin = pick(p.getProperty("autosleep"), AUTO_CHOICES, DEFAULT_AUTO);
            String w = p.getProperty("wake");
            wakeMode = WAKE_TOUCH.equals(w) ? WAKE_TOUCH : WAKE_MENU;
            String si = p.getProperty("showinfo");
            showInfo = si == null || !"0".equals(si.trim());
            String wd = p.getProperty("watchdog");
            watchdog = wd == null || !"0".equals(wd.trim());
            String rb = p.getProperty("releaseonblur");
            releaseOnBlur = rb == null || !"0".equals(rb.trim());
        } catch (Throwable t) { log("loi doc " + file.getName() + ": " + t + " (dung mac dinh)"); }
    }

    private static int pick(String v, int[] ok, int def) {
        if (v == null) return def;                       // thieu khoa -> mac dinh; "0" da luu thi giu 0
        try { int n = Integer.parseInt(v.trim()); for (int i = 0; i < ok.length; i++) if (ok[i] == n) return n; } catch (Throwable t) { /* mac dinh */ }
        return def;
    }

    private static void save() {
        if (file == null) return;
        synchronized (IO_LOCK) { saveLocked(); }
    }

    private static void saveLocked() {
        try {
            Properties p = new Properties();
            p.setProperty("version", "3");
            p.setProperty("showinfo", showInfo ? "1" : "0");
            p.setProperty("watchdog", watchdog ? "1" : "0");
            p.setProperty("releaseonblur", releaseOnBlur ? "1" : "0");
            p.setProperty("autosleep", String.valueOf(autoMin));
            p.setProperty("fps", String.valueOf(fps));
            p.setProperty("wake", wakeMode);
            File dir = file.getParentFile();
            if (dir != null && !dir.isDirectory()) dir.mkdirs();
            File tmp = new File(file.getPath() + ".tmp");
            OutputStream out = new FileOutputStream(tmp);
            try { p.store(out, "AngelChip Toi uu (theo cua so/profile)"); } finally { out.close(); }
            java.nio.file.Files.move(tmp.toPath(), file.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        } catch (Throwable t) { log("loi ghi " + file.getName() + ": " + t); }
    }

    /* ------------------------------------------------------------ cai dat (menu) */

    static void setFps(int v) {
        fps = v; lastPaint = 0;
        log("fps=" + (v == 0 ? "khong" : String.valueOf(v)));
        save();
        syncTimer();
        requestFullRepaint();
    }

    static void setAutoSleep(int minutes) {
        autoMin = minutes; lastHuman = System.currentTimeMillis();
        log("tu ngu " + (minutes == 0 ? "khong" : minutes + " phut"));
        save();
        syncTimer();
    }

    static void setReleaseOnBlur(boolean on) {
        releaseOnBlur = on;
        log("nha phim khi mat tieu diem: " + (on ? "bat" : "tat"));
        save();
    }

    /** P8: cua so mat tieu diem / bi vo hieu (RDP ngat, doi cua so...): nha moi phim/chuot game dang coi la giu (khong lam gi khi ngu - luc ngu da nha rieng). */
    static void onFocusLost(String why) {
        if (!releaseOnBlur || asleep) return;
        try {
            String r = InputGuard.releaseAll();
            if (InputGuard.lastReleased > 0 || InputGuard.lastHadImKeys) log("mat tieu diem (" + why + "): nha phim ket: " + r);
        } catch (Throwable t) { /* khong bao gio lam hong luong su kien */ }
    }

    static void setWatchdog(boolean on) {
        watchdog = on;
        log("ghi log khi do: " + (on ? "bat" : "tat"));
        Watchdog.reset();
        Watchdog.sync(on);
        save();
        syncTimer();
    }

    static void setShowInfo(boolean on) {
        showInfo = on;
        log("hien cpu/ram: " + (on ? "bat" : "tat"));
        save();
        syncTimer();
        if (!on) status(asleep ? "Đang ngủ" : "");
    }

    static void setWakeMode(String m) {
        wakeMode = m;
        log("cach danh thuc: " + (WAKE_TOUCH.equals(m) ? "cham la day" : "chi bam Day"));
        save();
    }

    /* ------------------------------------------------------------ ngu / day (toan cua so) */

    /** Doi trang thai ngu/day: MOT co duy nhat (asleep) doi nguyen tu bang CAS, moi viec phu (log, thanh trang thai, ve) lam NGOAI khoa. */
    private static final java.util.concurrent.atomic.AtomicBoolean SLEEP = new java.util.concurrent.atomic.AtomicBoolean();

    public static void sleepNow(String why) {
        if (!SLEEP.compareAndSet(false, true)) return;
        sleepSince = System.nanoTime();
        sleepPaints = 0;
        asleep = true;
        log("ngu (" + why + ")");
        String guard = InputGuard.onSleep();                 // P7: nha phim/chuot dang giu, xoa trang thai nhan phim; chan moi dau vao
        log("ngu: man hinh hien tai=" + currentDescribe() + " | " + guard);
        if (showInfo) infoTick(); else status("Đang ngủ");
        repaintDisplay();            // ve man hinh ngu DUNG 1 LAN
    }

    public static void wake(String why) {
        if (!SLEEP.compareAndSet(true, false)) return;
        String counters = InputGuard.onWake();               // P7: tong ket su kien da bo + xoa so sach (van dang ngu => khong lot su kien nao)
        asleep = false;
        log("day: man hinh hien tai=" + currentDescribe() + " | " + counters);
        if (!"cham".equals(why)) swallowUntil = 0L;
        lastHuman = System.currentTimeMillis();
        lastPaint = 0;
        log("day (" + why + ")");
        status("");
        if (showInfo) infoTick();
        repaintDisplay();            // ve lai ngay khung game cu
        owedRepaint = false;
        requestFullRepaint();        // 1 lan ve day du cho Canvas va Screen lcdui (khung dang cho tu luc ngu cung duoc ve o day)
    }

    static JFrame frameRef() { return frame; }

    static String currentDescribe() {
        try {
            MIDlet m = MIDletBridge.getCurrentMIDlet();
            Display d = m == null ? null : Display.getDisplay(m);
            return InputGuard.describe(d == null ? null : d.getCurrent());
        } catch (Throwable t) { return "?"; }
    }

    private static void status(final String s) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() { try { org.microemu.app.Common.setStatusBar(s); } catch (Throwable ignore) { /* khong co thanh trang thai */ } }
        });
    }

    private static void repaintDisplay() {
        Component c = displayComp;
        if (c != null) c.repaint();
    }

    /* ------------------------------------------------------------ bo loc su kien AWT: dem thao tac NGUOI, chan chuot/phim vao game khi ngu */

    private static final class Gate extends EventQueue {
        protected void dispatchEvent(AWTEvent e) {
            try { if (filter(e)) return; } catch (Throwable t) { /* khong de loi bo loc lam hong luong su kien */ }
            super.dispatchEvent(e);
        }
    }

    private static boolean inWindow(Object src) {
        JFrame f = frame;
        if (f == null || !(src instanceof Component)) return false;
        Component c = (Component) src;
        return c == f || SwingUtilities.getWindowAncestor(c) == f;
    }

    /** Su kien huong toi GAME: chuot tren man hinh/than may, hoac phim khong thuoc menu/hop thoai. */
    private static boolean gameBound(AWTEvent e) {
        if (!(e instanceof InputEvent)) return false;
        Object src = e.getSource();
        if (src instanceof org.microemu.app.ui.swing.SwingDisplayComponent || src instanceof org.microemu.app.ui.swing.SwingDeviceComponent) return true;
        if (e instanceof MouseEvent && src instanceof java.awt.Container) {
            // chuot toi thanh phan nhe: AWT chuyen su kien ve cua so nang (source = JFrame) roi moi chia lai -> tu tim thanh phan nam duoi con tro
            MouseEvent me = (MouseEvent) e;
            Component hit = SwingUtilities.getDeepestComponentAt((java.awt.Container) src, me.getX(), me.getY());
            return hit instanceof org.microemu.app.ui.swing.SwingDisplayComponent || hit instanceof org.microemu.app.ui.swing.SwingDeviceComponent;
        }
        if (e instanceof KeyEvent) {
            if (javax.swing.MenuSelectionManager.defaultManager().getSelectedPath().length > 0) return false;   // dang dieu khien menu bang ban phim
            return inWindow(src) && !(src instanceof MenuElement);
        }
        return false;
    }

    /** true = nuot su kien (khong cho toi game). */
    private static boolean filter(AWTEvent e) {
        if (!(e instanceof InputEvent)) return false;
        if (inWindow(e.getSource())) lastHuman = System.currentTimeMillis();
        boolean gb = gameBound(e);
        if (!gb) return false;
        int id = e.getID();
        if (asleep) {
            if (testPass) return false;
            InputGuard.countAwt(id == KeyEvent.KEY_PRESSED ? 0 : id == KeyEvent.KEY_RELEASED ? 1 : id == KeyEvent.KEY_TYPED ? 2
                    : id == MouseEvent.MOUSE_PRESSED ? 3 : id == MouseEvent.MOUSE_RELEASED ? 4 : id == MouseEvent.MOUSE_DRAGGED ? 5 : 6);
            if (WAKE_TOUCH.equals(wakeMode) && (id == MouseEvent.MOUSE_PRESSED || id == KeyEvent.KEY_PRESSED)) {
                swallowUntil = System.nanoTime() + 500000000L;
                wake("cham");
            }
            return true;             // dang ngu: khong ai duoc cham vao game (ke ca cai cham de day)
        }
        long su = swallowUntil;                       // P6: so sanh bang HIEU (nanoTime co the am/tran so); 0 = khong nuot gi
        return su != 0L && System.nanoTime() - su < 0L;     // vua day xong: nuot not nua nhan (nha chuot/phim)
    }

    /* ------------------------------------------------------------ CPU / RAM */

    private static boolean metricsInit;
    private static void initMetrics() {
        if (metricsInit) return;
        metricsInit = true;
        try {
            osBean = ManagementFactory.getOperatingSystemMXBean();
            Class<?> i = Class.forName("com.sun.management.OperatingSystemMXBean");
            if (!i.isInstance(osBean)) { osBean = null; return; }
            mCpuTime = i.getMethod("getProcessCpuTime");
            mCommit = i.getMethod("getCommittedVirtualMemorySize");
        } catch (Throwable t) { osBean = null; }
    }

    static String num1(double v) { String s = String.valueOf(Math.round(v * 10.0) / 10.0); return s.replace('.', ','); }

    /** Lay CPU (% ca may) va RAM (committed) cua tien trinh nay, ghi len thanh trang thai. Chi goi khi "Hien CPU/RAM" bat. */
    private static void infoTick() {
        try {
            initMetrics();
            String cpu = "?", ram = "?";
            if (osBean != null) {
                try {
                    long ct = ((Number) mCpuTime.invoke(osBean)).longValue();
                    long now = System.nanoTime();
                    if (lastCpuNs >= 0 && ct >= 0 && now > lastWallNs) {
                        double pct = 100.0 * (ct - lastCpuNs) / (double) (now - lastWallNs) / Runtime.getRuntime().availableProcessors();
                        cpu = num1(Math.max(0, Math.min(100, pct))) + "%";
                    }
                    lastCpuNs = ct; lastWallNs = now;
                } catch (Throwable t) { cpu = "?"; }
                try {
                    long c = ((Number) mCommit.invoke(osBean)).longValue();
                    if (c > 0) ram = (c / 1048576L) + " MB";
                } catch (Throwable t) { ram = "?"; }
            }
            String text = (asleep ? "Ngủ " + clock() + " | " : "") + "CPU " + cpu + " | RAM " + ram;
            if (DEBUG) log("info ms=" + System.currentTimeMillis() + " ngu=" + (asleep ? clock() : "-") + " cpu=" + cpu + " ram=" + ram);
            status(text);
        } catch (Throwable t) { /* khong de timer chet */ }
    }

    /** hh:mm (khong giay). */
    static String clock() {
        long m = (System.nanoTime() - sleepSince) / 60000000000L;
        return String.format("%02d:%02d", m / 60, m % 60);
    }

    private static final Color BLACK = Color.BLACK, WHITE = Color.WHITE;

    /** Ve man hinh ngu TINH: nen den + 1 dong chu, font mac dinh, khong khu rang cua, khong dong ho/CPU/RAM. true = da ve (khong ve game). */
    public static boolean paintSleep(Component c, Graphics g) {
        if (!asleep) return false;
        try {
            displayComp = c;
            sleepPaints++;
            int w = c.getWidth(), h = c.getHeight();
            g.setColor(BLACK);
            g.fillRect(0, 0, w, h);
            g.setColor(WHITE);
            String l = WAKE_TOUCH.equals(wakeMode) ? "Chạm để dậy" : "Đang ngủ - Tối ưu -> Dậy";
            FontMetrics fm = g.getFontMetrics();
            g.drawString(l, Math.max(2, (w - fm.stringWidth(l)) / 2), h / 2);
        } catch (Throwable t) { /* neu ve loi thi de man hinh den */ }
        return true;
    }

    /* ------------------------------------------------------------ thu nho / an, tu ngu, tick */

    private static boolean hidden() { return hiddenNow; }

    /** Doc trang thai that cua cua so (chi goi tu EDT/timer/listener, KHONG tu luong su kien game). */
    private static boolean readHidden() {
        JFrame f = frame;
        return f != null && (!f.isShowing() || (f.getExtendedState() & Frame.ICONIFIED) != 0);
    }

    private static void stateChanged() {
        boolean h = readHidden();
        hiddenNow = h;
        if (h && !hiddenLogged) { hiddenLogged = true; log("an/thu nho: ngung ve"); }
        else if (!h && hiddenLogged) { hiddenLogged = false; log("hien lai: ve tiep"); forceRepaint("hien lai"); }
        else if (!h) forceRepaint("trang thai cua so");
    }

    /** Hien lai / doi kich thuoc / lay tieu diem / kich hoat: xoa no, ve day du 1 lan (gop; bo qua neu dang ngu/an - luc day se ve). */
    static void forceRepaint(String why) {
        if (frame == null) return;
        if (asleep || hiddenNow) { owedRepaint = true; return; }
        lastPaint = 0;
        repaintDisplay();
        requestFullRepaint();
    }

    /** 5 giay/lan: tu ngu, an/thu nho, (debug) thong ke, CPU/RAM len thanh trang thai neu bat. */
    private static void tick() {
        try {
            boolean h = readHidden();
            if (h != hiddenNow || h != hiddenLogged) stateChanged();
            hiddenNow = h;
            if (!asleep && autoMin > 0 && System.currentTimeMillis() - lastHuman >= autoMin * 60000L) sleepNow("tu dong " + autoMin + " phut");
            // chong mat yeu cau ve: neu co no ve ma qua han (timer hen ve bu hong/huy) thi ve ngay
            if (owedRepaint && !asleep && !h) {
                long iv = fps > 0 ? 1000000000L / fps : 0L;
                if (System.nanoTime() - owedSince > iv + 200000000L) { owedRepaint = false; deferredPending.set(false); lastPaint = 0; requestFullRepaint(); if (DEBUG) log("tick: ve bu bi tre -> ve ngay"); }
            }
            ToiUuMenu.refresh();
            if (showInfo) infoTick();
            if (DEBUG) {
                int[] g = gamePaints;
                log("stat da-ve=" + statPainted + " bo-qua=" + statSkipped + " game-ve tab1=" + g[1] + " tab2=" + g[2] + " tab3=" + g[3] + " tab4=" + g[4]
                        + " tab5=" + g[5] + " khac=" + g[0] + " ngu=" + asleep + " ngu-ve=" + sleepPaints);
                statPainted = 0; statSkipped = 0; sleepPaints = 0;
                for (int i = 0; i < g.length; i++) g[i] = 0;
            }
        } catch (Throwable t) { /* khong de timer chet */ }
    }

    /**
     * MOT Timer duy nhat, chi ton tai khi can: tu ngu > 0, gioi han hinh/giay > 0 (hen ve bu), hoac "Hien CPU/RAM" bat.
     * Tat ca (tu ngu Khong + khong gioi han + khong hien CPU/RAM) -> khong co luong timer.
     */
    private static void syncTimer() {
        boolean need = autoMin > 0 || fps > 0 || showInfo;
        boolean first = false;
        synchronized (TIMER_LOCK) {
            if (need && timer == null) {
                lastCpuNs = -1;
                Timer t = new Timer("ToiUu-timer", true);
                t.schedule(new TimerTask() { public void run() { tick(); } }, 5000, 5000);
                if (showInfo) t.schedule(new TimerTask() { public void run() { infoTick(); } }, 100);   // lay moc dau de lan do thu hai co CPU
                timer = t;
            } else if (!need && timer != null) {
                timer.cancel();
                timer = null;
                deferredPending.set(false);       // task ve bu (neu co) da bi huy: khong de co ket
            }
        }
    }

    /* ------------------------------------------------------------ BO QUA VE (goi tu SwingDisplayComponent.repaintRequest) */

    /** true = bo qua lan ve nay (tra ve ngay, khong chan luong game). */
    public static boolean skip(Component comp, int x, int y, int w, int h) {
        displayComp = comp;                                   // KHONG khoa, KHONG goi Swing: chay tren luong su kien cua emulator
        if (asleep || hiddenNow) { statSkipped++; owedRepaint = true; owedSince = System.nanoTime(); return true; }
        long interval = fps > 0 ? 1000000000L / fps : 0L;
        if (interval == 0L) { statPainted++; return false; }
        long now = System.nanoTime();
        long lp = lastPaint;
        long since = now - lp;
        // lp==0: chua tung ve / vua duoc ep ve lai (P6: khong phu thuoc goc cua nanoTime, vi nanoTime co the am)
        if (lp == 0L || since >= interval) { lastPaint = now == 0L ? 1L : now; statPainted++; owedRepaint = false; return false; }
        statSkipped++;
        if (!owedRepaint) { owedRepaint = true; owedSince = now; }
        defer((interval - since) / 1000000L + 1L);
        return true;
    }

    /** Hen DUNG 1 lan ve bu (gop). Khong khoa; co han (deferDue) de tu chua khi timer chet/huy. */
    private static void defer(long ms) {
        long now = System.nanoTime();
        if (!deferredPending.compareAndSet(false, true)) {
            if (now - deferDue < 1000000000L) return;             // dang co task cho va chua qua han: gop
            // qua han > 1 s ma chua chay: coi nhu mat, hen lai
        }
        deferDue = now + ms * 1000000L;
        Timer t = timer;
        if (t == null) { deferredPending.set(false); return; }    // khong co timer: tick/lan ve sau se ve (owedRepaint van bat)
        try {
            t.schedule(new TimerTask() {
                public void run() {
                    deferredPending.set(false);
                    if (!asleep && !hiddenNow) { owedRepaint = false; requestFullRepaint(); }
                }
            }, ms);
        } catch (IllegalStateException e) { deferredPending.set(false); }
    }

    /** CHI KHI -Dtoiuu.debug=true: dem so lan Canvas.paint cua game that cho tung ban (goi tu J2SEDeviceDisplay.paintDisplayable). */
    public static void gamePaintHook() {
        if (!DEBUG) return;
        try {
            MIDlet m = MIDletBridge.getCurrentMIDlet();
            Display d = m == null ? null : Display.getDisplay(m);
            Displayable cur = d == null ? null : d.getCurrent();
            gamePaints[cur == null ? 0 : tabOf(cur.getClass().getName())]++;
        } catch (Throwable t) { gamePaints[0]++; }
    }

    static int tabOf(String n) {
        if (n.startsWith("lib.") || n.startsWith("MrQuyet.") || n.startsWith("ep3.")) return 0;
        if (n.startsWith("b.")) return 2;
        if (n.startsWith("c.")) return 3;
        if (n.startsWith("d.")) return 4;
        if (n.startsWith("e.")) return 5;
        if (n.indexOf('.') < 0 || n.startsWith("com.")) return 1;
        return 0;
    }

    /** Xep hang 1 yeu cau ve toan man hinh (hang doi su kien cua Display, khong chan). */
    static void requestFullRepaint() {
        try {
            MIDlet m = MIDletBridge.getCurrentMIDlet();
            Display d = m == null ? null : Display.getDisplay(m);
            if (d == null) return;
            Displayable c = d.getCurrent();
            if (c == null) return;
            d.repaint(c, 0, 0, c.getWidth(), c.getHeight());
        } catch (Throwable t) { /* bo qua */ }
    }
}
