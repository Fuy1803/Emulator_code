package ep3;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

/**
 * Hop thoai xem log loi theo tung tab (chi dung UI khi nguoi dung bam mo, dong lai la ngung cap nhat).
 */
public final class TabErrorLogDialog extends JDialog {
    private static final long serialVersionUID = 1L;
    private static TabErrorLogDialog instance;

    // Thu tu tab UI: 0 = Tat ca (-1), 1..5 = Tab 1..5, 6 = He thong (0)
    private static final int[] TAB_KEYS = { -1, 1, 2, 3, 4, 5, 0 };
    private static final String[] TAB_NAMES = { "Tất cả", "Tab 1", "Tab 2", "Tab 3", "Tab 4", "Tab 5", "Hệ thống" };

    private final JTabbedPane tabs = new JTabbedPane();
    private final JTextArea[] areas = new JTextArea[TAB_KEYS.length];
    private volatile boolean refreshQueued;

    private TabErrorLogDialog(Frame owner) {
        super(owner, "Log lỗi theo từng tab (siêu nhẹ)", false);
        setLayout(new BorderLayout(6, 6));
        Font mono = new Font(Font.MONOSPACED, Font.PLAIN, 12);
        for (int i = 0; i < TAB_KEYS.length; i++) {
            JTextArea ta = new JTextArea();
            ta.setEditable(false);
            ta.setFont(mono);
            ta.setLineWrap(true);
            ta.setWrapStyleWord(true);
            areas[i] = ta;
            tabs.addTab(TAB_NAMES[i], new JScrollPane(ta));
        }
        add(tabs, BorderLayout.CENTER);

        JPanel bar = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnRefresh = new JButton("Làm mới");
        btnRefresh.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { refreshNow(); }
        });
        JButton btnClearOne = new JButton("Xóa tab này");
        btnClearOne.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int idx = tabs.getSelectedIndex();
                if (idx >= 0) TabErrorLog.clear(TAB_KEYS[idx]);
            }
        });
        JButton btnClearAll = new JButton("Xóa tất cả");
        btnClearAll.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { TabErrorLog.clear(-1); }
        });
        JButton btnSave = new JButton("Lưu ra file...");
        btnSave.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { saveCurrentTab(); }
        });
        JButton btnClose = new JButton("Đóng");
        btnClose.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { setVisible(false); }
        });
        bar.add(btnRefresh);
        bar.add(btnClearOne);
        bar.add(btnClearAll);
        bar.add(btnSave);
        bar.add(btnClose);
        add(bar, BorderLayout.SOUTH);

        setSize(680, 420);
        setLocationRelativeTo(owner);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) { detachListener(); }
            public void windowClosed(WindowEvent e) { detachListener(); }
        });
    }

    public static void showDialog(Frame owner) {
        if (instance == null) {
            instance = new TabErrorLogDialog(owner);
        }
        instance.attachListener();
        instance.refreshNow();
        instance.setVisible(true);
        instance.toFront();
    }

    private void attachListener() {
        TabErrorLog.setActiveListener(new Runnable() {
            public void run() {
                if (!isVisible() || refreshQueued) return;
                refreshQueued = true;
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        refreshQueued = false;
                        if (isVisible()) refreshNow();
                    }
                });
            }
        });
    }

    private void detachListener() {
        TabErrorLog.setActiveListener(null);
    }

    @Override
    public void setVisible(boolean b) {
        if (!b) detachListener();
        super.setVisible(b);
    }

    private void refreshNow() {
        for (int i = 0; i < TAB_KEYS.length; i++) {
            int k = TAB_KEYS[i];
            int c = (k < 0) ? TabErrorLog.totalCount() : TabErrorLog.count(k);
            tabs.setTitleAt(i, c > 0 ? (TAB_NAMES[i] + " (" + c + ")") : TAB_NAMES[i]);
            areas[i].setText(TabErrorLog.getText(k));
            areas[i].setCaretPosition(areas[i].getDocument().getLength());
        }
    }

    private void saveCurrentTab() {
        int idx = tabs.getSelectedIndex();
        if (idx < 0) idx = 0;
        JFileChooser fc = new JFileChooser();
        fc.setSelectedFile(new File("emulator_error_log.txt"));
        if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        File f = fc.getSelectedFile();
        try {
            OutputStreamWriter w = new OutputStreamWriter(new FileOutputStream(f), "UTF-8");
            try { w.write(TabErrorLog.getText(TAB_KEYS[idx])); }
            finally { w.close(); }
            JOptionPane.showMessageDialog(this, "Đã lưu log vào: " + f.getAbsolutePath());
        } catch (Throwable t) {
            JOptionPane.showMessageDialog(this, "Không lưu được file: " + t.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }
}
