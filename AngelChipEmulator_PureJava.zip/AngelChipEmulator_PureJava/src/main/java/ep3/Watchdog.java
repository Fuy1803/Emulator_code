package ep3;

import java.lang.management.LockInfo;
import java.lang.management.ManagementFactory;
import java.lang.management.MonitorInfo;
import java.lang.management.ThreadInfo;
import java.lang.management.ThreadMXBean;
import javax.microedition.lcdui.Display;
import javax.microedition.midlet.MIDlet;
import javax.swing.SwingUtilities;
import org.microemu.MIDletBridge;

/**
 * P7: chong "do" CHI GHI LOG. Mot luong daemon rieng "ToiUu-watchdog" (ngu 1 s/vong) gui 1 viec nho vao luong Swing (EDT) va 1 viec nho vao luong su kien emulator
 * (Display.callSerially). Viec nao chua chay xong sau > 5 s => ghi MOT thread dump day du vao log thuong (co tieu de ro), toi da 1 lan / 10 phut
 * khi con do; het do thi lan do sau ghi lai ngay. Khong doi hanh vi nao cua emulator/game. Khong gui viec moi khi viec cu con treo (khong don hang).
 * Do tre phat hien: > 5 s den ~6 s (chu ky 1 s). Luong chi ton tai khi "Ghi log khi do" BAT.
 */
final class Watchdog {
    private Watchdog() {}
    private static final long STALL_NS = 5000000000L, REPEAT_NS = 600000000000L;
    private static volatile boolean edtPending, evPending;
    private static volatile long edtPostAt, evPostAt;
    private static long lastDump;            // nano, 0 = chua ghi trong dot do nay
    private static boolean dumpedOnce;
    static volatile int dumps;               // so dump da ghi (kiem thu)

    private static Thread th;

    static void reset() { lastDump = 0; dumpedOnce = false; }

    /** Bat/tat luong canh giu theo cai dat. */
    static synchronized void sync(boolean on) {
        if (on && th == null) {
            th = new Thread(new Runnable() { public void run() {
                try { while (!Thread.currentThread().isInterrupted()) { tick(); Thread.sleep(1000); } } catch (InterruptedException e) { /* dung */ }
            } }, "ToiUu-watchdog");
            th.setDaemon(true);
            th.start();
        } else if (!on && th != null) {
            th.interrupt(); th = null;
            edtPending = false; evPending = false;
        }
    }

    static void tick() {
        try {
            long now = System.nanoTime();
            if (!edtPending) {
                edtPending = true; edtPostAt = now;
                SwingUtilities.invokeLater(new Runnable() { public void run() { edtPending = false; } });
            }
            if (!evPending) {
                MIDlet m = MIDletBridge.getCurrentMIDlet();
                Display d = m == null ? null : Display.getDisplay(m);
                if (d != null) {
                    evPending = true; evPostAt = now;
                    try { d.callSerially(new Runnable() { public void run() { evPending = false; } }); }
                    catch (Throwable t) { evPending = false; }
                }
            }
            boolean edtStuck = edtPending && now - edtPostAt > STALL_NS;
            boolean evStuck = evPending && now - evPostAt > STALL_NS;
            if (!edtStuck && !evStuck) { dumpedOnce = false; lastDump = 0; return; }
            if (dumpedOnce && now - lastDump < REPEAT_NS) return;
            dumpedOnce = true; lastDump = now;
            dump(edtStuck, evStuck, edtStuck ? (now - edtPostAt) / 1000000L : 0, evStuck ? (now - evPostAt) / 1000000L : 0);
        } catch (Throwable t) { /* khong bao gio lam hong timer */ }
    }

    private static void dump(boolean edt, boolean ev, long edtMs, long evMs) {
        StringBuilder b = new StringBuilder(8192);
        b.append("[ToiUu] [WATCHDOG] ======== DO: ")
         .append(edt ? "luong Swing (EDT) khong phan hoi " + edtMs + " ms; " : "")
         .append(ev ? "luong su kien emulator khong phan hoi " + evMs + " ms; " : "")
         .append("thread dump #").append(++dumps).append(" luc ").append(new java.util.Date()).append(" ========\n");
        b.append("[WATCHDOG] trang thai: ngu=").append(ToiUu.asleep).append(" fps=").append(ToiUu.fps).append(" man-hinh=").append(ToiUu.currentDescribe())
         .append(" | ").append(InputGuard.snapshot()).append('\n');
        try {
            ThreadMXBean mx = ManagementFactory.getThreadMXBean();
            long[] dl = mx.findDeadlockedThreads();
            b.append("[WATCHDOG] deadlock: ").append(dl == null ? "khong" : java.util.Arrays.toString(dl)).append('\n');
            for (ThreadInfo ti : mx.dumpAllThreads(true, true)) {
                b.append('"').append(ti.getThreadName()).append("\" id=").append(ti.getThreadId()).append(' ').append(ti.getThreadState());
                if (ti.getLockName() != null) b.append(" cho ").append(ti.getLockName());
                if (ti.getLockOwnerName() != null) b.append(" (giu boi \"").append(ti.getLockOwnerName()).append("\")");
                b.append('\n');
                StackTraceElement[] st = ti.getStackTrace();
                MonitorInfo[] mi = ti.getLockedMonitors();
                for (int i = 0; i < st.length; i++) {
                    b.append("    at ").append(st[i]).append('\n');
                    for (MonitorInfo m : mi) if (m.getLockedStackDepth() == i) b.append("      - giu khoa ").append(m).append('\n');
                }
                for (LockInfo l : ti.getLockedSynchronizers()) b.append("      - giu dong bo ").append(l).append('\n');
            }
        } catch (Throwable t) {
            b.append("[WATCHDOG] ThreadMXBean loi ").append(t).append(", dung Thread.getAllStackTraces\n");
            for (java.util.Map.Entry<Thread, StackTraceElement[]> e : Thread.getAllStackTraces().entrySet()) {
                b.append('"').append(e.getKey().getName()).append("\" ").append(e.getKey().getState()).append('\n');
                for (StackTraceElement s : e.getValue()) b.append("    at ").append(s).append('\n');
            }
        }
        b.append("[ToiUu] [WATCHDOG] ======== HET thread dump #").append(dumps).append(" ========");
        System.out.println(b);
        System.out.flush();
    }
}
