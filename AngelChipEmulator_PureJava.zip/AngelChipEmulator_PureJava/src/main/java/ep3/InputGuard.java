package ep3;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.microedition.lcdui.Displayable;

import org.microemu.DisplayAccess;
import org.microemu.MIDletAccess;
import org.microemu.MIDletBridge;

/**
 * P7: chan MOI dau vao toi MIDlet o muc thap nhat ma emulator dung (n = DisplayAccess; J2SEInputMethod), khong chi o muc Swing.
 *  - Khi NGU: moi phim/chuot/go chu/dan/phim mem/lenh BI BO (khong xep hang).
 *  - Luc BAT DAU NGU: moi phim/chuot game dang coi la "dang giu" duoc nha DUNG 1 lan, roi xoa trang thai nhan phim cua emulator
 *    (danh sach phim dang giu cua J2SEInputMethod: neu de ket thi lan bam sau chi thanh keyRepeated, phim mem/phim giu menu khong bao gio chay).
 *  - Sau khi DAY: nha/lap/go chu cua phim ma lan BAM khong duoc thay sau khi day deu bi bo (so cai "so cai" bam-nha o 2 muc).
 * Cac ham drop*() duoc goi tu ma da vá ASM (tools/P7Patch) NGAY DAU phuong thuc; tra true = bo qua su kien. Khong khoa nao giu khi goi ra ngoai.
 */
public final class InputGuard {
    private InputGuard() {}

    // loai su kien (muc DisplayAccess)
    static final int K_PRESS = 0, K_REPEAT = 1, K_RELEASE = 2, P_PRESS = 3, P_RELEASE = 4, P_DRAG = 5, CMD = 6;
    // loai su kien (muc InputMethod)
    static final int B_PRESS = 10, B_RELEASE = 11, B_TYPED = 12, B_PASTE = 13;
    static final String[] NAME = { "phim-nhan", "phim-lap", "phim-nha", "chuot-nhan", "chuot-nha", "chuot-keo", "lenh", "nut-nhan", "nut-nha", "go-chu", "dan" };

    private static final Object L = new Object();          // chi bao ve cac tap/so dem ben duoi, khong bao gio giu khi goi ra ngoai
    private static final Set<Integer> daDown = new HashSet<Integer>();    // phim game dang coi la giu (muc DisplayAccess)
    private static final Set<Integer> imDown = new HashSet<Integer>();    // nut dang giu (muc InputMethod)
    private static boolean ptrDown; private static int ptrX, ptrY;
    private static volatile Thread bypass;                  // luong dang tu giao "nha phim luc bat dau ngu"
    private static final int[] dropAsleep = new int[11];    // dem bi bo khi ngu, theo loai
    private static final int[] dropUnseen = new int[11];    // dem bi bo sau khi day vi lan bam khong duoc thay
    private static final int[] dropAwt = new int[8];        // muc AWT (Gate): 0 phim-nhan 1 phim-nha 2 go 3 chuot-nhan 4 chuot-nha 5 chuot-keo 6 chuot-khac 7 lenh
    static volatile int setCurrentLogs;
    private static String unseenPrev = "0";

    static boolean asleep() { return ToiUu.asleep && !ToiUu.testPass; }

    /* ------------------------------------------------------------ muc DisplayAccess (lop n) */

    /** kind: 0 nhan 1 lap 2 nha 3 chuot-nhan 4 chuot-nha 5 chuot-keo 6 lenh. a,b = ma phim / toa do. true = bo. */
    public static boolean dropDa(int kind, int a, int b) {
        if (bypass == Thread.currentThread()) return false;
        try {
            boolean sl = asleep();
            synchronized (L) {
                if (sl) { dropAsleep[kind]++; return true; }
                switch (kind) {
                    case K_PRESS: daDown.add(a); return false;
                    case K_REPEAT: if (!daDown.contains(a)) { dropUnseen[kind]++; return true; } return false;
                    case K_RELEASE: if (!daDown.remove(a)) { dropUnseen[kind]++; return true; } return false;
                    case P_PRESS: ptrDown = true; ptrX = a; ptrY = b; return false;
                    case P_RELEASE: if (!ptrDown) { dropUnseen[kind]++; return true; } ptrDown = false; return false;
                    case P_DRAG: if (!ptrDown) { dropUnseen[kind]++; return true; } ptrX = a; ptrY = b; return false;
                    default: return false;
                }
            }
        } catch (Throwable t) { return false; }
    }

    /* ------------------------------------------------------------ muc InputMethod (J2SEInputMethod) */

    /** kind: 10 nhan 11 nha 12 go-chu 13 dan; code = ky tu hoac ma nut (cung cach J2SEInputMethod tinh). true = bo. */
    public static boolean dropIm(int kind, int code) {
        if (bypass == Thread.currentThread()) return false;
        try {
            boolean sl = asleep();
            synchronized (L) {
                int i = kind - B_PRESS + 7;                      // 10->7 ... 13->10
                if (sl) { dropAsleep[i]++; return true; }
                switch (kind) {
                    case B_PRESS: imDown.add(code); return false;
                    case B_RELEASE: if (!imDown.remove(code)) { dropUnseen[i]++; return true; } return false;
                    case B_TYPED: if (imDown.isEmpty()) { dropUnseen[i]++; return true; } return false;
                    default: return false;                       // dan (clipboard) khi thuc: cho qua (nguoi chu chu dong)
                }
            }
        } catch (Throwable t) { return false; }
    }

    /** J2SEInputMethod: ma "phim" cua nut/ky tu giong buttonPressed (char != 0 -> char, nguoc lai ma nut). */
    public static int imCode(Object button, char ch) {
        if (ch != 0) return ch;
        try { return ((org.microemu.device.j2se.J2SEButton) button).getKeyCode(); } catch (Throwable t) { return 0; }
    }

    /* ------------------------------------------------------------ AWT (Gate) dem so bi bo */

    static void countAwt(int idx) { synchronized (L) { dropAwt[idx]++; } }

    /* ------------------------------------------------------------ bat dau ngu / day */

    /** Goi sau khi asleep=true. Nha moi phim/chuot dang giu, xoa trang thai nhan phim. Tra ve mo ta (de log 1 dong). */
    static String onSleep() {
        List<Integer> keys; boolean pd; int px, py; Set<Integer> imSnap;
        synchronized (L) {
            keys = new ArrayList<Integer>(daDown); daDown.clear();
            pd = ptrDown; px = ptrX; py = ptrY; ptrDown = false;
            imSnap = new HashSet<Integer>(imDown); imDown.clear();
            unseenPrev = fmt(dropUnseen);
            java.util.Arrays.fill(dropAsleep, 0); java.util.Arrays.fill(dropUnseen, 0); java.util.Arrays.fill(dropAwt, 0);
        }
        setCurrentLogs = 0;
        String cArr = "?";
        try { cArr = String.valueOf(clearImState()); } catch (Throwable t) { cArr = "loi " + t; }
        int released = 0;
        try {
            MIDletAccess ma = MIDletBridge.getMIDletAccess();
            DisplayAccess da = ma == null ? null : ma.getDisplayAccess();
            if (da != null) {
                bypass = Thread.currentThread();
                try {
                    for (Integer k : keys) { try { da.keyReleased(k.intValue()); released++; } catch (Throwable t) { /* tiep */ } }
                    if (pd) { try { da.pointerReleased(px, py); released++; } catch (Throwable t) { /* tiep */ } }
                } finally { bypass = null; }
            }
        } catch (Throwable t) { /* khong de loi lam hong viec ngu */ }
        return "phim-dang-giu(game)=" + keys + " chuot-giu=" + pd + " nut-emulator=" + imSnap + " danh-sach-giu-cu=" + cArr + " -> da nha " + released + " va xoa trang thai; bo-trong-lan-thuc-truoc(nha/lap/go khong thay bam)=" + unseenPrev;
    }

    /** Nha moi phim/chuot game dang coi la giu (1 lan) + xoa trang thai nhan phim cua emulator, KHONG doi trang thai ngu. Dung cho "go ket" / gui phim. */
    static volatile int lastReleased; static volatile boolean lastHadImKeys;

    static String releaseAll() {
        List<Integer> keys; boolean pd; int px, py;
        synchronized (L) { keys = new ArrayList<Integer>(daDown); daDown.clear(); pd = ptrDown; px = ptrX; py = ptrY; ptrDown = false; imDown.clear(); }
        Object old = null;
        try { old = clearImState(); } catch (Throwable t) { old = "loi " + t; }
        lastHadImKeys = old instanceof java.util.Collection && !((java.util.Collection<?>) old).isEmpty();
        int released = 0;
        try {
            MIDletAccess ma = MIDletBridge.getMIDletAccess();
            DisplayAccess da = ma == null ? null : ma.getDisplayAccess();
            if (da != null) {
                bypass = Thread.currentThread();
                try {
                    for (Integer k : keys) { try { da.keyReleased(k.intValue()); released++; } catch (Throwable t) { /* tiep */ } }
                    if (pd) { try { da.pointerReleased(px, py); released++; } catch (Throwable t) { /* tiep */ } }
                } finally { bypass = null; }
            }
        } catch (Throwable t) { /* bo qua */ }
        lastReleased = released;
        return "game-giu=" + keys + " danh-sach-giu-cu=" + old + " -> da nha " + released;
    }

    /** Xoa danh sach phim dang giu + co "da xu ly" cua J2SEInputMethod (private). Tra ve noi dung cu. */
    static Object clearImState() throws Exception {
        Object im = org.microemu.device.DeviceFactory.getDevice().getInputMethod();
        if (im instanceof org.microemu.device.j2se.J2SEInputMethod) {
            return ((org.microemu.device.j2se.J2SEInputMethod) im).clearPressedState();
        }
        return java.util.Collections.emptyList();
    }

    /** Goi khi day: tra ve 1 dong dem so su kien da bo khi ngu. */
    static String onWake() {
        String s;
        synchronized (L) {
            s = "bo-khi-ngu(DisplayAccess/InputMethod): " + fmt(dropAsleep) + "; bo-o-AWT: phim-nhan=" + dropAwt[0] + " phim-nha=" + dropAwt[1] + " go=" + dropAwt[2]
                    + " chuot-nhan=" + dropAwt[3] + " chuot-nha=" + dropAwt[4] + " chuot-keo=" + dropAwt[5] + " chuot-khac=" + dropAwt[6]
                    + "; (dang-giu sau day: game=" + daDown + " nut=" + imDown + ")";
            daDown.clear(); imDown.clear(); ptrDown = false;
        }
        return s;
    }

    /** Dem bi bo sau khi day vi khong thay lan bam (dung de bao cao). */
    static String unseenCounters() { synchronized (L) { return fmt(dropUnseen); } }

    private static String fmt(int[] a) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < a.length; i++) if (a[i] != 0) b.append(NAME[i]).append('=').append(a[i]).append(' ');
        return b.length() == 0 ? "0" : b.toString().trim();
    }

    /** CHI DE THU/CHAN DOAN: tong so su kien da bi bo tinh den gio (khi ngu + do khong thay bam). */
    public static String snapshot() { synchronized (L) { return "ngu[" + fmt(dropAsleep) + "] khong-thay-bam[" + fmt(dropUnseen) + "]"; } }

    /* ------------------------------------------------------------ S3: ai doi man hinh hien tai khi ngu */

    /** Goi tu Display.setCurrent (da vá). Khi ngu: ghi 1 dong kem vet ngan xep ngan. */
    public static void onSetCurrent(Object d) {
        if (!asleep()) return;
        try {
            if (setCurrentLogs++ >= 20) return;
            StringBuilder sb = new StringBuilder();
            StackTraceElement[] st = new Throwable().getStackTrace();
            int n = 0;
            for (int i = 1; i < st.length && n < 6; i++) {
                String cn = st[i].getClassName();
                if (cn.startsWith("javax.microedition.lcdui.Display")) continue;
                sb.append(n == 0 ? "" : " < ").append(cn).append('.').append(st[i].getMethodName()).append(':').append(st[i].getLineNumber());
                n++;
            }
            String warn = "CANH BAO setCurrent khi ngu: " + describe(d) + " | luong=" + Thread.currentThread().getName() + " | " + sb;
            ToiUu.log(warn);
            int tIdx = d == null ? 0 : ToiUu.tabOf(d.getClass().getName());
            TabErrorLog.record(tIdx, warn);
        } catch (Throwable t) { /* bo qua */ }
    }

    static String describe(Object d) {
        if (d == null) return "null";
        String title = "";
        try { if (d instanceof Displayable) { String t = ((Displayable) d).getTitle(); title = t == null ? "" : t; } } catch (Throwable t) { /* bo qua */ }
        String cn = d.getClass().getName();
        return cn + (title.length() == 0 ? "" : "/\"" + title + "\"") + " [ban " + ToiUu.tabOf(cn) + "]";
    }
}
