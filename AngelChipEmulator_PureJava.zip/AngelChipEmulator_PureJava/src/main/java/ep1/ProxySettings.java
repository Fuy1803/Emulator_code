package ep1;

import java.io.*;
import java.util.Properties;

/** Cai dat proxy cua MOT cua so (mot profile). Doc/ghi file proxy_<ten>.properties. */
public final class ProxySettings {
    public static final int TABS = 5;
    public static final int OFF = 0, DEFAULT = 1, OWN = 2;

    public static final class Entry {
        public boolean enabled;      // chi dung cho "mac dinh cua so"
        public int mode = DEFAULT;   // chi dung cho tab
        public String host = "";
        public int port = -1;
        public String user = "";
        public String pass = "";

        public Entry copy() {
            Entry e = new Entry();
            e.enabled = enabled; e.mode = mode; e.host = host; e.port = port; e.user = user; e.pass = pass;
            return e;
        }
        public boolean valid() { return host.length() > 0 && port >= 1 && port <= 65535; }
    }

    public Entry def = new Entry();
    public final Entry[] tabs = new Entry[TABS];

    public ProxySettings() {
        for (int i = 0; i < TABS; i++) tabs[i] = new Entry();
    }

    public ProxySettings copy() {
        ProxySettings s = new ProxySettings();
        s.def = def.copy();
        for (int i = 0; i < TABS; i++) s.tabs[i] = tabs[i].copy();
        return s;
    }

    private static int parsePort(String v) {
        try { int p = Integer.parseInt(v.trim()); return (p >= 1 && p <= 65535) ? p : -1; }
        catch (Exception e) { return -1; }
    }
    private static String g(Properties p, String k) {
        String v = p.getProperty(k);
        return v == null ? "" : v.trim();
    }

    public static ProxySettings load(File f) throws IOException {
        ProxySettings s = new ProxySettings();
        if (f == null || !f.isFile()) return s;
        Properties p = new Properties();
        InputStream in = new FileInputStream(f);
        try { p.load(new InputStreamReader(in, "UTF-8")); } finally { in.close(); }
        s.def.enabled = "true".equalsIgnoreCase(g(p, "default.enabled"));
        s.def.host = g(p, "default.host");
        s.def.port = parsePort(g(p, "default.port"));
        s.def.user = g(p, "default.user");
        s.def.pass = p.getProperty("default.pass", "");
        for (int i = 0; i < TABS; i++) {
            String k = "tab" + (i + 1) + ".";
            Entry e = s.tabs[i];
            String m = g(p, k + "mode");
            e.mode = "off".equalsIgnoreCase(m) ? OFF : ("own".equalsIgnoreCase(m) ? OWN : DEFAULT);
            e.host = g(p, k + "host");
            e.port = parsePort(g(p, k + "port"));
            e.user = g(p, k + "user");
            e.pass = p.getProperty(k + "pass", "");
        }
        return s;
    }

    public void save(File f) throws IOException {
        Properties p = new Properties();
        p.setProperty("version", "1");
        p.setProperty("default.enabled", def.enabled ? "true" : "false");
        p.setProperty("default.host", def.host);
        p.setProperty("default.port", def.port > 0 ? String.valueOf(def.port) : "");
        p.setProperty("default.user", def.user);
        p.setProperty("default.pass", def.pass);
        for (int i = 0; i < TABS; i++) {
            String k = "tab" + (i + 1) + ".";
            Entry e = tabs[i];
            p.setProperty(k + "mode", e.mode == OFF ? "off" : (e.mode == OWN ? "own" : "default"));
            p.setProperty(k + "host", e.host);
            p.setProperty(k + "port", e.port > 0 ? String.valueOf(e.port) : "");
            p.setProperty(k + "user", e.user);
            p.setProperty(k + "pass", e.pass);
        }
        File dir = f.getParentFile();
        if (dir != null && !dir.isDirectory()) dir.mkdirs();
        File tmp = new File(f.getPath() + ".tmp");
        OutputStream out = new FileOutputStream(tmp);
        try {
            p.store(new OutputStreamWriter(out, "UTF-8"), "AngelChip proxy profile (SOCKS5). Mat khau luu dang chu thuong.");
        } finally { out.close(); }
        java.nio.file.Files.move(tmp.toPath(), f.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
    }
}
