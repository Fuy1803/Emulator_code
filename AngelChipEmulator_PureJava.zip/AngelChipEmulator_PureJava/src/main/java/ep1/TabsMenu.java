package ep1;

import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import org.microemu.app.ui.swing.SwingDialogWindow;

/** Menu AngelChip -> "Proxy cho từng tab". */
public final class TabsMenu implements ActionListener {
    private final Frame owner;

    public TabsMenu(Frame owner) { this.owner = owner; }

    public void actionPerformed(ActionEvent e) {
        TabProxyDialog d = new TabProxyDialog();
        if (SwingDialogWindow.show(owner, "Proxy cho từng tab", d, true) && d.save()) {
            JOptionPane.showMessageDialog(owner, "Đã lưu. Áp dụng cho kết nối kế tiếp của từng tab (không cần khởi động lại cửa sổ).");
        }
    }
}
