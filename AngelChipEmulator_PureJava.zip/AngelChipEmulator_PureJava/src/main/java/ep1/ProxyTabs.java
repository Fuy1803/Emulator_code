package ep1;

import java.io.*;
import java.net.*;
import java.util.*;
import javax.net.ssl.SSLSocketFactory;

/**
 * Proxy SOCKS5 theo tung cua so (profile) va theo tung tab (goi game).
 * Khong co fallback: proxy hong -> ket noi cua tab do that bai, KHONG bao gio ket noi truc tiep thay the.
 */
public final class ProxyTabs {
    private static final String TAG = "[ProxyTab] ";
    public static final int CONNECT_TIMEOUT_MS = 20000;

    private static volatile String profile;          // null = khong co --proxyProfile
    private static volatile File file;
    private static ProxySettings cur = new ProxySettings();
    private static long seenMtime = -1, seenLen = -1;
    private static boolean authInstalled;
    private static final Set<String> loopbackLogged = Collections.synchronizedSet(new HashSet<String>());

    private static final Map<String, String[]> REGISTRY = new HashMap<String, String[]>(); // "host:port" -> {user,pass}
    private static final ThreadLocal<String[]> CURRENT = new ThreadLocal<String[]>();      // {host,port,user,pass}

    private static volatile String lastHost;
    private static volatile int lastPort;

    /** Dich game (host, cong) gan nhat cua cua so nay, hoac null neu chua co. */
    static String[] lastTarget() {
        String h = lastHost;
        return h == null ? null : new String[] { h, String.valueOf(lastPort) };
    }

    private ProxyTabs() {}

    /* ---------------------------------------------------------------- khoi dong */

    /** Goi tu Main.main: tim va BO "--proxyProfile <ten>" khoi danh sach tham so. */
    public static void init(List args) {
        String name = null;
        try {
            for (Iterator it = args.iterator(); it.hasNext();) {
                Object o = it.next();
                if (o instanceof String && "--proxyProfile".equalsIgnoreCase((String) o)) {
                    it.remove();
                    if (it.hasNext()) { Object v = it.next(); it.remove(); if (v instanceof String) name = (String) v; }
                }
            }
        } catch (Throwable t) {
            log("loi doc tham so --proxyProfile: " + t);
        }
        try {
            installAuth();
        } catch (Throwable ignore) {}
        if (name != null) name = sanitize(name);
        if (name == null || name.length() == 0) {
            profile = null; file = null;
            log("chua co profile (khong co --proxyProfile) -> proxy TAT cho moi tab");
        } else {
            profile = name;
            file = new File(new File(System.getProperty("user.home"), ".microemulator"), "proxy_" + name + ".properties");
            reload(true);
            log("profile=" + name + " file=" + file.getPath() + " (chi doc/ghi file nay)");
        }
        log("kiem tra JVM-wide: socksProxyHost=" + System.getProperty("socksProxyHost")
                + " socksProxyPort=" + System.getProperty("socksProxyPort")
                + " java.net.socks.username=" + (System.getProperty("java.net.socks.username") == null ? "null" : "(co)"));
    }

    private static String sanitize(String n) {
        StringBuffer b = new StringBuffer();
        for (int i = 0; i < n.length() && i < 40; i++) {
            char c = n.charAt(i);
            boolean ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == '-' || c == '.';
            b.append(ok ? c : '_');
        }
        String r = b.toString();
        while (r.startsWith(".")) r = "_" + r.substring(1);
        if (!r.equals(n)) log("ten profile da doi thanh '" + r + "' (chi cho phep chu, so, _ - .)");
        return r;
    }

    public static boolean hasProfile() { return profile != null; }
    public static String profileName() { return profile; }
    public static File profileFile() { return file; }
    public static final String NO_PROFILE_TEXT = "Chưa có profile (thêm --proxyProfile vào file .bat)";

    /* ---------------------------------------------------------------- cai dat */

    private static synchronized void reload(boolean force) {
        File f = file;
        if (f == null) return;
        long m = f.lastModified(), l = f.length();
        if (!force && m == seenMtime && l == seenLen) return;
        try {
            cur = ProxySettings.load(f);
            seenMtime = m; seenLen = l;
        } catch (Throwable t) {
            seenMtime = m; seenLen = l; // khong thu lai lien tuc; giu cai dat cu
            log("LOI doc " + f.getName() + ": " + t + " (giu cai dat cu)");
        }
    }

    /** Ban sao cai dat hien tai (cho hop thoai). */
    public static synchronized ProxySettings snapshot() {
        reload(false);
        return cur.copy();
    }

    /** Hop thoai luu: ghi file roi ap dung ngay cho ket noi ke tiep. */
    public static synchronized void apply(ProxySettings s) throws IOException {
        if (file == null) throw new IOException("chua co profile");
        s.save(file);
        cur = s.copy();
        seenMtime = file.lastModified(); seenLen = file.length();
        log("da luu cai dat vao " + file.getName() + " (ap dung cho ket noi ke tiep cua tung tab)");
    }

    /* ---------------------------------------------------------------- tim tab */

    private static final class Ctx extends SecurityManager {
        Class[] get() { return getClassContext(); }
    }
    private static Ctx ctx;
    private static Set<ClassLoader> emuLoaders;

    private static synchronized void prep() {
        if (ctx != null) return;
        Set<ClassLoader> s = new HashSet<ClassLoader>();
        for (ClassLoader l = ProxyTabs.class.getClassLoader(); l != null; l = l.getParent()) s.add(l);
        emuLoaders = s;
        ctx = new Ctx();
    }

    static int tabOfClassName(String n) {
        if (n.startsWith("lib.") || n.startsWith("MrQuyet.")) return 0;   // thu vien dung chung
        if (n.startsWith("b.")) return 2;
        if (n.startsWith("c.")) return 3;
        if (n.startsWith("d.")) return 4;
        if (n.startsWith("e.")) return 5;
        if (n.indexOf('.') < 0 || n.startsWith("com.")) return 1;            // goi mac dinh
        return 0;
    }

    /** 1..5 neu tim duoc, 0 neu khong. Chi xet lop do class loader cua game nap (khong phai loader cua emulator). */
    public static int detectTab() {
        try {
            prep();
            Class[] cs = ctx.get();
            for (int i = 0; i < cs.length; i++) {
                ClassLoader l = cs[i].getClassLoader();
                if (l == null || emuLoaders.contains(l)) continue;
                int t = tabOfClassName(cs[i].getName());
                if (t > 0) return t;
            }
        } catch (Throwable t) {
            log("khong tim duoc tab: " + t);
        }
        return 0;
    }

    /* ---------------------------------------------------------------- tuyen duong */

    private static final class Route {
        boolean direct; String error; String host; int port; String user = ""; String pass = ""; boolean viaDefault;
    }

    private static Route resolve(int tab) {
        Route r = new Route();
        if (profile == null) { r.direct = true; return r; }
        ProxySettings s;
        synchronized (ProxyTabs.class) { reload(false); s = cur; }
        ProxySettings.Entry e;
        if (tab >= 1 && tab <= ProxySettings.TABS) {
            ProxySettings.Entry t = s.tabs[tab - 1];
            if (t.mode == ProxySettings.OFF) { r.direct = true; return r; }
            if (t.mode == ProxySettings.OWN) e = t;
            else { r.viaDefault = true; e = s.def; if (!e.enabled) { r.direct = true; return r; } }
        } else {
            r.viaDefault = true; e = s.def;
            if (!e.enabled) { r.direct = true; return r; }
        }
        if (!e.valid()) { r.error = "cau hinh proxy khong hop le (thieu host hoac port)"; return r; }
        r.host = e.host; r.port = e.port; r.user = e.user; r.pass = e.pass;
        return r;
    }

    static String maskUser(String u) {
        if (u == null || u.length() == 0) return "khong user";
        return "user " + u.substring(0, Math.min(2, u.length())) + "***";
    }

    private static String where(Route r) { return r.host + ":" + r.port + " (" + maskUser(r.user) + ")"; }

    private static boolean isLoopback(String h) {
        if (h == null) return false;
        String x = h.trim().toLowerCase();
        return x.equals("localhost") || x.startsWith("127.") || x.equals("::1") || x.equals("[::1]") || x.equals("0:0:0:0:0:0:0:1");
    }

    /** Chi khi chay voi -Dep1.debug=true: them 1 dong ghi cong cuc bo de doi chieu voi log may chu thu. */
    private static Socket dbg(int tab, Socket s, String host, int port) {
        if (Boolean.getBoolean("ep1.debug")) log("  [debug] " + tabLabel(tab) + " cong-cuc-bo=" + s.getLocalPort() + " dich=" + host + ":" + port);
        return s;
    }

    private static String tabLabel(int tab) { return tab > 0 ? "tab " + tab : "tab ? (khong xac dinh, dung mac dinh cua so)"; }

    private static void register(Route r) {
        synchronized (REGISTRY) { REGISTRY.put(r.host.toLowerCase() + ":" + r.port, new String[] { r.user, r.pass }); }
    }

    /* ---------------------------------------------------------------- socket */

    /** Thay cho "new Socket(host, port)" trong SocketConnection. */
    public static Socket connect(String host, int port) throws IOException {
        int tab = detectTab();
        if (isLoopback(host)) {
            if (loopbackLogged.add(tab + "|" + host + ":" + port))
                log(tabLabel(tab) + " -> truc tiep (loopback " + host + ":" + port + ", khong qua proxy)");
            return dbg(tab, direct(host, port), host, port);
        }
        lastHost = host; lastPort = port;   // EP2: nho dich game gan nhat (chi de "Kiem tra proxy" hien/dung lam dich)
        Route r = resolve(tab);
        if (r.direct) {
            log(tabLabel(tab) + " -> truc tiep (proxy tat)");
            return dbg(tab, direct(host, port), host, port);
        }
        if (r.error != null) {
            log(tabLabel(tab) + " -> LOI: " + r.error + "; ket noi that bai, KHONG ket noi truc tiep");
            throw new IOException("ProxyTab " + tabLabel(tab) + ": " + r.error);
        }
        log(tabLabel(tab) + " -> " + where(r) + " => dich " + host + ":" + port);
        register(r);
        Socket s = null;
        final boolean[] timedOut = new boolean[1];
        TimerTask wd = null;
        try {
            InetSocketAddress pa = new InetSocketAddress(r.host, r.port);
            if (pa.isUnresolved()) throw new IOException("khong phan giai duoc ten may proxy " + r.host);
            s = new Socket(new Proxy(Proxy.Type.SOCKS, pa));
            CURRENT.set(new String[] { r.host, String.valueOf(r.port), r.user, r.pass });
            wd = watchdog(s, timedOut);
            s.connect(target(host, port), CONNECT_TIMEOUT_MS);
            return dbg(tab, s, host, port);
        } catch (IOException e) {
            closeQuiet(s);
            if (timedOut[0]) e = new SocketTimeoutException("het thoi gian cho " + (WATCHDOG_MS / 1000) + " giay (proxy khong tra loi)");
            failLog(tab, r, e);
            throw new IOException("ProxyTab " + tabLabel(tab) + ": " + e.getMessage());
        } catch (RuntimeException e) {
            closeQuiet(s);
            failLog(tab, r, e);
            throw new IOException("ProxyTab " + tabLabel(tab) + ": " + e);
        } finally {
            if (wd != null) wd.cancel();
            CURRENT.remove();
        }
    }

    /** Doc lap voi phien ban JDK: neu bat tay SOCKS treo qua WATCHDOG_MS thi dong socket de connect() nem loi. */
    private static final long WATCHDOG_MS = CONNECT_TIMEOUT_MS + 2000L;
    private static Timer timer;
    private static synchronized TimerTask watchdog(final Socket s, final boolean[] flag) {
        if (timer == null) timer = new Timer("ProxyTab-watchdog", true);
        TimerTask t = new TimerTask() { public void run() { flag[0] = true; closeQuiet(s); } };
        timer.schedule(t, WATCHDOG_MS);
        return t;
    }

    private static void failLog(int tab, Route r, Exception e) {
        log(tabLabel(tab) + " -> LOI qua proxy " + where(r) + ": " + e.getClass().getSimpleName() + ": " + e.getMessage()
                + "; ket noi that bai, KHONG ket noi truc tiep");
    }

    private static void closeQuiet(Socket s) { if (s != null) try { s.close(); } catch (Throwable ignore) {} }

    private static boolean isIpLiteral(String h) {
        return h.matches("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}") || h.indexOf(':') >= 0;
    }

    /** IP thuat: dich truc tiep; ten may: de proxy tu phan giai DNS (khong ro ri DNS ve may nay). */
    private static InetSocketAddress target(String host, int port) throws IOException {
        if (isIpLiteral(host)) return new InetSocketAddress(InetAddress.getByName(host), port);
        return InetSocketAddress.createUnresolved(host, port);
    }

    private static Socket direct(String host, int port) throws IOException {
        Socket s = new Socket(Proxy.NO_PROXY);
        try {
            s.connect(new InetSocketAddress(host, port));
            return s;
        } catch (IOException e) { closeQuiet(s); throw e; }
        catch (RuntimeException e) { closeQuiet(s); throw e; }
    }

    /** Thay cho factory.createSocket(host, port) trong ssl.Connection. */
    public static Socket sslWrap(SSLSocketFactory f, String host, int port) throws IOException {
        Socket raw = connect(host, port);
        try {
            return f.createSocket(raw, host, port, true);
        } catch (IOException e) { closeQuiet(raw); throw e; }
        catch (RuntimeException e) { closeQuiet(raw); throw e; }
    }

    /** Thay cho url.openConnection() trong http.Connection. */
    public static URLConnection openHttp(URL u) throws IOException {
        int tab = detectTab();
        String host = u.getHost();
        if (isLoopback(host)) {
            if (loopbackLogged.add(tab + "|http|" + host + ":" + u.getPort()))
                log(tabLabel(tab) + " -> truc tiep (loopback http " + host + ", khong qua proxy)");
            return u.openConnection(Proxy.NO_PROXY);
        }
        Route r = resolve(tab);
        if (r.direct) {
            log(tabLabel(tab) + " -> truc tiep (proxy tat) [http " + host + "]");
            return u.openConnection(Proxy.NO_PROXY);
        }
        if (r.error != null) {
            log(tabLabel(tab) + " -> LOI: " + r.error + " [http]; that bai, KHONG ket noi truc tiep");
            throw new IOException("ProxyTab " + tabLabel(tab) + ": " + r.error);
        }
        log(tabLabel(tab) + " -> " + where(r) + " => dich http " + host);
        register(r);
        InetSocketAddress pa = new InetSocketAddress(r.host, r.port);
        if (pa.isUnresolved()) {
            log(tabLabel(tab) + " -> LOI: khong phan giai duoc ten may proxy " + r.host + " [http]; that bai, KHONG ket noi truc tiep");
            throw new IOException("ProxyTab " + tabLabel(tab) + ": khong phan giai duoc ten may proxy");
        }
        URLConnection c = u.openConnection(new Proxy(Proxy.Type.SOCKS, pa));
        c.setConnectTimeout(CONNECT_TIMEOUT_MS);
        c.setReadTimeout(30000);
        return c;
    }

    /* ---------------------------------------------------------------- xac thuc */

    private static synchronized void installAuth() {
        if (authInstalled) return;
        Authenticator.setDefault(new Auth());
        authInstalled = true;
    }

    /** Tra loi theo dia chi proxy (getRequestingHost/Port), moi proxy mot user/pass. */
    private static final class Auth extends Authenticator {
        protected PasswordAuthentication getPasswordAuthentication() {
            String h = getRequestingHost();
            int p = getRequestingPort();
            String site = getRequestingSite() == null ? null : getRequestingSite().getHostAddress();
            String[] c = CURRENT.get();
            if (c != null && String.valueOf(p).equals(c[1])
                    && (c[0].equalsIgnoreCase(h) || (site != null && c[0].equals(site)))) {
                return new PasswordAuthentication(c[2], c[3].toCharArray());
            }
            synchronized (REGISTRY) {
                String[] v = REGISTRY.get((h == null ? "" : h.toLowerCase()) + ":" + p);
                if (v == null && site != null) v = REGISTRY.get(site + ":" + p);
                if (v != null) return new PasswordAuthentication(v[0], v[1].toCharArray());
            }
            return null;
        }
    }

    /* ---------------------------------------------------------------- log */

    static void log0(String m) { System.out.println(m); System.out.flush(); }

    static void log(String m) {
        System.out.println(TAG + m);
        System.out.flush();
    }
}
