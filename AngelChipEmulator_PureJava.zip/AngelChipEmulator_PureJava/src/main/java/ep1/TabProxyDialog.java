package ep1;

import java.awt.*;
import javax.swing.*;
import org.microemu.app.ui.swing.SwingDialogPanel;

/** Hop thoai "Proxy cho tung tab": moi tab 3 lua chon Tat / Mac dinh / Rieng. */
public class TabProxyDialog extends SwingDialogPanel {
    private final boolean has = ProxyTabs.hasProfile();
    private final ProxySettings s;
    private final JRadioButton[][] rb = new JRadioButton[ProxySettings.TABS][3];
    private final JTextField[] host = new JTextField[ProxySettings.TABS];
    private final JTextField[] port = new JTextField[ProxySettings.TABS];
    private final JTextField[] user = new JTextField[ProxySettings.TABS];
    private final JPasswordField[] pass = new JPasswordField[ProxySettings.TABS];
    private final JButton[] chk = new JButton[ProxySettings.TABS];
    private final JLabel[] res = new JLabel[ProxySettings.TABS];
    private final JButton chkAll = new JButton("Kiểm tra tất cả");
    private final JLabel tgt = new JLabel(" ");
    private static final Color GREEN = new Color(0, 140, 0), RED = new Color(200, 0, 0);

    public TabProxyDialog() {
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(2, 4, 2, 4);
        c.gridx = 0; c.gridy = 0; c.gridwidth = 10;
        if (!has) {
            s = null;
            JLabel l = new JLabel(ProxyTabs.NO_PROFILE_TEXT);
            l.setForeground(Color.red);
            add(l, c);
            c.gridy = 1;
            add(new JLabel("Không có profile thì proxy TẮT cho mọi tab."), c);
            btOk.setEnabled(false);
            return;
        }
        s = ProxyTabs.snapshot();
        JLabel w = new JLabel("(*) Chỉ hỗ trợ SOCKS5. Proxy lỗi thì tab đó mất kết nối, không nối trực tiếp.");
        w.setForeground(Color.red);
        add(w, c);
        c.gridy = 1;
        String d = s.def.enabled && s.def.valid()
                ? s.def.host + ":" + s.def.port + " (" + ProxyTabs.maskUser(s.def.user) + ")"
                : "TẮT (chưa bật/đặt trong \"Cài đặt Proxy\")";
        add(new JLabel("Profile: " + ProxyTabs.profileName() + "   |   Mặc định của cửa sổ: " + d), c);
        c.gridwidth = 1; c.gridy = 2;
        String[] hd = { "Tab", "Tắt", "Mặc định", "Riêng", "Host", "Port", "User", "Mật khẩu", "", "Kết quả kiểm tra" };
        for (int i = 0; i < hd.length; i++) {
            c.gridx = i;
            JLabel h = new JLabel(hd[i]);
            h.setFont(h.getFont().deriveFont(Font.BOLD));
            add(h, c);
        }
        for (int t = 0; t < ProxySettings.TABS; t++) {
            final int ti = t;
            ProxySettings.Entry e = s.tabs[t];
            c.gridy = 3 + t;
            c.gridx = 0; add(new JLabel("Hải tặc " + (t + 1)), c);
            ButtonGroup g = new ButtonGroup();
            for (int m = 0; m < 3; m++) {
                rb[t][m] = new JRadioButton();
                g.add(rb[t][m]);
                c.gridx = 1 + m; add(rb[t][m], c);
                rb[t][m].addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent ev) { refresh(ti); }
                });
            }
            rb[t][e.mode == ProxySettings.OFF ? 0 : (e.mode == ProxySettings.OWN ? 2 : 1)].setSelected(true);
            host[t] = new JTextField(e.host, 14);
            port[t] = new JTextField(e.port > 0 ? String.valueOf(e.port) : "", 5);
            user[t] = new JTextField(e.user, 8);
            pass[t] = new JPasswordField(e.pass, 8);
            c.gridx = 4; add(host[t], c);
            c.gridx = 5; add(port[t], c);
            c.gridx = 6; add(user[t], c);
            c.gridx = 7; add(pass[t], c);
            chk[t] = new JButton("Kiểm tra");
            res[t] = new JLabel(" ");
            res[t].setPreferredSize(new Dimension(320, 20));
            c.gridx = 8; add(chk[t], c);
            c.gridx = 9; add(res[t], c);
            chk[t].addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent ev) { checkOne(ti); }
            });
            refresh(t);
        }
        c.gridx = 0; c.gridy = 10; c.gridwidth = 4;
        chkAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent ev) { checkAll(); }
        });
        add(chkAll, c);
        c.gridx = 4; c.gridwidth = 6;
        tgt.setText("Đích kiểm tra: " + ProxyCheck.targetText());
        add(tgt, c);
        c.gridx = 0; c.gridy = 9; c.gridwidth = 10;
        add(new JLabel("Thay đổi áp dụng cho kết nối kế tiếp của tab đó (không cần khởi động lại cửa sổ)."), c);
    }

    private void refresh(int t) {
        boolean own = rb[t][2].isSelected();
        host[t].setEnabled(own); port[t].setEnabled(own); user[t].setEnabled(own); pass[t].setEnabled(own);
        boolean off = rb[t][0].isSelected(), defOff = rb[t][1].isSelected() && !s.def.enabled;
        chk[t].setEnabled(!off && !defOff);
        if (off) show(t, Color.gray, "Tắt - nối thẳng, không có proxy để kiểm tra");
        else if (defOff) show(t, Color.gray, "Mặc định đang tắt - nối thẳng");
        else show(t, Color.gray, " ");
    }

    private void show(int t, Color c, String text) { res[t].setForeground(c); res[t].setText(text); }

    /** Proxy hieu luc cua dong t: Rieng = cac o cua dong; Mac dinh = mac dinh cua cua so; Tat/Mac dinh tat = null. */
    private ProxySettings.Entry eff(int t) {
        if (rb[t][0].isSelected()) return null;
        if (rb[t][1].isSelected()) return s.def.enabled ? s.def : null;
        ProxySettings.Entry e = new ProxySettings.Entry();
        e.host = host[t].getText().trim();
        try { e.port = Integer.parseInt(port[t].getText().trim()); } catch (Exception ex) { e.port = -1; }
        e.user = user[t].getText().trim();
        e.pass = new String(pass[t].getPassword());
        return e;
    }

    private static String key(ProxySettings.Entry e) { return e.host + "|" + e.port + "|" + e.user + "|" + e.pass; }

    private void checkOne(final int t) {
        final ProxySettings.Entry e = eff(t);
        if (e == null) return;
        if (!e.valid()) { show(t, RED, "Nhập Host và Port hợp lệ trước"); return; }
        final String[] tg = ProxyCheck.target();
        tgt.setText("Đích kiểm tra: " + ProxyCheck.targetText());
        chk[t].setEnabled(false);
        show(t, Color.gray, "Đang kiểm tra...");
        Thread th = new Thread(new Runnable() {
            public void run() {
                final ProxyCheck.Result r = ProxyCheck.checkAndLog("tab " + (t + 1), e.host, e.port, e.user, e.pass, tg);
                SwingUtilities.invokeLater(new Runnable() { public void run() { show(t, r.alive ? GREEN : RED, r.text()); chk[t].setEnabled(true); } });
            }
        }, "ProxyCheck-" + (t + 1));
        th.setDaemon(true);
        th.start();
    }

    /** Kiem tra tat ca cac dong cung luc; moi proxy khac nhau (host, cong, user, mat khau) chi kiem tra 1 lan. */
    private void checkAll() {
        final String[] tg = ProxyCheck.target();
        tgt.setText("Đích kiểm tra: " + ProxyCheck.targetText());
        final java.util.LinkedHashMap<String, java.util.List<Integer>> groups = new java.util.LinkedHashMap<String, java.util.List<Integer>>();
        final java.util.Map<String, ProxySettings.Entry> ent = new java.util.HashMap<String, ProxySettings.Entry>();
        for (int t = 0; t < ProxySettings.TABS; t++) {
            ProxySettings.Entry e = eff(t);
            if (e == null) { refresh(t); continue; }                       // Tat / Mac dinh tat: bo qua
            if (!e.valid()) { show(t, RED, "Nhập Host và Port hợp lệ trước"); continue; }
            String k = key(e);
            if (!groups.containsKey(k)) { groups.put(k, new java.util.ArrayList<Integer>()); ent.put(k, e); }
            groups.get(k).add(t);
            chk[t].setEnabled(false);
            show(t, Color.gray, "Đang kiểm tra...");
        }
        if (groups.isEmpty()) return;
        chkAll.setEnabled(false);
        final java.util.concurrent.atomic.AtomicInteger left = new java.util.concurrent.atomic.AtomicInteger(groups.size());
        for (final java.util.Map.Entry<String, java.util.List<Integer>> g : groups.entrySet()) {
            final ProxySettings.Entry e = ent.get(g.getKey());
            final java.util.List<Integer> rows = g.getValue();
            StringBuffer lb = new StringBuffer("tab ");
            for (int i = 0; i < rows.size(); i++) lb.append(i > 0 ? "," : "").append(rows.get(i) + 1);
            final String label = lb.toString();
            Thread th = new Thread(new Runnable() {
                public void run() {
                    final ProxyCheck.Result r = ProxyCheck.checkAndLog(label, e.host, e.port, e.user, e.pass, tg);
                    SwingUtilities.invokeLater(new Runnable() {
                        public void run() {
                            for (int i = 0; i < rows.size(); i++) { int t = rows.get(i); show(t, r.alive ? GREEN : RED, r.text()); chk[t].setEnabled(true); }
                            if (left.decrementAndGet() == 0) chkAll.setEnabled(true);
                        }
                    });
                }
            }, "ProxyCheck-all");
            th.setDaemon(true);
            th.start();
        }
    }

    public boolean check(boolean ok) {
        if (!ok || !has) return true;
        for (int t = 0; t < ProxySettings.TABS; t++) {
            if (!rb[t][2].isSelected()) continue;
            boolean bad = host[t].getText().trim().length() == 0;
            try { int n = Integer.parseInt(port[t].getText().trim()); if (n < 1 || n > 65535) bad = true; } catch (Exception e) { bad = true; }
            if (bad) {
                JOptionPane.showMessageDialog(this, "Hải tặc " + (t + 1) + ": chọn \"Riêng\" thì phải nhập Host và Port hợp lệ (1-65535).");
                return false;
            }
        }
        return true;
    }

    public boolean save() {
        if (!has) return false;
        ProxySettings n = s.copy();
        for (int t = 0; t < ProxySettings.TABS; t++) {
            ProxySettings.Entry e = n.tabs[t];
            e.mode = rb[t][0].isSelected() ? ProxySettings.OFF : (rb[t][2].isSelected() ? ProxySettings.OWN : ProxySettings.DEFAULT);
            e.host = host[t].getText().trim();
            int pn;
            try { pn = Integer.parseInt(port[t].getText().trim()); } catch (Exception ex) { pn = -1; }
            e.port = pn;
            e.user = user[t].getText().trim();
            e.pass = new String(pass[t].getPassword());
        }
        try {
            ProxyTabs.apply(n);
            return true;
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Không lưu được: " + ex.getMessage());
            return false;
        }
    }
}
