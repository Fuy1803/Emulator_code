package ep1;

import java.io.*;
import java.net.*;

/**
 * EP2: kiem tra proxy SOCKS5 song/chet. Tu nhan socket (khong dung Authenticator, khong dung ProxyTabs.connect),
 * chi noi TOI PROXY: chao SOCKS5 -> (RFC 1929 neu co user) -> CONNECT toi dich -> dong ngay, khong gui du lieu.
 * Khong doi cai dat, khong mo ket noi game, khong noi thang di dau.
 */
public final class ProxyCheck {
    public static final int TOTAL_MS = 10000;
    public static final String FALLBACK_HOST = "www.google.com";
    public static final int FALLBACK_PORT = 443;

    public static final class Result {
        public final boolean alive; public final long ms; public final String reason;
        Result(boolean a, long ms, String r) { alive = a; this.ms = ms; reason = r; }
        public String text() { return alive ? "Sống - " + ms + " ms" : "Die - " + reason; }
    }

    private ProxyCheck() {}

    /** {host, cong, mota}: dich game gan nhat neu co, neu khong thi www.google.com:443. */
    public static String[] target() {
        String[] t = ProxyTabs.lastTarget();
        if (t != null) return new String[] { t[0], t[1], "máy chủ game kết nối gần nhất" };
        return new String[] { FALLBACK_HOST, String.valueOf(FALLBACK_PORT), "mặc định, chưa có kết nối game nào" };
    }

    public static String targetText() {
        String[] t = target();
        return t[0] + ":" + t[1] + " (" + t[2] + ")";
    }

    /** Kiem tra va ghi 1 dong log. label vd "tab 3", "tab 1,4", "mac dinh". */
    public static Result checkAndLog(String label, String host, int port, String user, String pass, String[] target) {
        Result r = check(host, port, user, pass, target[0], Integer.parseInt(target[1]));
        ProxyTabs.log0(fold("[ProxyCheck] " + label + " " + host + ":" + port + " (" + ProxyTabs.maskUser(user) + ") -> "
                + (r.alive ? "Song " + r.ms + " ms (dich " + target[0] + ":" + target[1] + ")" : "Die: " + r.reason
                        + " (dich " + target[0] + ":" + target[1] + ")")));
        return r;
    }

    /** Bo dau tieng Viet trong dong log (console/file log Windows hay khong hien UTF-8). Giao dien van co dau. */
    static String fold(String s) {
        String n = java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        return n.replace('đ', 'd').replace('Đ', 'D');
    }

    private static Result die(String why) { return new Result(false, 0, why); }

    private static void tmo(Socket s, long deadline) throws IOException {
        long left = (deadline - System.nanoTime()) / 1000000L;
        if (left <= 0) throw new SocketTimeoutException("deadline");
        s.setSoTimeout((int) Math.min(left, Integer.MAX_VALUE));
    }

    private static void readFully(Socket s, InputStream in, byte[] b, int n, long deadline) throws IOException {
        int got = 0;
        while (got < n) {
            tmo(s, deadline);
            int k = in.read(b, got, n - got);
            if (k < 0) throw new EOFException();
            got += k;
        }
    }

    private static boolean isIp(String h) {
        return h.matches("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}");
    }

    public static Result check(String host, int port, String user, String pass, String tHost, int tPort) {
        long t0 = System.nanoTime(), deadline = t0 + TOTAL_MS * 1000000L;
        user = user == null ? "" : user; pass = pass == null ? "" : pass;
        Socket s = new Socket();
        int stage = 0;   // 0 ket noi proxy, 1 chao, 2 dang nhap, 3 CONNECT
        try {
            byte[] ub, pb;
            try { ub = user.getBytes("UTF-8"); pb = pass.getBytes("UTF-8"); } catch (UnsupportedEncodingException e) { return die("lỗi mã hóa"); }
            if (ub.length > 255 || pb.length > 255) return die("user hoặc mật khẩu quá dài (tối đa 255 byte)");
            byte[] th;
            try { th = tHost.getBytes("UTF-8"); } catch (UnsupportedEncodingException e) { return die("lỗi mã hóa"); }
            InetSocketAddress pa = new InetSocketAddress(host, port);
            if (pa.isUnresolved()) return die("không kết nối được proxy (không tìm thấy tên máy chủ proxy)");
            s.connect(pa, (int) Math.max(1, (deadline - System.nanoTime()) / 1000000L));
            InputStream in = s.getInputStream();
            OutputStream out = s.getOutputStream();
            stage = 1;
            if (ub.length > 0) out.write(new byte[] { 5, 2, 0, 2 }); else out.write(new byte[] { 5, 1, 0 });
            out.flush();
            byte[] b = new byte[4];
            readFully(s, in, b, 2, deadline);
            if (b[0] != 5) return die("proxy không phải SOCKS5");
            int m = b[1] & 0xff;
            if (m == 0xff) return die(ub.length > 0 ? "proxy từ chối cách đăng nhập (sai user hoặc mật khẩu?)" : "proxy yêu cầu user và mật khẩu");
            if (m == 2) {
                if (ub.length == 0) return die("proxy không phải SOCKS5 (đòi đăng nhập dù không được mời)");
                stage = 2;
                byte[] a = new byte[3 + ub.length + pb.length];
                a[0] = 1; a[1] = (byte) ub.length;
                System.arraycopy(ub, 0, a, 2, ub.length);
                a[2 + ub.length] = (byte) pb.length;
                System.arraycopy(pb, 0, a, 3 + ub.length, pb.length);
                out.write(a); out.flush();
                readFully(s, in, b, 2, deadline);
                if (b[1] != 0) return die("sai user hoặc mật khẩu");
            } else if (m != 0) {
                return die("proxy không phải SOCKS5 (phương thức lạ " + m + ")");
            }
            stage = 3;
            byte[] q;
            if (isIp(tHost)) {
                String[] o = tHost.split("\\.");
                q = new byte[10];
                q[3] = 1;
                for (int i = 0; i < 4; i++) q[4 + i] = (byte) Integer.parseInt(o[i]);
            } else {
                q = new byte[7 + th.length];
                q[3] = 3; q[4] = (byte) th.length;
                System.arraycopy(th, 0, q, 5, th.length);
            }
            q[0] = 5; q[1] = 1; q[2] = 0;
            q[q.length - 2] = (byte) (tPort >> 8); q[q.length - 1] = (byte) tPort;
            out.write(q); out.flush();
            readFully(s, in, b, 4, deadline);
            if (b[0] != 5) return die("proxy không phải SOCKS5");
            if (b[1] != 0) return die("proxy không cho kết nối tới máy chủ (mã " + (b[1] & 0xff) + ")");
            return new Result(true, (System.nanoTime() - t0) / 1000000L, null);
        } catch (SocketTimeoutException e) {
            return die("hết thời gian chờ (" + (TOTAL_MS / 1000) + " giây)");
        } catch (EOFException e) {
            return die(stage == 1 ? "proxy không phải SOCKS5 (đóng kết nối ngay)"
                    : stage == 2 ? "sai user hoặc mật khẩu (proxy đóng kết nối)" : "proxy đóng kết nối giữa chừng");
        } catch (IOException e) {
            return die(stage == 0 ? "không kết nối được proxy" : "lỗi mạng khi nói chuyện với proxy (" + e.getClass().getSimpleName() + ")");
        } catch (RuntimeException e) {
            return die("lỗi không rõ (" + e.getClass().getSimpleName() + ")");
        } finally {
            try { s.close(); } catch (IOException ignore) {}
        }
    }
}
