# Bàn giao chuyển đổi kiến trúc: Từ vá Bytecode ASM (EP1–P8) sang 100% Mã nguồn Java thuần

Tài liệu này mô tả thay đổi kiến trúc của dự án **AngelChipEmulator** để các AI / lập trình viên tiếp nhận sau này nắm đúng nền mã nguồn hiện tại và **không quay lại quy trình dịch ngược hay vá bytecode ASM cũ**.

## 1. Bối cảnh & lý do chuyển đổi

* **Trước đây (nhánh `ep1` → `p8`):** Dự án dựa trên file đóng gói `AngelChipEmulator_V2Proxy.jar` đã bị làm rối mã (505 lớp `.class`, trong đó có 183 lớp ở package gốc dạng `A.class`/`a.class` gây xung đột hoa/thường trên Windows). Mỗi phiên bản mới (`P3`..`P8`) phải dùng `ASM` (`Ep1Patch`, `P3Patch`, `P4Patch`, `P6Patch`, `P7Patch`, `P8Patch`) để vá đè bytecode lên `.jar` bản trước, và một số chỗ như `InputGuard.clearImState()` phải dùng reflection truy cập tên trường rối mã (`"c"`, `"a"`).

* **Hiện tại (`AngelChipEmulator_PureJava`):** Toàn bộ dự án đã được chuyển sang **100% mã nguồn `.java` thuần** dựa trực tiếp trên mã nguồn mở [MicroEmulator (`barteo/microemu`)](https://github.com/barteo/microemu) (gồm 5 module desktop: `microemu-cldc`, `microemu-midp`, `microemu-javase`, `microemu-javase-swing`, `microemu-jsr-75` + tài nguyên `microemu-injected.jar`).

* **Kết quả:** Không còn lớp bị rối mã, không còn chuỗi vá chồng tầng `ep1` → `p8`, không còn viết patch ASM. Mọi chỉnh sửa từ nay thực hiện trực tiếp trong `src/main/java/` và đóng gói thành 1 file `.jar` duy nhất chạy được trên Java 8+.

## 2. Đối chiếu các bản vá ASM cũ sang mã nguồn Java thuần hiện tại

| Bản vá cũ (Bytecode ASM) | Đã thay bằng mã nguồn Java thuần tại | Chi tiết thay đổi | 
| ----- | ----- | ----- | 
| `Ep1Patch` (Config, Main, Socket, SSL, HTTP) | `org/microemu/app/Config.java`, `org/microemu/app/Main.java`, `org/microemu/cldc/socket/SocketConnection.java`, `org/microemu/cldc/ssl/Connection.java`, `org/microemu/cldc/http/Connection.java` | Gọi trực tiếp `ep1.ProxyTabs.init(params)`, `connect()`, `sslWrap()`, `openHttp()`; `Config.getProxy()` trả `null`; thêm menu `AngelChip` (đủ 4 mục) và dùng `angelchip_config2.xml` + `--tabId`. | 
| `P3Patch` + `P4Patch` (Menu Tối ưu, skip/paintSleep, Display.repaint, gamePaintHook) | `org/microemu/app/Main.java`, `org/microemu/app/ui/swing/SwingDisplayComponent.java`, `org/microemu/device/j2se/J2SEDeviceDisplay.java`, `javax/microedition/lcdui/Display.java` | Gắn `ep3.ToiUuMenu.create(this)`, gọi trực tiếp `ToiUu.skip()`, `ToiUu.paintSleep()`, `ToiUu.gamePaintHook()`, `ToiUu.sleepingNow()`; đổi `Display.repaint(Displayable,int,int,int,int)` thành `public`. | 
| `P6Patch` (`EventDispatcher.serviceRepaints`) | `org/microemu/device/ui/EventDispatcher.java` | Đổi `serviceRepaintsLock.wait()` thành `serviceRepaintsLock.wait(1000L)`. | 
| `P7Patch` (`InputGuard` trên `n.class`, `J2SEInputMethod`, `Display.setCurrent`) | `javax/microedition/lcdui/Display.java` (`DisplayAccessor`), `org/microemu/device/j2se/J2SEInputMethod.java`, `ep3/InputGuard.java` | Chèn trực tiếp `InputGuard.dropDa()`, `dropIm()`, `onSetCurrent()`; bỏ reflection tên trường `"c"`/`"a"`, thay bằng gọi trực tiếp `J2SEInputMethod.clearPressedState()`. | 
| `P8Patch` (`Displayable.repaint` & chế độ tự ngủ cũ) | `javax/microedition/lcdui/Displayable.java`, `javax/microedition/lcdui/AngelChipSleepCanvas.java` | Thay lớp `a.class` cũ bằng `AngelChipSleepCanvas` thuần Java; chỉ kích hoạt tự ngủ cũ khi `this == currentDisplay.getCurrent()` (bản game nền trong jar ghép không thể làm nhảy màn hình). | 
| Giao diện thiết bị (Skin) AngelChip | `src/main/resources/org/microemu/device/resizable/gray_device.xml`, `black_device.xml` & `Config.java` | Tích hợp sẵn 2 skin **AngelChip Gray** và **AngelChip Black** trong `Config.getDeviceEntries()`. | 

## 3. Hai nâng cấp mới đã thêm sau P8

1. **Quản lý Profile trực tiếp trên giao diện (không bắt buộc `.bat`):**

   * Khi mở trực tiếp `.jar` không có `--proxyProfile`, `ep1.ProxyTabs.init()` tự dùng profile `default` để Proxy và Tối ưu hoạt động ngay.

   * Thêm mục **AngelChip → Chọn / Tạo Profile...** (`Main.java` → `ProxyTabs.setProfile()` & `ToiUu.switchProfile()`), đồng bộ tiêu đề cửa sổ `AngelChip Emulator [<profile>]` và tự quét danh sách profile hiện có (`ProxyTabs.listProfiles()`).

   * File `.bat` vẫn được khuyên dùng khi treo nhiều cửa sổ trên VPS để gắn `--proxyProfile <tên>` riêng và ép cờ tiết kiệm RAM (`-Xmx192m`, `-XX:+UseSerialGC`,...).

2. **Trình xem "Log lỗi theo từng tab" siêu nhẹ cho VPS (`ep3/TabErrorLog.java`, `ep3/TabErrorLogDialog.java`):**

   * Chỉ ghi khi phát sinh lỗi/cảnh báo từ `ProxyTabs` (lỗi mạng/proxy từng tab), `Watchdog` (phát hiện đơ), `InputGuard` (`setCurrent` khi ngủ) và `UncaughtExceptionHandler` của các luồng game.

   * Dùng bộ đệm vòng cố định (tối đa 200 dòng/tab, 400 dòng tổng) nên tiêu tốn < 200 KB RAM dù chạy 24/7; không tạo luồng nền, không cập nhật Swing khi hộp thoại đang đóng (\~0% CPU).

   * Truy cập tại **Tối ưu → Log lỗi theo tab** (hiện số lỗi ngay trên mục menu khi mở, có tách tab *Tất cả / Tab 1..5 / Hệ thống*, nút *Xóa* và *Lưu ra file...*).

## 4. Cấu trúc dự án & quy trình build mới

```
AngelChipEmulator_PureJava/
├── pom.xml                               # Maven 1 module, target Java 8 (--release 8), duy nhất 1 dep asm:3.1 cho MIDletClassLoader
├── build.bat / build.sh                  # Build 1 lệnh trên Windows / Linux -> dist/AngelChipEmulator_PureJava.jar
├── .github/workflows/build.yml           # GitHub Actions tự build và xuất Artifact AngelChipEmulator_PureJava.jar
└── src/main/
    ├── java/
    │   ├── ep1/                          # Proxy SOCKS5, kiểm tra proxy, chọn/tạo profile
    │   ├── ep3/                          # Menu Tối ưu, InputGuard, Watchdog, Rescue, TabErrorLog
    │   ├── javax/microedition/           # CLDC, MIDP, JSR-75, Display, Displayable, AngelChipSleepCanvas
    │   └── org/microemu/                 # Core MicroEmulator, Main, Config, Swing UI, J2SE, Socket/SSL/HTTP
    └── resources/                        # Skins (default, resizable, gray_device.xml, black_device.xml), icon, microemu-injected.jar

```

* **Lệnh build chuẩn:** `mvn -B -DskipTests clean package` → xuất file chạy trực tiếp `target/AngelChipEmulator_PureJava.jar` (`Main-Class: org.microemu.app.Main`, bytecode tương thích Java 8 32-bit/64-bit).

* **Build tự động trên GitHub:** Push code lên nhánh `main` (hoặc chạy tay ở tab **Actions** → **Build AngelChipEmulator JAR**) → tải `AngelChipEmulator_PureJava.jar` trong mục **Artifacts**.

## 5. Quy tắc bắt buộc cho AI / lập trình viên phát triển các bản mod sau

1. **KHÔNG dịch ngược `.jar` và KHÔNG viết patch bytecode ASM mới.** Mọi tính năng mới hoặc sửa lỗi phải viết thẳng vào các file `.java` trong `src/main/java/`.

2. **KHÔNG dùng reflection theo tên rối mã** (như `"a"`, `"c"`, `n.class`). Hãy thêm phương thức `public` hoặc gọi trực tiếp lớp/trường thật trong mã nguồn MicroEmulator.

3. **Giữ tương thích Java 8 (`--release 8`) và mã hóa UTF-8** cho tất cả file `.java` (đặc biệt khi dùng chuỗi tiếng Việt trên menu/UI).

4. **Ưu tiên nhẹ CPU/RAM cho VPS:** Không thêm timer tần suất cao hoặc ghi log liên tục khi game chạy bình thường; mọi UI chẩn đoán phải ở dạng lazy (chỉ vẽ khi người dùng mở).

5. **Giữ nguyên các tính năng cốt lõi đã ổn định:** Toàn bộ `ep1` (không fallback kết nối trực tiếp khi proxy lỗi), `ep3` (ngủ toàn cửa sổ, `InputGuard`, `Watchdog`, `Rescue`, `TabErrorLog`), 4 mục menu `AngelChip` + `Chọn / Tạo Profile...`, và bản sửa P8 trong `Displayable.repaint()`.