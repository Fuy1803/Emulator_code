#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v mvn >/dev/null 2>&1; then
  echo "[LOI] Khong tim thay Maven (mvn). Cai Maven hoac dung GitHub Actions (.github/workflows/build.yml)."
  exit 1
fi

mvn -B -DskipTests clean package
mkdir -p dist
cp -f target/AngelChipEmulator_PureJava.jar dist/AngelChipEmulator_PureJava.jar
echo "[THANH CONG] Da tao: dist/AngelChipEmulator_PureJava.jar"
