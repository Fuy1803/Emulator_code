# AngelChipEmulator (100% Java thuần trên nền MicroEmulator)

Dự án này chuyển toàn bộ **AngelChipEmulator_V2Proxy (bản P8)** sang **100% mã nguồn `.java` thuần** dựa trên mã nguồn mở [MicroEmulator (`barteo/microemu`)](https://github.com/barteo/microemu), **không còn dùng dịch ngược hay vá bytecode ASM**.

## Tính năng đã tích hợp sẵn
* **Menu `AngelChip` (đủ 4 mục):**
  * **Chế độ tự ngủ** (đã kèm bản sửa P8: bản game chạy nền trong jar ghép không thể tự kích hoạt làm nhảy màn hình).
  * **Cài đặt Proxy** (SOCKS5 theo từng `--proxyProfile`, kèm kiểm tra proxy sống/die từ `ep1`/`ep2`).
  * **Proxy cho từng tab** (từ `ep1`/`ep2`).
  * **About**.
* **Menu `Tối ưu` (đầy đủ bản P8 — `src/main/java/ep3/`):** Ngủ toàn cửa sổ, tự ngủ sau 1/5/15 phút, giới hạn FPS, cách đánh thức (*Chạm là dậy* / *Chỉ bấm Dậy*), hiển thị CPU/RAM trên thanh trạng thái, chặn phím/chuột lúc ngủ (`InputGuard`), nhả phím khi mất tiêu điểm (`releaseOnBlur`), ghi log khi đơ (`Watchdog`) và mục cứu hộ (`Rescue`).
* **Giao diện & cấu hình AngelChip:** Tích hợp sẵn 2 skin **AngelChip Gray** / **AngelChip Black**, file cấu hình `angelchip_config2.xml` và tham số `--tabId`.

## Cách đóng gói thành file `.jar`

### Cách 1: Tự động trên GitHub (không cần cài gì trên máy)
1. Giải nén thư mục dự án này và đẩy toàn bộ lên repository GitHub của bạn (nhánh `main` hoặc `master`).
2. Mở tab **Actions** trên GitHub → chọn workflow **Build AngelChipEmulator JAR** (tự chạy mỗi khi push, hoặc bấm **Run workflow**).
3. Khi chạy xong (khoảng 20–30 giây), tải file **`AngelChipEmulator_PureJava.jar`** ở mục **Artifacts**.

### Cách 2: Build trực tiếp trên máy cá nhân
* **Windows:** Cài JDK 11+ (hoặc 17) và Apache Maven, sau đó nhấp đúp `build.bat` → nhận file `dist\AngelChipEmulator_PureJava.jar`.
* **Linux / macOS:** Chạy `./build.sh` → nhận file `dist/AngelChipEmulator_PureJava.jar`.

*(File `.jar` xuất ra tương thích ngược với Java 8 32-bit/64-bit nhờ cờ `--release 8`.)*

## Vị trí các tệp chính khi bạn muốn chỉnh sửa code
* `src/main/java/ep1/` và `src/main/java/org/microemu/app/ui/swing/DialogProxySettings.java`: Toàn bộ giao diện và logic Proxy SOCKS5 / kiểm tra proxy.
* `src/main/java/ep3/`: Toàn bộ menu Tối ưu (`ToiUu.java`, `ToiUuMenu.java`, `InputGuard.java`, `Rescue.java`, `Watchdog.java`).
* `src/main/java/org/microemu/app/Main.java`: Thanh menu (`File`, `Options`, `AngelChip`, `Tối ưu`) và xử lý tham số khởi chạy (`--proxyProfile`, `--tabId`).
* `src/main/java/javax/microedition/lcdui/Displayable.java` & `AngelChipSleepCanvas.java`: Chế độ tự ngủ cũ của AngelChip (đã vá P8).
