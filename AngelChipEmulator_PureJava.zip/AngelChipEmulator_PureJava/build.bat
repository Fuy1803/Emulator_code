@echo off
setlocal
cd /d "%~dp0"

where mvn >nul 2>nul
if %errorlevel% neq 0 (
    echo [LOI] Khong tim thay Maven (mvn) trong PATH.
    echo Ban co the cai Maven hoac day du an nay len GitHub de GitHub Actions tu dong build file .jar.
    pause
    exit /b 1
)

echo Dang bien dich AngelChipEmulator_PureJava.jar (Java 8)...
call mvn -B -DskipTests clean package
if %errorlevel% neq 0 (
    echo [LOI] Bien dich that bai. Kiem tra log o tren.
    pause
    exit /b 1
)

if not exist dist mkdir dist
copy /Y target\AngelChipEmulator_PureJava.jar dist\AngelChipEmulator_PureJava.jar >nul
echo.
echo [THANH CONG] Da tao file: dist\AngelChipEmulator_PureJava.jar
pause
